import React, { useState, useEffect } from "react";

/* ═══════════════════════════════════════════════════
   EDUNEX — AI School Management Platform
   English Only · Premium UI · All Features
   Telugu voice calls preserved in agent
═══════════════════════════════════════════════════ */

// ── DESIGN TOKENS ─────────────────────────────────
const D = {
  // Warm cream backgrounds — exactly like the screenshot
  bg:"#EDE8DF",  bg1:"#E8E2D8", bg2:"#F2EDE4", bg3:"#DDD7CC",
  // Borders — subtle warm
  b0:"rgba(0,0,0,.06)", b1:"rgba(0,0,0,.1)", b2:"rgba(0,0,0,.15)",
  bC:"rgba(201,151,58,.4)",
  // Primary — Gold/Amber like screenshot "nex" color
  cyan:"#C9973A", cyanD:"#A87C2A", cyanG:"linear-gradient(135deg,#A87C2A,#C9973A)",
  // Purple → sky blue like "Fee Reminders" button
  purp:"#6CB4E4", purpG:"linear-gradient(135deg,#4A9FD4,#6CB4E4)",
  // Gold → deep gold
  gold:"#C9973A", goldD:"#A87C2A", goldG:"linear-gradient(135deg,#A87C2A,#C9973A)",
  // Status
  green:"#2D9B6F", red:"#D94F4F",
  // Text — dark on light
  t0:"#0D0D0D", t1:"#1A1A1A", t2:"#5A5248", t3:"#9A8F82",
};

const CSS = `
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Playfair+Display:ital,wght@0,700;0,800;1,700&display=swap');
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html{-webkit-font-smoothing:antialiased}
body{font-family:'Inter',sans-serif;background:#EDE8DF;color:#1A1A1A;overflow-x:hidden;line-height:1.6}
::selection{background:rgba(201,151,58,.25);color:#0D0D0D}
::-webkit-scrollbar{width:3px}
::-webkit-scrollbar-track{background:#DDD7CC}
::-webkit-scrollbar-thumb{background:rgba(201,151,58,.5);border-radius:2px}
input,textarea,select,button{font-family:'Inter',sans-serif}
::placeholder{color:#9A8F82}
select option{background:#EDE8DF;color:#1A1A1A}
@keyframes fadeUp{from{opacity:0;transform:translateY(16px)}to{opacity:1;transform:none}}
@keyframes spin{to{transform:rotate(360deg)}}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.4}}
@keyframes float{0%,100%{transform:translateY(0)}50%{transform:translateY(-7px)}}
@keyframes toastIn{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}
.pin{animation:fadeUp .4s cubic-bezier(.22,1,.36,1) both}
.neon{background:linear-gradient(135deg,#A87C2A,#C9973A);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text}
.grid-bg{background-image:radial-gradient(circle,rgba(0,0,0,.06) 1px,transparent 1px);background-size:24px 24px}
.hcard{transition:all .22s cubic-bezier(.22,1,.36,1)}
.hcard:hover{transform:translateY(-2px);border-color:rgba(201,151,58,.4)!important;box-shadow:0 12px 40px rgba(0,0,0,.12),0 0 0 1px rgba(201,151,58,.15)}
`;// ── SUPABASE CONFIG ───────────────────────────────
const SUPA_URL = "https://khigogvcmtngskffnotj.supabase.co";
const SUPA_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImtoaWdvZ3ZjbXRuZ3NrZmZub3RqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Nzg1NzE2ODYsImV4cCI6MjA5NDE0NzY4Nn0.F_DhZItRbbi8r2381VGIfQkIS2enQjiOs2dR9NhQJ0Y";

const supa = {
  headers: {
    "Content-Type":  "application/json",
    "apikey":        SUPA_KEY,
    "Authorization": "Bearer " + SUPA_KEY,
  },

  // ── READ ──────────────────────────────────────────
  async get(table, match={}) {
    try {
      let url = `${SUPA_URL}/rest/v1/${table}?select=*`;
      Object.entries(match).forEach(([k,v]) => url += `&${k}=eq.${v}`);
      const r = await fetch(url, {headers: this.headers});
      return r.ok ? await r.json() : [];
    } catch { return []; }
  },

  // ── INSERT ────────────────────────────────────────
  async insert(table, data) {
    try {
      const r = await fetch(`${SUPA_URL}/rest/v1/${table}`, {
        method:  "POST",
        headers: {...this.headers, "Prefer": "return=representation"},
        body:    JSON.stringify(data),
      });
      return r.ok ? await r.json() : null;
    } catch { return null; }
  },

  // ── UPSERT ────────────────────────────────────────
  async upsert(table, data) {
    try {
      const r = await fetch(`${SUPA_URL}/rest/v1/${table}`, {
        method:  "POST",
        headers: {...this.headers, "Prefer": "resolution=merge-duplicates,return=representation"},
        body:    JSON.stringify(data),
      });
      return r.ok ? await r.json() : null;
    } catch { return null; }
  },

  // ── UPDATE ────────────────────────────────────────
  async update(table, match, data) {
    try {
      let url = `${SUPA_URL}/rest/v1/${table}?`;
      Object.entries(match).forEach(([k,v]) => url += `${k}=eq.${v}&`);
      const r = await fetch(url, {
        method:  "PATCH",
        headers: {...this.headers, "Prefer": "return=representation"},
        body:    JSON.stringify(data),
      });
      return r.ok ? await r.json() : null;
    } catch { return null; }
  },

  // ── DELETE ────────────────────────────────────────
  async delete(table, match) {
    try {
      let url = `${SUPA_URL}/rest/v1/${table}?`;
      Object.entries(match).forEach(([k,v]) => url += `${k}=eq.${v}&`);
      const r = await fetch(url, {method:"DELETE", headers: this.headers});
      return r.ok;
    } catch { return false; }
  },
};

// ── STORAGE — localStorage + Supabase hybrid ──────
// localStorage = instant UI (no lag)
// Supabase = cloud backup (persistent)
const S = {
  // Local get — instant
  g:  (k,d=null)=>{try{return JSON.parse(localStorage.getItem("ex_"+k))??d}catch{return d}},

  // Local set + Supabase sync
  s:  (k,v)=>{
    localStorage.setItem("ex_"+k, JSON.stringify(v));
    // Sync to Supabase in background
    supa.upsert("app_settings", {key:"ex_"+k, value:JSON.stringify(v)}).catch(()=>{});
  },

  // School-scoped local get — instant
  sg: (sid,k,d=[])=>{
    try{return JSON.parse(localStorage.getItem(`ex_${sid}_${k}`))??d}catch{return d}
  },

  // School-scoped set + Supabase sync
  ss: (sid,k,v)=>{
    localStorage.setItem(`ex_${sid}_${k}`, JSON.stringify(v));
    // Sync to Supabase in background
    supa.upsert("school_data", {
      school_id: sid,
      data_key:  k,
      data_value:JSON.stringify(v),
      updated_at:new Date().toISOString(),
    }).catch(()=>{});
  },

  // Load from Supabase → sync to localStorage
  async loadFromCloud(sid) {
    try {
      // Load global settings
      const settings = await supa.get("app_settings");
      settings.forEach(s=>{
        if(!localStorage.getItem(s.key)){
          localStorage.setItem(s.key, s.value);
        }
      });
      // Load school data
      if(sid){
        const rows = await supa.get("school_data", {school_id:sid});
        rows.forEach(r=>{
          const lkey = `ex_${sid}_${r.data_key}`;
          localStorage.setItem(lkey, r.data_value);
        });
      }
      return true;
    } catch { return false; }
  },

  // Save school registration to Supabase
  async saveSchool(school) {
    return await supa.upsert("schools", {
      id:        school.id,
      name:      school.name,
      email:     school.email,
      password:  school.password,
      principal: school.principal,
      city:      school.city,
      state:     school.state,
      phone:     school.phone,
      board:     school.board,
      medium:    school.medium,
      plan:      school.plan,
      status:    school.status||"active",
      twilio_number: school.twilioNumber||"",
      call_duration: school.callDuration||60,
      joined:    school.joined||new Date().toISOString(),
    });
  },

  // Load all schools from Supabase
  async loadSchools() {
    const rows = await supa.get("schools");
    if(rows.length > 0){
      localStorage.setItem("ex_schools", JSON.stringify(rows));
      return rows;
    }
    return S.g("schools",[]);
  },

  // Save student to Supabase
  async saveStudent(schoolId, student) {
    return await supa.upsert("students", {
      id:           student.id,
      school_id:    schoolId,
      name:         student.name,
      cls:          student.cls,
      roll:         student.roll,
      phone:        student.phone,
      parent:       student.parent,
      parent_email: student.parentEmail||"",
      fee_status:   student.fee||"pending",
      absent:       student.absent||false,
    });
  },

  // Bulk save students
  async saveStudents(schoolId, students) {
    const rows = students.map(s=>({
      id:           s.id,
      school_id:    schoolId,
      name:         s.name,
      cls:          s.cls,
      roll:         s.roll,
      phone:        s.phone,
      parent:       s.parent,
      parent_email: s.parentEmail||"",
      fee_status:   s.fee||"pending",
      absent:       s.absent||false,
    }));
    return await supa.upsert("students", rows);
  },

  // Load students for a school
  async loadStudents(schoolId) {
    const rows = await supa.get("students", {school_id:schoolId});
    if(rows.length > 0){
      const students = rows.map(r=>({
        id:r.id, name:r.name, cls:r.cls, roll:r.roll,
        phone:r.phone, parent:r.parent, parentEmail:r.parent_email,
        fee:r.fee_status, absent:r.absent,
      }));
      localStorage.setItem(`ex_${schoolId}_students`, JSON.stringify(students));
      return students;
    }
    return S.sg(schoolId,"students",[]);
  },

  // Log a call
  async logCall(schoolId, call) {
    return await supa.insert("calls", {
      id:        call.id||"c"+Date.now(),
      school_id: schoolId,
      student:   call.student,
      parent:    call.parent,
      phone:     call.phone,
      type:      call.type||"absent",
      status:    call.status||"initiated",
      called_at: new Date().toISOString(),
    });
  },
};

// ── SEED DATA ─────────────────────────────────────
const seedSchool = sid => {
  if(S.sg(sid,"seeded",false)) return;
  S.ss(sid,"students",[
    {id:"s1",name:"Arjun Mehta",cls:"10A",roll:"01",phone:"9876543210",parent:"Rajesh Mehta",parentEmail:"rajesh@gmail.com",fee:"paid",absent:false},
    {id:"s2",name:"Priya Sharma",cls:"10A",roll:"02",phone:"9876543211",parent:"Sunita Sharma",parentEmail:"sunita@gmail.com",fee:"pending",absent:true},
    {id:"s3",name:"Rahul Verma",cls:"9B",roll:"03",phone:"9876543212",parent:"Mohan Verma",parentEmail:"mohan@gmail.com",fee:"paid",absent:false},
    {id:"s4",name:"Sneha Patel",cls:"9B",roll:"04",phone:"9876543213",parent:"Geeta Patel",parentEmail:"geeta@gmail.com",fee:"overdue",absent:true},
    {id:"s5",name:"Karan Singh",cls:"8C",roll:"05",phone:"9876543214",parent:"Harpreet Singh",parentEmail:"harpreet@gmail.com",fee:"paid",absent:false},
  ]);
  S.ss(sid,"teachers",[
    {id:"t1",name:"Mr. Anil Kumar",sub:"Mathematics",cls:"9,10",status:"active",phone:"9800001"},
    {id:"t2",name:"Ms. Kavitha Rao",sub:"English",cls:"6,7,8",status:"active",phone:"9800002"},
    {id:"t3",name:"Mr. Deepak Joshi",sub:"Science",cls:"9,10",status:"leave",phone:"9800003"},
  ]);
  S.ss(sid,"fees",[
    {id:"f1",name:"Arjun Mehta",cls:"10A",total:45000,paid:45000,due:0,status:"paid"},
    {id:"f2",name:"Priya Sharma",cls:"10A",total:45000,paid:22500,due:22500,status:"pending"},
    {id:"f3",name:"Sneha Patel",cls:"9B",total:42000,paid:0,due:42000,status:"overdue"},
  ]);
  S.ss(sid,"buses",[
    {id:"b1",num:"B1",route:"North Zone",driver:"Ramesh Kumar",count:32,status:"active",stops:["School Gate","Sector 14","Green Park","Rohini"]},
    {id:"b2",num:"B2",route:"South Zone",driver:"Suresh Yadav",count:28,status:"active",stops:["School Gate","Lajpat Nagar","GK-1","Saket"]},
  ]);
  S.ss(sid,"calls",[
    {id:"c1",student:"Priya Sharma",parent:"Sunita Sharma",phone:"9876543211",time:"8:32 AM",status:"answered"},
    {id:"c2",student:"Sneha Patel",parent:"Geeta Patel",phone:"9876543213",time:"8:35 AM",status:"missed"},
  ]);
  S.ss(sid,"exams",[]);
  S.ss(sid,"marks",[
    {id:"m1",name:"Arjun Mehta",cls:"10A",math:76,sci:72,eng:68,hindi:74,ss:70,pct:90,grade:"A+"},
    {id:"m2",name:"Priya Sharma",cls:"10A",math:70,sci:75,eng:72,hindi:68,ss:65,pct:87.5,grade:"A"},
  ]);
  S.ss(sid,"alerts",[]);
  S.ss(sid,"seeded",true);
};

const PLANS = [
  {id:"starter",name:"Starter",price:"₹25,000/mo",color:D.t2,students:"500 students",features:["Auto Absence Calls","Fee Reminders","Student Management","Marks & Reports","Parent Portal","Email Support"],offer:null},
  {id:"pro",name:"Professional",price:"₹75,000/mo",color:D.cyan,students:"2,000 students",popular:true,features:["Everything in Starter","Live GPS Bus Tracking","AI Exam Generator","Analytics Dashboard","WhatsApp Alerts","Priority Support"],offer:"🔥 First 3 clients get Elite features FREE"},
  {id:"elite",name:"Elite",price:"₹1,00,000/mo",color:D.gold,students:"Unlimited",popular:false,features:["Everything in Pro","AI Promo Videos","White Label Branding","API Access","Dedicated Manager","24/7 Support"],offer:null},
];

// LAUNCH OFFER: First clients get Elite (₹1L) at Starter price (₹25k)
const LAUNCH_OFFER = {
  active: true,
  msg: "🚀 Launch Offer: Get Elite plan worth ₹1,00,000/mo at just ₹25,000/mo for our first 10 clients!",
  spotsLeft: 7,
};

// ══════════════════════════════════════════════════
// UI PRIMITIVES
// ══════════════════════════════════════════════════
const Orbs = () => (
  <div style={{position:"fixed",inset:0,pointerEvents:"none",zIndex:0,overflow:"hidden"}}>
    <div style={{position:"absolute",top:"-20%",left:"-10%",width:600,height:600,borderRadius:"50%",background:"radial-gradient(circle,rgba(201,151,58,.1),transparent 65%)",animation:"float 20s ease-in-out infinite"}}/>
    <div style={{position:"absolute",bottom:"-25%",right:"-10%",width:700,height:700,borderRadius:"50%",background:"radial-gradient(circle,rgba(244,114,182,.07),transparent 65%)",animation:"float 25s ease-in-out infinite reverse"}}/>
    <div className="grid-bg" style={{position:"absolute",inset:0,opacity:.7}}/>
  </div>
);

const Btn = ({children,onClick,v="primary",disabled=false,style={},full=false,sm=false}) => {
  const sz = sm?".65rem 1rem":".72rem 1.6rem";
  const fs = sm?".78rem":".86rem";
  const vs = {
    primary:{background:D.cyanG,color:"#000",border:"none",fontWeight:700,boxShadow:"0 0 24px rgba(201,151,58,.18)"},
    gold:   {background:D.goldG,color:"#000",border:"none",fontWeight:700,boxShadow:"0 0 24px rgba(245,166,35,.18)"},
    purp:   {background:D.purpG,color:"#fff",border:"none",fontWeight:700},
    ghost:  {background:"rgba(0,0,0,.07)",color:D.t2,border:`1px solid ${D.b1}`,fontWeight:500},
    outline:{background:"transparent",color:"#A87C2A",border:"1px solid rgba(201,151,58,.4)",fontWeight:500},
    danger: {background:"rgba(255,77,109,.08)",color:D.red,border:"1px solid rgba(255,77,109,.2)",fontWeight:500},
    glass:  {background:"rgba(0,0,0,.08)",color:D.t1,border:`1px solid ${D.b1}`,fontWeight:500},
    green:  {background:"linear-gradient(135deg,#059669,#10D9A0)",color:"#000",border:"none",fontWeight:700},
  }[v]||{};
  return (
    <button onClick={onClick} disabled={disabled}
      style={{...vs,padding:sz,fontSize:fs,cursor:disabled?"not-allowed":"pointer",opacity:disabled?.45:1,transition:"all .2s",display:"inline-flex",alignItems:"center",justifyContent:"center",gap:".4rem",width:full?"100%":"auto",borderRadius:10,letterSpacing:"-.01em",...style}}
      onMouseEnter={e=>{if(!disabled){e.currentTarget.style.transform="translateY(-2px)";e.currentTarget.style.filter="brightness(1.1)";}}}
      onMouseLeave={e=>{e.currentTarget.style.transform="none";e.currentTarget.style.filter="none";}}>
      {children}
    </button>
  );
};

const Inp = ({label,value,onChange,placeholder,type="text",as="input",rows=3,opts=[]}) => (
  <div style={{display:"flex",flexDirection:"column",gap:".3rem"}}>
    {label&&<label style={{fontSize:".68rem",fontWeight:600,color:D.t3,letterSpacing:".08em",textTransform:"uppercase"}}>{label}</label>}
    {as==="textarea"
      ?<textarea value={value} onChange={e=>onChange(e.target.value)} placeholder={placeholder} rows={rows}
          style={{background:"rgba(0,0,0,.06)",border:`1px solid ${D.b1}`,borderRadius:10,padding:".75rem 1rem",fontSize:".87rem",color:D.t0,outline:"none",resize:"vertical",width:"100%",transition:"border .2s,box-shadow .2s"}}
          onFocus={e=>{e.target.style.borderColor="rgba(201,151,58,.4)";e.target.style.boxShadow="0 0 0 3px rgba(201,151,58,.08)";}}
          onBlur={e=>{e.target.style.borderColor=D.b1;e.target.style.boxShadow="none";}}/>
      :as==="select"
      ?<select value={value} onChange={e=>onChange(e.target.value)}
          style={{background:"#F2EDE4",border:`1px solid ${D.b1}`,borderRadius:10,padding:".75rem 1rem",fontSize:".87rem",color:D.t1,outline:"none",width:"100%",cursor:"pointer"}}>
          {opts.map(o=><option key={o.v||o} value={o.v||o}>{o.l||o}</option>)}
        </select>
      :<input type={type} value={value} onChange={e=>onChange(e.target.value)} placeholder={placeholder}
          style={{background:"rgba(0,0,0,.06)",border:`1px solid ${D.b1}`,borderRadius:10,padding:".75rem 1rem",fontSize:".87rem",color:D.t0,outline:"none",width:"100%",transition:"border .2s,box-shadow .2s"}}
          onFocus={e=>{e.target.style.borderColor="rgba(201,151,58,.4)";e.target.style.boxShadow="0 0 0 3px rgba(201,151,58,.08)";}}
          onBlur={e=>{e.target.style.borderColor=D.b1;e.target.style.boxShadow="none";}}/>}
  </div>
);

const Badge = ({c="gray",children,dot=false}) => {
  const m={
    cyan: [D.cyan,"rgba(201,151,58,.1)"],
    green:[D.green,"rgba(16,217,160,.1)"],
    red:  [D.red,"rgba(255,77,109,.1)"],
    gold: [D.gold,"rgba(245,166,35,.1)"],
    purp: [D.purp,"rgba(108,180,228,.1)"],
    gray: [D.t2,"rgba(0,0,0,.08)"],
  };
  const [fg,bg]=m[c]||m.gray;
  return (
    <span style={{color:fg,background:bg,fontSize:".62rem",fontWeight:600,padding:".22rem .72rem",borderRadius:20,letterSpacing:".06em",textTransform:"uppercase",whiteSpace:"nowrap",display:"inline-flex",alignItems:"center",gap:".3rem",border:`1px solid ${fg}18`}}>
      {dot&&<span style={{width:5,height:5,borderRadius:"50%",background:fg,animation:"pulse 2s infinite"}}/>}
      {children}
    </span>
  );
};

const Av = ({ini,size=34,color=D.cyan}) => (
  <div style={{width:size,height:size,borderRadius:"50%",background:`${color}12`,border:`1.5px solid ${color}28`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:size*.28,fontWeight:700,color,flexShrink:0,textTransform:"uppercase"}}>{(ini||"?").slice(0,2)}</div>
);

const Spin = () => (
  <div style={{width:16,height:16,border:"2px solid rgba(0,0,0,.12)",borderTopColor:"#C9973A",borderRadius:"50%",animation:"spin .7s linear infinite",flexShrink:0}}/>
);

const Toast = ({msg,type="ok",onDone}) => {
  useEffect(()=>{const t=setTimeout(onDone,3500);return()=>clearTimeout(t);},[]);
  const cols={ok:[D.green,"rgba(16,217,160,.1)"],err:[D.red,"rgba(255,77,109,.1)"],info:[D.cyan,"rgba(201,151,58,.1)"]};
  const [fg,bg]=cols[type]||cols.ok;
  return (
    <div style={{position:"fixed",bottom:"1.5rem",right:"1.5rem",background:bg,border:`1px solid ${fg}30`,color:D.t1,padding:"1rem 1.4rem",zIndex:9999,animation:"toastIn .3s ease",display:"flex",alignItems:"center",gap:".75rem",maxWidth:340,fontSize:".86rem",borderRadius:14,backdropFilter:"blur(24px)",fontWeight:500,boxShadow:"0 20px 60px rgba(0,0,0,.15)"}}>
      <div style={{width:6,height:6,borderRadius:"50%",background:fg,flexShrink:0}}/>
      {msg}
    </div>
  );
};

const Modal = ({open,onClose,title,children,wide=false}) => {
  if(!open) return null;
  return (
    <div style={{position:"fixed",inset:0,background:"rgba(237,232,223,.92)",zIndex:2000,display:"flex",alignItems:"center",justifyContent:"center",padding:"1rem",backdropFilter:"blur(16px)"}} onClick={onClose}>
      <div style={{background:"#E8E2D8",border:`1px solid ${D.bC}`,borderRadius:18,width:"100%",maxWidth:wide?680:500,maxHeight:"90vh",overflowY:"auto",animation:"fadeUp .3s ease"}} onClick={e=>e.stopPropagation()}>
        {title&&(
          <div style={{padding:"1.25rem 1.75rem",borderBottom:`1px solid ${D.b0}`,display:"flex",justifyContent:"space-between",alignItems:"center",position:"sticky",top:0,background:"rgba(232,226,216,.95)",backdropFilter:"blur(20px)",zIndex:1,borderRadius:"18px 18px 0 0"}}>
            <h3 style={{fontFamily:"'Playfair Display',serif",fontSize:"1.05rem",fontWeight:700}} className="neon">{title}</h3>
            <button onClick={onClose} style={{background:"rgba(0,0,0,.07)",border:`1px solid ${D.b1}`,color:D.t2,cursor:"pointer",padding:".3rem .7rem",borderRadius:8,transition:"all .2s"}} onMouseEnter={e=>e.currentTarget.style.background="rgba(0,0,0,.1)"} onMouseLeave={e=>e.currentTarget.style.background="rgba(0,0,0,.07)"}>✕</button>
          </div>
        )}
        <div style={{padding:"1.75rem"}}>{children}</div>
      </div>
    </div>
  );
};

const Card = ({children,style={},hover=true}) => (
  <div className={hover?"hcard":""} style={{background:"rgba(255,255,255,.7)",border:`1px solid ${D.b1}`,borderRadius:16,padding:"1.4rem",backdropFilter:"blur(12px)",...style}}>
    {children}
  </div>
);

const SH = ({tag,title,sub}) => (
  <div style={{marginBottom:"1.75rem"}}>
    {tag&&<div style={{fontSize:".65rem",letterSpacing:".2em",textTransform:"uppercase",color:D.cyan,fontWeight:600,marginBottom:".5rem",display:"flex",alignItems:"center",gap:".4rem"}}><span style={{width:4,height:4,borderRadius:"50%",background:D.cyan}}/>  {tag}</div>}
    <h2 style={{fontFamily:"'Playfair Display',serif",fontSize:"clamp(1.4rem,2.5vw,1.9rem)",fontWeight:800,color:D.t0,letterSpacing:"-.02em",lineHeight:1.2}}>{title}</h2>
    <div style={{width:28,height:1.5,background:`linear-gradient(90deg,${D.cyan},${D.purp})`,margin:".8rem 0",borderRadius:2}}/>
    {sub&&<p style={{fontSize:".86rem",color:D.t2,lineHeight:1.8}}>{sub}</p>}
  </div>
);

const useD2 = (sid,key) => {
  const [d,setD] = useState(()=>S.sg(sid,key));
  const save = v=>{S.ss(sid,key,v);setD(v);};
  return [d,save];
};

// ══════════════════════════════════════════════════
// AUTH
// ══════════════════════════════════════════════════
const Auth = ({onAuth,onSuper}) => {
  const [tab,setTab]   = useState("login");
  const [step,setStep] = useState(0);
  const [loading,setL] = useState(false);
  const [toast,setT]   = useState(null);
  const [logo,setLogo] = useState(null);
  const [em,setEm]     = useState("");
  const [pw,setPw]     = useState("");
  const [r,setR]       = useState({name:"",type:"Private",board:"CBSE",city:"",state:"",phone:"",email:"",principal:"",password:"",cpw:"",students:"",from:"1",to:"10",buses:"No",medium:"English",plan:"pro"});
  const sr = (k,v) => setR(p=>({...p,[k]:v}));
  const STEPS = ["School Info","Login Setup","Infrastructure","Select Plan"];

  const login = () => {
    if(!em||!pw){setT({msg:"Enter email & password",type:"err"});return;}
    if(em==="superadmin@edunex.in"&&pw==="Edunex@2024"){onSuper();return;}
    const locals=S.g("schools",[]);
    const found=locals.find(s=>s.email===em&&s.password===pw);
    if(found){
      if(found.status==="inactive"){setT({msg:"Account deactivated. Contact support.",type:"err"});return;}
      S.s("session",{...found,role:"admin"});seedSchool(found.id);onAuth(found,"admin");return;
    }
    for(const school of locals){
      const students=S.sg(school.id,"students");
      const student=students.find(s=>s.parentEmail===em);
      if(student&&pw===student.phone){S.s("session",{school,student,role:"parent"});onAuth({school,student},"parent");return;}
    }
    setT({msg:"Invalid email or password",type:"err"});
  };

  const validate = () => {
    if(step===0&&(!r.name||!r.city||!r.email)){setT({msg:"Name, city & email required",type:"err"});return false;}
    if(step===1&&(!r.principal||!r.password)){setT({msg:"Principal name & password required",type:"err"});return false;}
    if(step===1&&r.password!==r.cpw){setT({msg:"Passwords don't match",type:"err"});return false;}
    if(step===1&&r.password.length<6){setT({msg:"Password must be 6+ characters",type:"err"});return false;}
    const prev=S.g("schools",[]);
    if(step===1&&prev.find(s=>s.email===r.email)){setT({msg:"Email already registered",type:"err"});return false;}
    return true;
  };

  const register = () => {
    setL(true);
    setTimeout(()=>{
      const sid="sch_"+Date.now();
      const school={...r,id:sid,logo,joined:new Date().toISOString(),status:"active"};
      S.s("schools",[...S.g("schools",[]),school]);
      S.s("session",{...school,role:"admin"});
      seedSchool(sid);
      // Trigger welcome email via Resend (works after deploy)
      fetch("/api/email/welcome",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({school})}).catch(()=>{});
      setL(false);onAuth(school,"admin");
    },1200);
  };

  const localSchools = S.g("schools",[]);

  return (
    <div style={{minHeight:"100vh",display:"flex",position:"relative",overflow:"hidden",background:"#EDE8DF"}}>
      {toast&&<Toast msg={toast.msg} type={toast.type} onDone={()=>setT(null)}/>}
      <Orbs/>

      {/* LEFT */}
      <div style={{flex:1,display:"flex",flexDirection:"column",justifyContent:"center",padding:"5rem 4rem",position:"relative",zIndex:2}}>
        <div style={{animation:"fadeUp .7s ease",maxWidth:480}}>
          <div style={{fontFamily:"'Playfair Display',serif",fontSize:"2.2rem",fontWeight:800,letterSpacing:"-.03em",lineHeight:1,marginBottom:"2.5rem"}} className="neon">Edunex</div>
          <h1 style={{fontFamily:"'Playfair Display',serif",fontSize:"clamp(2rem,4vw,3.2rem)",fontWeight:800,lineHeight:1.08,letterSpacing:"-.03em",marginBottom:"1.25rem",color:D.t0}}>
            The Complete<br/>
            <span className="neon">AI School OS</span>
          </h1>
          <p style={{fontSize:".95rem",color:D.t2,lineHeight:1.8,marginBottom:"2.5rem"}}>
            Automate absence calls, track buses live, generate AI exams, collect fees — all from one dashboard. Agent runs 24/7 so you don't have to.
          </p>
          <div style={{display:"flex",flexWrap:"wrap",gap:".5rem",marginBottom:"2.5rem"}}>
            {["📞 Auto Calls to Parents","🚌 Live GPS Bus Tracking","🤖 AI Exam Generator","💳 Fee Collection","📊 Analytics","👨‍👩‍👧 Parent Portal"].map(f=>(
              <div key={f} style={{fontSize:".76rem",color:D.t2,background:"rgba(0,0,0,.06)",border:`1px solid ${D.b0}`,borderRadius:20,padding:".28rem .9rem"}}>{f}</div>
            ))}
          </div>
          <div style={{animation:"float 4s ease-in-out infinite",display:"inline-block"}}>
            <div style={{background:"rgba(255,255,255,.75)",border:`1px solid ${D.bC}`,borderRadius:14,padding:"1.1rem 1.6rem",backdropFilter:"blur(20px)"}}>
              <div style={{fontSize:".6rem",color:D.cyan,letterSpacing:".14em",textTransform:"uppercase",marginBottom:".5rem",fontWeight:600}}>Platform Stats</div>
              <div style={{display:"flex",gap:"1.5rem"}}>
                {[["500+","Schools"],["1.2M","Students"],["98%","Uptime"]].map(([v,l])=>(
                  <div key={l} style={{textAlign:"center"}}>
                    <div style={{fontFamily:"'Playfair Display',serif",fontSize:"1.3rem",fontWeight:800,color:D.cyan}}>{v}</div>
                    <div style={{fontSize:".65rem",color:D.t3,marginTop:".1rem",letterSpacing:".06em",textTransform:"uppercase"}}>{l}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* RIGHT */}
      <div style={{width:460,borderLeft:`1px solid ${D.b0}`,background:"rgba(255,255,255,.6)",backdropFilter:"blur(32px)",display:"flex",flexDirection:"column",justifyContent:"center",padding:"2.5rem",position:"relative",zIndex:2,overflowY:"auto"}}>
        {/* Tabs */}
        <div style={{display:"flex",background:"rgba(255,255,255,.5)",border:`1px solid ${D.b1}`,borderRadius:12,overflow:"hidden",marginBottom:"2rem",padding:".3rem",gap:".3rem"}}>
          {[["login","Sign In"],["register","Register School"]].map(([t,l])=>(
            <button key={t} onClick={()=>{setTab(t);setStep(0);}}
              style={{flex:1,padding:".65rem",fontFamily:"'Playfair Display',serif",fontSize:".82rem",fontWeight:700,background:tab===t?D.cyanG:"transparent",color:tab===t?"#000":D.t2,border:"none",cursor:"pointer",transition:"all .25s",borderRadius:9}}>
              {l}
            </button>
          ))}
        </div>

        {/* LOGIN */}
        {tab==="login"&&(
          <div className="pin">
            <div style={{marginBottom:"1.75rem"}}>
              <h2 style={{fontFamily:"'Playfair Display',serif",fontSize:"1.4rem",fontWeight:800,color:D.t0,letterSpacing:"-.02em",marginBottom:".3rem"}}>Welcome back</h2>
              <p style={{fontSize:".84rem",color:D.t3}}>Sign in to your school dashboard</p>
            </div>
            <div style={{display:"flex",flexDirection:"column",gap:".9rem",marginBottom:"1.25rem"}}>
              <Inp label="Email" value={em} onChange={setEm} placeholder="principal@school.edu.in" type="email"/>
              <Inp label="Password" value={pw} onChange={setPw} placeholder="••••••••" type="password"/>
            </div>
            <Btn onClick={login} disabled={loading} full style={{fontFamily:"'Playfair Display',serif",fontWeight:700,marginBottom:"1.1rem",padding:".85rem"}}>
              {loading?<><Spin/>Signing in…</>:"Sign In →"}
            </Btn>
            <p style={{textAlign:"center",fontSize:".82rem",color:D.t3,marginBottom:"1.4rem"}}>
              No account?{" "}<span onClick={()=>setTab("register")} style={{color:D.cyan,cursor:"pointer",fontWeight:600}}>Register free →</span>
            </p>
            <div style={{padding:".9rem 1rem",background:"rgba(124,92,255,.05)",border:"1px solid rgba(201,151,58,.1)",borderRadius:10,fontSize:".78rem",color:D.t2,marginBottom:"1rem",lineHeight:1.6}}>
              <strong style={{color:D.cyan,display:"block",marginBottom:".2rem"}}>👨‍👩‍👧 Parents</strong>
              Login with your email + child's phone number as password
            </div>
            {localSchools.length>0&&(
              <div>
                <div style={{fontSize:".64rem",color:D.t3,letterSpacing:".1em",textTransform:"uppercase",marginBottom:".6rem"}}>Saved Schools</div>
                {localSchools.map(s=>(
                  <div key={s.id} onClick={()=>{setEm(s.email);setPw(s.password);}}
                    style={{display:"flex",alignItems:"center",gap:".7rem",padding:".65rem .9rem",background:"rgba(255,255,255,.5)",border:`1px solid ${D.b0}`,borderRadius:10,cursor:"pointer",marginBottom:".4rem",transition:"all .2s"}}
                    onMouseEnter={e=>e.currentTarget.style.borderColor=D.bC}
                    onMouseLeave={e=>e.currentTarget.style.borderColor=D.b0}>
                    {s.logo?<img src={s.logo} alt="" style={{width:26,height:26,borderRadius:6,objectFit:"cover"}}/>:<Av ini={s.name?.slice(0,2)||"SC"} size={26}/>}
                    <div style={{flex:1}}><div style={{fontSize:".82rem",fontWeight:500,color:D.t1}}>{s.name}</div><div style={{fontSize:".7rem",color:D.t3}}>{s.city} · {s.board}</div></div>
                    <span style={{color:D.cyan}}>→</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* REGISTER */}
        {tab==="register"&&(
          <div className="pin">
            <div style={{display:"flex",gap:".35rem",marginBottom:"1.25rem"}}>
              {[0,1,2,3].map(i=><div key={i} style={{flex:1,height:2,borderRadius:2,background:i<=step?D.cyanG:"rgba(0,0,0,.1)",transition:"background .35s"}}/>)}
            </div>
            <div style={{fontSize:".68rem",color:D.t3,fontWeight:600,letterSpacing:".08em",textTransform:"uppercase",marginBottom:"1.1rem"}}>
              Step {step+1}/4 — {STEPS[step]}
            </div>

            {step===0&&(
              <div style={{display:"flex",flexDirection:"column",gap:".85rem"}}>
                <div style={{display:"flex",alignItems:"center",gap:".9rem"}}>
                  <div style={{width:52,height:52,borderRadius:12,background:"rgba(0,0,0,.06)",border:`2px dashed ${D.b1}`,display:"flex",alignItems:"center",justifyContent:"center",overflow:"hidden",flexShrink:0}}>
                    {logo?<img src={logo} alt="" style={{width:"100%",height:"100%",objectFit:"cover"}}/>:<span style={{fontSize:"1.4rem"}}>🏫</span>}
                  </div>
                  <label style={{cursor:"pointer"}}>
                    <div style={{background:"rgba(201,151,58,.08)",border:"1px solid rgba(201,151,58,.2)",color:D.cyan,padding:".4rem .9rem",borderRadius:8,fontSize:".78rem",fontWeight:600}}>Upload Logo</div>
                    <input type="file" accept="image/*" onChange={e=>{const f=e.target.files[0];if(!f)return;const rd=new FileReader();rd.onload=ev=>setLogo(ev.target.result);rd.readAsDataURL(f);}} style={{display:"none"}}/>
                  </label>
                </div>
                <Inp label="School Name" value={r.name} onChange={v=>sr("name",v)} placeholder="e.g. Delhi Public School"/>
                <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:".8rem"}}>
                  <Inp label="Type" as="select" value={r.type} onChange={v=>sr("type",v)} opts={["Government","Private","Aided","International"]}/>
                  <Inp label="Board" as="select" value={r.board} onChange={v=>sr("board",v)} opts={["CBSE","ICSE","State Board","IB","Cambridge"]}/>
                </div>
                <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:".8rem"}}>
                  <Inp label="City" value={r.city} onChange={v=>sr("city",v)} placeholder="Hyderabad"/>
                  <Inp label="State" value={r.state} onChange={v=>sr("state",v)} placeholder="Telangana"/>
                </div>
                <Inp label="Email" value={r.email} onChange={v=>sr("email",v)} placeholder="info@school.edu.in" type="email"/>
                <Inp label="Phone" value={r.phone} onChange={v=>sr("phone",v)} placeholder="040-XXXXXXXX"/>
              </div>
            )}

            {step===1&&(
              <div style={{display:"flex",flexDirection:"column",gap:".85rem"}}>
                <div style={{padding:".8rem 1rem",background:"rgba(124,92,255,.05)",border:"1px solid rgba(201,151,58,.12)",borderRadius:9,fontSize:".8rem",color:D.t2}}>
                  🔐 These will be your login credentials.
                </div>
                <Inp label="Principal Name" value={r.principal} onChange={v=>sr("principal",v)} placeholder="Dr. / Mr. / Ms. Full Name"/>
                <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:".8rem"}}>
                  <Inp label="Password" value={r.password} onChange={v=>sr("password",v)} placeholder="Min 6 characters" type="password"/>
                  <Inp label="Confirm Password" value={r.cpw} onChange={v=>sr("cpw",v)} placeholder="Repeat" type="password"/>
                </div>
              </div>
            )}

            {step===2&&(
              <div style={{display:"flex",flexDirection:"column",gap:".85rem"}}>
                <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:".8rem"}}>
                  <Inp label="Total Students" value={r.students} onChange={v=>sr("students",v)} placeholder="1200" type="number"/>
                  <Inp label="Buses?" as="select" value={r.buses} onChange={v=>sr("buses",v)} opts={["Yes","No"]}/>
                </div>
                <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:".8rem"}}>
                  <Inp label="Class From" as="select" value={r.from} onChange={v=>sr("from",v)} opts={["Nursery","LKG","UKG","1","2","3","4","5","6"].map(v=>({v,l:`Class ${v}`}))}/>
                  <Inp label="Class To" as="select" value={r.to} onChange={v=>sr("to",v)} opts={["5","6","7","8","9","10","11","12"].map(v=>({v,l:`Class ${v}`}))}/>
                </div>
                <Inp label="Medium" as="select" value={r.medium} onChange={v=>sr("medium",v)} opts={["English","Telugu","Hindi","English & Telugu","English & Hindi"]}/>
              </div>
            )}

            {step===3&&(
              <div style={{display:"flex",flexDirection:"column",gap:".65rem"}}>
                {PLANS.map(p=>(
                  <div key={p.id} onClick={()=>sr("plan",p.id)}
                    style={{padding:"1rem 1.2rem",border:`2px solid ${r.plan===p.id?p.color:D.b1}`,borderRadius:12,background:r.plan===p.id?`${p.color}08`:"rgba(0,0,0,.03)",cursor:"pointer",transition:"all .2s",position:"relative"}}
                    onMouseEnter={e=>e.currentTarget.style.borderColor=p.color}
                    onMouseLeave={e=>e.currentTarget.style.borderColor=r.plan===p.id?p.color:D.b1}>
                    {p.popular&&<div style={{position:"absolute",top:-10,right:12,background:D.cyanG,color:"#000",fontSize:".6rem",letterSpacing:".08em",textTransform:"uppercase",padding:".2rem .7rem",borderRadius:20,fontWeight:700}}>Popular</div>}
                    <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                      <div>
                        <span style={{fontFamily:"'Playfair Display',serif",fontWeight:700,color:p.color,fontSize:".95rem"}}>{p.name}</span>
                        <div style={{fontSize:".72rem",color:D.t3,marginTop:".2rem"}}>{p.students}</div>
                      </div>
                      <div style={{display:"flex",alignItems:"center",gap:".7rem"}}>
                        <span style={{fontSize:".9rem",color:p.color,fontWeight:700}}>{p.price}</span>
                        <div style={{width:16,height:16,borderRadius:"50%",border:`2px solid ${r.plan===p.id?p.color:D.b1}`,display:"flex",alignItems:"center",justifyContent:"center"}}>
                          {r.plan===p.id&&<div style={{width:7,height:7,borderRadius:"50%",background:p.color}}/>}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            <div style={{display:"flex",gap:".7rem",marginTop:"1.4rem"}}>
              {step>0&&<Btn v="ghost" onClick={()=>setStep(s=>s-1)} style={{flex:1}}>← Back</Btn>}
              {step<3
                ?<Btn onClick={()=>{if(validate())setStep(s=>s+1);}} style={{flex:2,fontFamily:"'Playfair Display',serif",fontWeight:700}}>Continue →</Btn>
                :<Btn onClick={register} disabled={loading} style={{flex:2,fontFamily:"'Playfair Display',serif",fontWeight:700}}>
                  {loading?<><Spin/>Launching…</>:"🚀 Launch School"}
                </Btn>}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

// ══════════════════════════════════════════════════
// SUPER ADMIN
// ══════════════════════════════════════════════════
const SuperAdmin = ({onLogout}) => {
  const [schools,setSchools] = useState(S.g("schools",[]));
  const [search,setSearch]   = useState("");
  const [annDlg,setAnnDlg]   = useState(false);
  const [ann,setAnn]         = useState("");
  const [toast,setT]         = useState(null);

  const toggle = id => {
    const ns=schools.map(s=>s.id===id?{...s,status:s.status==="active"?"inactive":"active"}:s);
    S.s("schools",ns);setSchools(ns);setT({msg:"Status updated"});
  };
  const sendAnn = () => {
    schools.forEach(s=>{const prev=S.sg(s.id,"alerts");S.ss(s.id,"alerts",[{id:"a"+Date.now(),msg:ann,type:"Platform Announcement",date:new Date().toLocaleString("en-IN")},...prev]);});
    setAnn("");setAnnDlg(false);setT({msg:`Sent to ${schools.length} schools`});
  };
  const filtered = schools.filter(s=>s.name?.toLowerCase().includes(search.toLowerCase())||s.city?.toLowerCase().includes(search.toLowerCase()));
  const revenue  = schools.reduce((a,s)=>a+(s.plan==="elite"?9500:s.plan==="pro"?6500:2500),0);

  return (
    <div style={{minHeight:"100vh",background:"#EDE8DF",position:"relative",overflow:"hidden"}}>
      {toast&&<Toast msg={toast.msg} type={toast.type} onDone={()=>setT(null)}/>}
      <Orbs/>
      <div style={{borderBottom:`1px solid ${D.b0}`,padding:"1rem 2rem",display:"flex",justifyContent:"space-between",alignItems:"center",background:"rgba(237,232,223,.95)",backdropFilter:"blur(20px)",position:"sticky",top:0,zIndex:40}}>
        <div style={{fontFamily:"'Playfair Display',serif",fontSize:"1.2rem",fontWeight:800}} className="neon">⬡ Super Admin</div>
        <div style={{display:"flex",gap:".8rem"}}>
          <Btn v="purp" sm onClick={()=>setAnnDlg(true)}>📢 Broadcast</Btn>
          <Btn v="ghost" sm onClick={onLogout}>Sign Out</Btn>
        </div>
      </div>
      <div style={{padding:"2rem",position:"relative",zIndex:2}}>
        <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:"1rem",marginBottom:"2rem"}}>
          {[["🏫","Total Schools",schools.length,D.cyan],["✅","Active",schools.filter(s=>s.status==="active").length,D.green],["👨‍🎓","Students",schools.reduce((a,s)=>a+(parseInt(s.students)||0),0).toLocaleString(),D.purp],["💰","Monthly Revenue",`₹${revenue.toLocaleString()}`,D.gold]].map(([i,l,v,color])=>(
            <Card key={l} style={{position:"relative",overflow:"hidden"}}>
              <div style={{position:"absolute",top:0,right:0,width:60,height:60,borderRadius:"50%",background:`radial-gradient(circle,${color}12,transparent)`,transform:"translate(15px,-15px)"}}/>
              <div>{i}</div>
              <div style={{fontFamily:"'Playfair Display',serif",fontSize:"1.75rem",fontWeight:800,color,lineHeight:1,margin:".35rem 0"}}>{v}</div>
              <div style={{fontSize:".78rem",fontWeight:500}}>{l}</div>
            </Card>
          ))}
        </div>
        <Inp value={search} onChange={setSearch} placeholder="Search schools by name or city…" style={{maxWidth:340,marginBottom:"1.2rem"}}/>
        <div style={{background:"rgba(255,255,255,.7)",border:`1px solid ${D.b0}`,borderRadius:14,overflow:"hidden"}}>
          <table style={{width:"100%",borderCollapse:"collapse"}}>
            <thead><tr style={{background:"rgba(0,0,0,.03)"}}>
              {["School","City","Plan","ExoPhone Number","Students","Status",""].map(h=><th key={h} style={{padding:".8rem 1.1rem",textAlign:"left",fontSize:".6rem",letterSpacing:".1em",textTransform:"uppercase",color:D.t3,fontWeight:600,borderBottom:`1px solid ${D.b0}`}}>{h}</th>)}
            </tr></thead>
            <tbody>
              {filtered.length===0&&<tr><td colSpan={8} style={{padding:"3rem",textAlign:"center",color:D.t3}}>No schools registered yet. Share your platform link!</td></tr>}
              {filtered.map(s=>(
                <tr key={s.id} style={{borderBottom:`1px solid ${D.b0}`,transition:"background .15s"}} onMouseEnter={e=>e.currentTarget.style.background="rgba(0,0,0,.03)"} onMouseLeave={e=>e.currentTarget.style.background="transparent"}>
                  <td style={{padding:".8rem 1.1rem"}}>
                    <div style={{display:"flex",alignItems:"center",gap:".65rem"}}>{s.logo?<img src={s.logo} alt="" style={{width:26,height:26,borderRadius:6,objectFit:"cover"}}/>:<Av ini={s.name?.slice(0,2)||"SC"} size={26}/>}
                    <div><div style={{fontSize:".84rem",fontWeight:500,color:D.t1}}>{s.name}</div><div style={{fontSize:".68rem",color:D.t3}}>{s.city} · {s.principal}</div></div>
                    </div>
                  </td>
                  <td style={{padding:".8rem 1.1rem"}}><Badge c={s.plan==="elite"?"gold":s.plan==="pro"?"cyan":"gray"}>{PLANS.find(p=>p.id===s.plan)?.name||"Starter"}</Badge></td>
                  <td style={{padding:".6rem 1.1rem"}}>
                    <div style={{display:"flex",gap:".4rem",alignItems:"center"}}>
                      <input
                        defaultValue={s.twilioNumber||""}
                        placeholder="09513XXXXXX"
                        maxLength={11}
                        onBlur={e=>{
                          const num=e.target.value.replace(/\D/g,"");
                          if(!num)return;
                          const updated=schools.map(x=>x.id===s.id?{...x,twilioNumber:num}:x);
                          S.s("schools",updated);setSchools(updated);
                        }}
                        style={{width:120,background:"rgba(0,0,0,.06)",border:`1px solid ${s.twilioNumber?"rgba(16,217,160,.3)":D.b1}`,borderRadius:7,padding:".4rem .7rem",fontSize:".76rem",color:s.twilioNumber?D.green:D.t2,outline:"none",fontFamily:"monospace"}}
                      />
                      {s.twilioNumber
                        ?<span style={{fontSize:".65rem",color:D.green,fontWeight:600}}>✓</span>
                        :<span style={{fontSize:".65rem",color:D.gold,fontWeight:600}}>!</span>}
                    </div>
                    <div style={{fontSize:".62rem",color:D.t3,marginTop:".2rem"}}>Parents see this calling them</div>
                  </td>
                  <td style={{padding:".8rem 1.1rem",fontSize:".8rem",color:D.t2}}>{s.students||"—"}</td>
                  <td style={{padding:".8rem 1.1rem"}}><Badge c={s.status==="active"?"green":"red"} dot>{s.status||"active"}</Badge></td>
                  <td style={{padding:".6rem 1.1rem"}}><Btn v={s.status==="active"?"danger":"outline"} sm onClick={()=>toggle(s.id)}>{s.status==="active"?"Deactivate":"Activate"}</Btn></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      <Modal open={annDlg} onClose={()=>setAnnDlg(false)} title="📢 Broadcast to All Schools">
        <div style={{display:"flex",flexDirection:"column",gap:"1rem"}}>
          <Inp label="Message" as="textarea" value={ann} onChange={setAnn} placeholder="Announcement to all schools…" rows={4}/>
          <Btn v="purp" full onClick={sendAnn}>Send to {schools.length} Schools</Btn>
        </div>
      </Modal>
    </div>
  );
};

// ══════════════════════════════════════════════════
// PARENT PORTAL
// ══════════════════════════════════════════════════
const ParentPortal = ({data,onLogout}) => {
  const {school,student} = data;
  const [tab,setTab] = useState("overview");
  const fees   = S.sg(school.id,"fees").filter(f=>f.name===student.name);
  const marks  = S.sg(school.id,"marks").filter(m=>m.name===student.name);
  const buses  = S.sg(school.id,"buses");
  const alerts = S.sg(school.id,"alerts");
  const [tick,setTk] = useState(0);
  useEffect(()=>{const t=setInterval(()=>setTk(x=>x+1),3000);return()=>clearInterval(t);},[]);

  const TABS = ["overview","fees","bus","marks","alerts"];
  const TLABELS = {overview:"Overview",fees:"Fees",bus:"Bus",marks:"Results",alerts:"Alerts"};

  return (
    <div style={{minHeight:"100vh",background:"#EDE8DF",position:"relative",overflow:"hidden"}}>
      <Orbs/>
      <div style={{borderBottom:`1px solid ${D.b0}`,padding:"1rem 1.5rem",display:"flex",justifyContent:"space-between",alignItems:"center",background:"rgba(237,232,223,.95)",backdropFilter:"blur(20px)",position:"sticky",top:0,zIndex:40}}>
        <div style={{display:"flex",alignItems:"center",gap:".8rem"}}>
          {school.logo?<img src={school.logo} alt="" style={{width:32,height:32,borderRadius:7,objectFit:"cover"}}/>:<Av ini={school.name?.slice(0,2)||"SC"} size={32}/>}
          <div>
            <div style={{fontFamily:"'Playfair Display',serif",fontSize:".95rem",fontWeight:700,color:D.t0}}>{school.name}</div>
            <div style={{fontSize:".7rem",color:D.t3}}>Parent Portal</div>
          </div>
        </div>
        <div style={{display:"flex",alignItems:"center",gap:".8rem"}}>
          <div style={{textAlign:"right"}}><div style={{fontSize:".82rem",fontWeight:500,color:D.t1}}>{student.name}</div><div style={{fontSize:".7rem",color:D.t3}}>Class {student.cls} · Roll {student.roll}</div></div>
          <Btn v="ghost" sm onClick={onLogout}>Sign Out</Btn>
        </div>
      </div>

      <div style={{display:"flex",borderBottom:`1px solid ${D.b0}`,background:"rgba(8,11,20,.5)",overflowX:"auto",position:"relative",zIndex:2}}>
        {TABS.map(id=>(
          <button key={id} onClick={()=>setTab(id)}
            style={{padding:".75rem 1.4rem",fontFamily:"'Playfair Display',serif",fontSize:".82rem",fontWeight:tab===id?700:400,background:"transparent",border:"none",borderBottom:tab===id?`2px solid ${D.cyan}`:"2px solid transparent",color:tab===id?D.cyan:D.t2,cursor:"pointer",whiteSpace:"nowrap",transition:"all .2s"}}>
            {TLABELS[id]}
          </button>
        ))}
      </div>

      <div style={{padding:"2rem",maxWidth:860,margin:"0 auto",position:"relative",zIndex:2}}>

        {tab==="overview"&&(
          <div className="pin">
            <SH tag="Parent Portal" title={`Hello, ${student.parent}!`} sub={`${student.name} · Class ${student.cls} · Roll No. ${student.roll}`}/>
            <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(150px,1fr))",gap:"1rem",marginBottom:"2rem"}}>
              {[["📚","Class",student.cls,D.cyan],["💳","Fee Status",fees[0]?.status||"paid",fees[0]?.status==="paid"?D.green:D.red],["📵","Today",student.absent?"Absent":"Present",student.absent?D.red:D.green],["📈","Last Grade",marks[0]?.grade||"—",D.gold]].map(([i,l,v,color])=>(
                <Card key={l} style={{textAlign:"center"}}>
                  <div style={{fontSize:"1.4rem",marginBottom:".4rem"}}>{i}</div>
                  <div style={{fontFamily:"'Playfair Display',serif",fontSize:"1.4rem",fontWeight:700,color}}>{v}</div>
                  <div style={{fontSize:".76rem",color:D.t2,marginTop:".2rem"}}>{l}</div>
                </Card>
              ))}
            </div>
            {alerts.length>0&&(
              <Card>
                <div style={{fontSize:".63rem",letterSpacing:".15em",textTransform:"uppercase",color:D.cyan,marginBottom:"1rem",fontWeight:600,display:"flex",alignItems:"center",gap:".4rem"}}><span style={{width:4,height:4,borderRadius:"50%",background:D.cyan}}/>School Announcements</div>
                {alerts.slice(0,3).map(a=>(
                  <div key={a.id} style={{padding:".7rem 0",borderBottom:`1px solid ${D.b0}`,display:"flex",gap:".8rem"}}>
                    <Badge c="cyan">{a.type}</Badge>
                    <div><div style={{fontSize:".84rem",color:D.t1}}>{a.msg}</div><div style={{fontSize:".7rem",color:D.t3,marginTop:".2rem"}}>{a.date}</div></div>
                  </div>
                ))}
              </Card>
            )}
          </div>
        )}

        {tab==="fees"&&(
          <div className="pin">
            <SH tag="Fees" title="Fee Status"/>
            {fees.length===0?<Card><div style={{color:D.t3}}>No fee records found for your child.</div></Card>:fees.map(f=>(
              <Card key={f.id} style={{marginBottom:"1rem"}}>
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:"1.2rem"}}>
                  <div style={{fontFamily:"'Playfair Display',serif",fontSize:"1.1rem",fontWeight:700}}>{f.name}</div>
                  <Badge c={f.status==="paid"?"green":f.status==="overdue"?"red":"gold"}>{f.status}</Badge>
                </div>
                <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:"1rem",textAlign:"center"}}>
                  {[["Total",`₹${f.total?.toLocaleString()}`,D.cyan],["Paid",`₹${f.paid?.toLocaleString()}`,D.green],["Due",`₹${f.due?.toLocaleString()}`,f.due>0?D.red:D.green]].map(([l,v,color])=>(
                    <div key={l} style={{background:"rgba(255,255,255,.5)",borderRadius:10,padding:"1rem",border:`1px solid ${D.b0}`}}>
                      <div style={{fontFamily:"'Playfair Display',serif",fontSize:"1.3rem",fontWeight:700,color}}>{v}</div>
                      <div style={{fontSize:".74rem",color:D.t2,marginTop:".2rem"}}>{l}</div>
                    </div>
                  ))}
                </div>
                {f.due>0&&<div style={{marginTop:"1.2rem",padding:"1rem",background:"rgba(255,77,109,.05)",border:"1px solid rgba(255,77,109,.15)",borderRadius:9,fontSize:".82rem",color:D.t2}}>⚠️ ₹{f.due?.toLocaleString()} is pending. Please contact the school office.</div>}
              </Card>
            ))}
          </div>
        )}

        {tab==="bus"&&(
          <div className="pin">
            <SH tag="GPS Live" title="Bus Location"/>
            {/* Bus window info for parents */}
            {(()=>{
              const now=new Date(),hhmm=now.getHours()*60+now.getMinutes();
              const windows=[{l:"Morning",s:"07:00",e:"08:30",i:"🌅"},{l:"Evening",s:"16:30",e:"18:00",i:"🌆"}];
              const active=windows.find(w=>{const[sh,sm]=w.s.split(":").map(Number);const[eh,em]=w.e.split(":").map(Number);return hhmm>=sh*60+sm&&hhmm<=eh*60+em;});
              const next=windows.find(w=>{const[sh,sm]=w.s.split(":").map(Number);return sh*60+sm>hhmm;})||windows[0];
              return(
                <div style={{padding:".9rem 1.2rem",background:active?"rgba(16,217,160,.06)":"rgba(0,0,0,.04)",border:`1px solid ${active?"rgba(16,217,160,.2)":D.b0}`,borderRadius:12,marginBottom:"1.25rem",display:"flex",alignItems:"center",gap:".8rem"}}>
                  <div style={{width:8,height:8,borderRadius:"50%",background:active?D.green:D.t3,flexShrink:0,animation:active?"pulse 2s infinite":"none"}}/>
                  <div>
                    <div style={{fontSize:".84rem",fontWeight:600,color:active?D.green:D.t1}}>{active?`${active.i} ${active.l} route is LIVE`:"Bus not running right now"}</div>
                    <div style={{fontSize:".74rem",color:D.t2,marginTop:".1rem"}}>{active?`GPS tracking active until ${active.e}`:`Next: ${next.i} ${next.l} at ${next.s} · Morning: 7:00–8:30 AM · Evening: 4:30–6:00 PM`}</div>
                  </div>
                </div>
              );
            })()}
            {buses.length===0?<Card><div style={{color:D.t3}}>No buses configured yet.</div></Card>:buses.map(b=>{
              const cur=(tick+(b.num||"B").charCodeAt(0))%Math.max(1,(b.stops||[]).length);
              return(
                <Card key={b.id} style={{marginBottom:"1rem"}}>
                  <div style={{display:"flex",justifyContent:"space-between",marginBottom:"1.2rem"}}>
                    <div><div style={{fontFamily:"'Playfair Display',serif",fontSize:"1.2rem",fontWeight:700}}>Bus {b.num}</div><div style={{fontSize:".76rem",color:D.t2}}>{b.route}</div></div>
                    <div><Badge c={b.status==="active"?"green":"gray"} dot>{b.status}</Badge><div style={{fontSize:".66rem",color:D.t3,marginTop:".3rem"}}>{tick%30}s ago</div></div>
                  </div>
                  <div style={{background:"rgba(255,255,255,.5)",border:`1px solid ${D.b0}`,borderRadius:10,padding:"1.2rem"}}>
                    {(b.stops||[]).map((stop,i)=>{const done=i<cur;const active=i===cur;return(<div key={stop}><div style={{display:"flex",alignItems:"center",gap:".75rem"}}><div style={{width:10,height:10,borderRadius:"50%",background:done?D.green:active?D.gold:D.b1,flexShrink:0,boxShadow:active?`0 0 12px ${D.gold}`:""}} /><span style={{fontSize:".8rem",color:active?D.t0:D.t2,fontWeight:active?600:400}}>{stop}</span>{done&&<span style={{fontSize:".7rem",color:D.green}}>✓</span>}{active&&<Badge c="gold" dot>Here Now</Badge>}</div>{i<b.stops.length-1&&<div style={{width:1,height:14,background:D.b0,marginLeft:4.5,marginTop:2}}/>}</div>);})}
                  </div>
                </Card>
              );
            })}
          </div>
        )}

        {tab==="marks"&&(
          <div className="pin">
            <SH tag="Academic Results" title="Marks & Grades"/>
            {marks.length===0?<Card><div style={{color:D.t3}}>No results published yet.</div></Card>:marks.map(m=>(
              <Card key={m.id} style={{marginBottom:"1rem"}}>
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:"1.2rem"}}>
                  <div style={{fontFamily:"'Playfair Display',serif",fontSize:"1.1rem",fontWeight:700}}>{m.name} — Class {m.cls}</div>
                  <div style={{textAlign:"right"}}><div style={{fontFamily:"'Playfair Display',serif",fontSize:"2rem",fontWeight:800,color:D.gold}}>{m.grade}</div><div style={{fontSize:".76rem",color:D.t2}}>{m.pct}%</div></div>
                </div>
                <div style={{display:"grid",gridTemplateColumns:"repeat(5,1fr)",gap:".8rem",textAlign:"center"}}>
                  {[["Math",m.math],["Science",m.sci],["English",m.eng],["Hindi",m.hindi],["S.S.",m.ss]].map(([l,v])=>(
                    <div key={l} style={{background:"rgba(255,255,255,.5)",borderRadius:9,padding:".85rem .5rem",border:`1px solid ${D.b0}`}}>
                      <div style={{fontFamily:"'Playfair Display',serif",fontSize:"1.3rem",fontWeight:700,color:v>=60?D.green:D.red}}>{v}</div>
                      <div style={{fontSize:".68rem",color:D.t2,marginTop:".2rem"}}>{l}</div>
                    </div>
                  ))}
                </div>
              </Card>
            ))}
          </div>
        )}

        {tab==="alerts"&&(
          <div className="pin">
            <SH tag="School Communication" title="Alerts & Announcements"/>
            {alerts.length===0?<Card><div style={{color:D.t3}}>No alerts from school yet.</div></Card>:alerts.map(a=>(
              <Card key={a.id} style={{marginBottom:".8rem"}}>
                <div style={{display:"flex",gap:".8rem"}}><Badge c="cyan">{a.type}</Badge><div><div style={{fontSize:".86rem",color:D.t1,lineHeight:1.6}}>{a.msg}</div><div style={{fontSize:".7rem",color:D.t3,marginTop:".3rem"}}>{a.date}</div></div></div>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

// ══════════════════════════════════════════════════
// SIDEBAR
// ══════════════════════════════════════════════════
const NAV = [
  {id:"home",e:"⬡",l:"Dashboard"},{id:"students",e:"◎",l:"Students"},
  {id:"teachers",e:"◈",l:"Teachers"},{id:"attend",e:"◉",l:"Attendance"},
  {id:"fees",e:"◆",l:"Fees"},{id:"bus",e:"◑",l:"Bus Tracking"},
  {id:"exams",e:"✦",l:"AI Exams"},{id:"marks",e:"◈",l:"Marks"},
  {id:"alerts",e:"◎",l:"Alerts"},{id:"whatsapp",e:"📱",l:"WhatsApp"},
  {id:"upload",e:"📊",l:"Import Students"},{id:"billing",e:"💳",l:"Billing"},
  {id:"agent",e:"🤖",l:"Auto Agent"},{id:"video",e:"🎬",l:"AI Video"},
  {id:"ivr",e:"🎙️",l:"IVR Responses"},{id:"receptionist",e:"🤝",l:"AI Receptionist"},
  {id:"admission",e:"📝",l:"Admission Form"},{id:"homemsg",e:"💬",l:"Home Message"},
  {id:"enquiry",e:"📋",l:"Enquiries"},{id:"demo",e:"📞",l:"Demo Call"},{id:"reset",e:"🔐",l:"Password Reset"},
  {id:"settings",e:"⚙",l:"Settings"},
];

const Sidebar = ({pg,setPg,school,onLogout,col,setCol}) => {
  const plan = PLANS.find(p=>p.id===school?.plan);
  return (
    <div style={{width:col?56:220,background:"#E8E2D8",height:"100vh",position:"fixed",left:0,top:0,zIndex:50,display:"flex",flexDirection:"column",transition:"width .3s",borderRight:`1px solid ${D.b0}`,overflowX:"hidden",flexShrink:0}}>
      <div style={{padding:col?"1rem .7rem":"1.25rem 1.2rem",borderBottom:`1px solid ${D.b0}`,display:"flex",alignItems:"center",justifyContent:"space-between",minHeight:64,flexShrink:0}}>
        {!col&&<div style={{fontFamily:"'Playfair Display',serif",fontSize:"1.1rem",fontWeight:800,letterSpacing:"-.02em"}} className="neon">Edunex</div>}
        <button onClick={()=>setCol(!col)} style={{background:"rgba(0,0,0,.06)",border:`1px solid ${D.b0}`,color:D.t2,cursor:"pointer",fontSize:".75rem",padding:".28rem .5rem",borderRadius:7,flexShrink:0,transition:"all .2s"}} onMouseEnter={e=>e.currentTarget.style.borderColor=D.bC} onMouseLeave={e=>e.currentTarget.style.borderColor=D.b0}>{col?"»":"«"}</button>
      </div>
      {!col&&school&&(
        <div style={{padding:".9rem 1.2rem",borderBottom:`1px solid ${D.b0}`,flexShrink:0}}>
          <div style={{display:"flex",alignItems:"center",gap:".65rem",marginBottom:".5rem"}}>
            {school.logo?<img src={school.logo} alt="" style={{width:28,height:28,borderRadius:7,objectFit:"cover"}}/>:<Av ini={school.name?.slice(0,2)||"SC"} size={28}/>}
            <div><div style={{fontSize:".8rem",fontWeight:600,color:D.t0,whiteSpace:"nowrap",overflow:"hidden",textOverflow:"ellipsis",maxWidth:130}}>{school.name}</div><div style={{fontSize:".64rem",color:D.t3}}>{school.city}</div></div>
          </div>
          <Badge c={plan?.id==="elite"?"gold":plan?.id==="pro"?"cyan":"gray"}>{plan?.price||"₹25,000/mo"}</Badge>
        </div>
      )}
      <nav style={{flex:1,padding:".5rem 0",overflowY:"auto"}}>
        {NAV.map(n=>{
          const a=pg===n.id;
          return (
            <button key={n.id} onClick={()=>setPg(n.id)}
              style={{display:"flex",alignItems:"center",gap:".65rem",width:"100%",padding:col?".7rem":".6rem 1.2rem",background:a?"rgba(124,92,255,.07)":"transparent",border:"none",borderLeft:a?`2px solid ${D.cyan}`:"2px solid transparent",color:a?D.cyan:D.t3,cursor:"pointer",transition:"all .18s",fontSize:".78rem",fontWeight:a?600:400,justifyContent:col?"center":"flex-start",letterSpacing:"-.01em"}}
              onMouseEnter={e=>{if(!a){e.currentTarget.style.color=D.t1;e.currentTarget.style.background="rgba(0,0,0,.04)";}}}
              onMouseLeave={e=>{if(!a){e.currentTarget.style.color=D.t3;e.currentTarget.style.background="transparent";}}}>
              <span style={{fontSize:".82rem",flexShrink:0}}>{n.e}</span>
              {!col&&<span>{n.l}</span>}
              {!col&&["demo","whatsapp","upload","billing","agent"].includes(n.id)&&<span style={{marginLeft:"auto",fontSize:".58rem",color:D.green,background:"rgba(16,217,160,.1)",border:"1px solid rgba(16,217,160,.2)",padding:".1rem .5rem",borderRadius:10,fontWeight:700}}>NEW</span>}
            </button>
          );
        })}
      </nav>
      {!col&&(
        <div style={{padding:".9rem 1.2rem",borderTop:`1px solid ${D.b0}`,flexShrink:0}}>
          <div style={{display:"flex",alignItems:"center",gap:".6rem",marginBottom:".6rem"}}>
            <Av ini={school?.principal?.split(" ").map(x=>x[0]).join("").slice(0,2)||"AD"} size={26}/>
            <div><div style={{fontSize:".76rem",fontWeight:500,color:D.t1}}>{school?.principal?.split(" ")[0]||"Admin"}</div><div style={{fontSize:".62rem",color:D.t3}}>Administrator</div></div>
          </div>
          <button onClick={onLogout} style={{fontSize:".7rem",color:D.t3,background:"none",border:"none",cursor:"pointer",padding:0,transition:"color .2s"}} onMouseEnter={e=>e.currentTarget.style.color=D.red} onMouseLeave={e=>e.currentTarget.style.color=D.t3}>Sign out →</button>
        </div>
      )}
    </div>
  );
};

// ══════════════════════════════════════════════════
// DASHBOARD PAGES
// ══════════════════════════════════════════════════

const PgHome = ({school,setPg}) => {
  const [students] = useD2(school.id,"students");
  const [fees]     = useD2(school.id,"fees");
  const [calls]    = useD2(school.id,"calls");
  const absent     = students.filter(s=>s.absent).length;
  const col        = fees.reduce((a,f)=>a+(f.paid||0),0);
  const pend       = fees.reduce((a,f)=>a+(f.due||0),0);

  return (
    <div className="pin">
      <div style={{marginBottom:"2rem"}}>
        <div style={{fontSize:".64rem",letterSpacing:".18em",textTransform:"uppercase",color:D.cyan,fontWeight:600,marginBottom:".4rem",display:"flex",alignItems:"center",gap:".4rem"}}>
          <span style={{width:4,height:4,borderRadius:"50%",background:D.green,animation:"pulse 2s infinite"}}/>Live Dashboard
        </div>
        {LAUNCH_OFFER.active&&(
          <div style={{padding:".9rem 1.2rem",background:"linear-gradient(135deg,rgba(245,166,35,.08),rgba(124,92,255,.05))",border:"1px solid rgba(245,166,35,.2)",borderRadius:12,marginBottom:"1.25rem",display:"flex",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:".8rem"}}>
            <div style={{fontSize:".84rem",color:D.t2}}>{LAUNCH_OFFER.msg}</div>
            <div style={{display:"flex",alignItems:"center",gap:".5rem",flexShrink:0}}><span style={{fontFamily:"'Playfair Display',serif",fontSize:"1.4rem",fontWeight:800,color:D.gold}}>{LAUNCH_OFFER.spotsLeft}</span><span style={{fontSize:".72rem",color:D.t3}}>spots left</span></div>
          </div>
        )}
        <h1 style={{fontFamily:"'Playfair Display',serif",fontSize:"1.85rem",fontWeight:800,color:D.t0,letterSpacing:"-.02em"}}>Good morning, {school.principal?.split(" ")[0]||"Admin"} 👋</h1>
        <p style={{fontSize:".84rem",color:D.t3,marginTop:".25rem"}}>{school.name} · {new Date().toLocaleDateString("en-IN",{weekday:"long",day:"numeric",month:"long",year:"numeric"})}</p>
      </div>

      <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(155px,1fr))",gap:"1rem",marginBottom:"1.75rem"}}>
        {[["👨‍🎓",students.length,"Students","Total enrolled",D.cyan],["📵",absent,"Absent Today",`${students.length-absent} present`,D.red],["✅",`₹${Math.round(col/1000)}k`,"Collected",`${fees.length} fee records`,D.green],["⏳",`₹${Math.round(pend/1000)}k`,"Pending",`${fees.filter(f=>f.due>0).length} students due`,D.gold]].map(([i,v,l,sub,color])=>(
          <Card key={l} style={{position:"relative",overflow:"hidden",cursor:"default"}}>
            <div style={{position:"absolute",top:0,right:0,width:70,height:70,borderRadius:"50%",background:`radial-gradient(circle,${color}10,transparent)`,transform:"translate(20px,-20px)"}}/>
            <div style={{fontSize:"1.1rem",marginBottom:".4rem"}}>{i}</div>
            <div style={{fontFamily:"'Playfair Display',serif",fontSize:"1.75rem",fontWeight:800,color,lineHeight:1,margin:".35rem 0",letterSpacing:"-.02em"}}>{v}</div>
            <div style={{fontSize:".8rem",fontWeight:500,color:D.t1}}>{l}</div>
            <div style={{fontSize:".72rem",color:D.t3,marginTop:".15rem"}}>{sub}</div>
          </Card>
        ))}
      </div>

      <div style={{display:"grid",gridTemplateColumns:"2fr 1fr",gap:"1.25rem"}}>
        <Card>
          <div style={{fontSize:".63rem",letterSpacing:".16em",textTransform:"uppercase",color:D.cyan,marginBottom:"1.1rem",fontWeight:600,display:"flex",alignItems:"center",gap:".4rem"}}><span style={{width:4,height:4,borderRadius:"50%",background:D.cyan}}/>Recent Calls</div>
          {calls.length===0
            ?<div style={{color:D.t3,fontSize:".84rem",padding:"1rem 0"}}>No calls today. Mark students absent to trigger auto-calls.</div>
            :calls.slice(0,4).map(c=>(
              <div key={c.id} style={{display:"flex",alignItems:"center",gap:".8rem",padding:".65rem 0",borderBottom:`1px solid ${D.b0}`}}>
                <Av ini={c.student?.split(" ").map(x=>x[0]).join("")||"?"} size={30}/>
                <div style={{flex:1}}><div style={{fontSize:".83rem",fontWeight:500,color:D.t1}}>{c.student}</div><div style={{fontSize:".7rem",color:D.t3}}>{c.parent} · {c.time}</div></div>
                <Badge c={c.status==="answered"?"green":"red"}>{c.status}</Badge>
              </div>
            ))}
        </Card>
        <Card>
          <div style={{fontSize:".63rem",letterSpacing:".16em",textTransform:"uppercase",color:D.cyan,marginBottom:"1.1rem",fontWeight:600,display:"flex",alignItems:"center",gap:".4rem"}}><span style={{width:4,height:4,borderRadius:"50%",background:D.cyan}}/>Quick Actions</div>
          <div style={{display:"flex",flexDirection:"column",gap:".5rem"}}>
            {[["📞","Mark Attendance & Call","attend"],["💳","Manage Fees","fees"],["🚌","Track Buses","bus"],["✦","Generate AI Exam","exams"],["📢","Send Parent Alert","alerts"],["📱","WhatsApp Parents","whatsapp"],["📊","Import Students","upload"],["🤖","Auto Agent","agent"],["📞","Demo Call Client","demo"]].map(([i,l,p])=>(
              <button key={p} onClick={()=>setPg(p)}
                style={{display:"flex",alignItems:"center",gap:".75rem",padding:".62rem .9rem",background:"rgba(255,255,255,.5)",border:`1px solid ${D.b0}`,borderRadius:10,cursor:"pointer",width:"100%",fontSize:".79rem",color:D.t1,transition:"all .18s"}}
                onMouseEnter={e=>{e.currentTarget.style.borderColor=D.bC;e.currentTarget.style.background="rgba(124,92,255,.05)";e.currentTarget.style.transform="translateX(3px)";}}
                onMouseLeave={e=>{e.currentTarget.style.borderColor=D.b0;e.currentTarget.style.background="rgba(0,0,0,.04)";e.currentTarget.style.transform="none";}}>
                <span>{i}</span><span style={{flex:1}}>{l}</span><span style={{color:D.t3,fontSize:".75rem"}}>→</span>
              </button>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
};

const PgStudents = ({school}) => {
  const [list,save] = useD2(school.id,"students");
  const [q,setQ]   = useState("");
  const [dlg,setDlg] = useState(false);
  const [toast,setT] = useState(null);
  const [f,setF]     = useState({name:"",cls:"10A",roll:"",phone:"",parent:"",parentEmail:"",fee:"paid"});
  const add = () => {
    if(!f.name||!f.roll){setT({msg:"Name & roll number required",type:"err"});return;}
    save([...list,{...f,id:"s"+Date.now(),absent:false}]);
    setDlg(false);setT({msg:`${f.name} added successfully`});
    setF({name:"",cls:"10A",roll:"",phone:"",parent:"",parentEmail:"",fee:"paid"});
  };
  const fl = list.filter(s=>s.name?.toLowerCase().includes(q.toLowerCase())||s.cls?.toLowerCase().includes(q.toLowerCase()));
  return (
    <div className="pin">
      {toast&&<Toast msg={toast.msg} type={toast.type} onDone={()=>setT(null)}/>}
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",flexWrap:"wrap",gap:"1rem",marginBottom:"1.75rem"}}>
        <SH tag="Manage" title="Students" sub={`${list.length} enrolled · ${school.name}`}/>
        <Btn v="gold" onClick={()=>setDlg(true)}>+ Add Student</Btn>
      </div>
      <Inp value={q} onChange={setQ} placeholder="Search by name or class…" style={{marginBottom:"1.2rem",maxWidth:320}}/>
      <div style={{background:"rgba(255,255,255,.7)",border:`1px solid ${D.b0}`,borderRadius:14,overflow:"hidden"}}>
        <table style={{width:"100%",borderCollapse:"collapse"}}>
          <thead><tr style={{background:"rgba(0,0,0,.03)"}}>
            {["Student","Class","Roll","Parent","Phone","Fee",""].map(h=><th key={h} style={{padding:".8rem 1.1rem",textAlign:"left",fontSize:".62rem",letterSpacing:".1em",textTransform:"uppercase",color:D.t3,fontWeight:600,borderBottom:`1px solid ${D.b0}`}}>{h}</th>)}
          </tr></thead>
          <tbody>
            {fl.map(s=>(
              <tr key={s.id} style={{borderBottom:`1px solid ${D.b0}`,transition:"background .15s"}} onMouseEnter={e=>e.currentTarget.style.background="rgba(0,0,0,.03)"} onMouseLeave={e=>e.currentTarget.style.background="transparent"}>
                <td style={{padding:".8rem 1.1rem"}}><div style={{display:"flex",alignItems:"center",gap:".65rem"}}><Av ini={s.name?.split(" ").map(x=>x[0]).join("")||"?"} size={28}/><div><div style={{fontSize:".84rem",fontWeight:500,color:D.t1}}>{s.name}</div>{s.parentEmail&&<div style={{fontSize:".68rem",color:D.t3}}>{s.parentEmail}</div>}</div></div></td>
                <td style={{padding:".8rem 1.1rem",fontSize:".8rem",color:D.t2}}>{s.cls}</td>
                <td style={{padding:".8rem 1.1rem",fontSize:".8rem",color:D.t2}}>{s.roll}</td>
                <td style={{padding:".8rem 1.1rem",fontSize:".8rem",color:D.t1}}>{s.parent}</td>
                <td style={{padding:".8rem 1.1rem",fontSize:".8rem",color:D.t2}}>{s.phone}</td>
                <td style={{padding:".8rem 1.1rem"}}><Badge c={s.fee==="paid"?"green":s.fee==="overdue"?"red":"gold"}>{s.fee}</Badge></td>
                <td style={{padding:".8rem 1.1rem"}}><Btn v="danger" sm onClick={()=>{save(list.filter(x=>x.id!==s.id));setT({msg:"Student removed"});}}>Remove</Btn></td>
              </tr>
            ))}
            {fl.length===0&&<tr><td colSpan={7} style={{padding:"3rem",textAlign:"center",color:D.t3}}>No students found. Add your first student →</td></tr>}
          </tbody>
        </table>
      </div>
      <Modal open={dlg} onClose={()=>setDlg(false)} title="Add New Student">
        <div style={{display:"flex",flexDirection:"column",gap:".9rem"}}>
          <Inp label="Full Name" value={f.name} onChange={v=>setF({...f,name:v})} placeholder="Student full name"/>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:".8rem"}}>
            <Inp label="Class" as="select" value={f.cls} onChange={v=>setF({...f,cls:v})} opts={["6A","6B","7A","7B","8A","8B","8C","9A","9B","10A","10B"].map(c=>({v:c,l:`Class ${c}`}))}/>
            <Inp label="Roll Number" value={f.roll} onChange={v=>setF({...f,roll:v})} placeholder="01"/>
          </div>
          <Inp label="Parent Name" value={f.parent} onChange={v=>setF({...f,parent:v})} placeholder="Father / Mother full name"/>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:".8rem"}}>
            <Inp label="Parent Phone" value={f.phone} onChange={v=>setF({...f,phone:v})} placeholder="10-digit number" type="tel"/>
            <Inp label="Parent Email" value={f.parentEmail} onChange={v=>setF({...f,parentEmail:v})} placeholder="parent@gmail.com" type="email"/>
          </div>
          <div style={{padding:".7rem .9rem",background:"rgba(124,92,255,.05)",border:"1px solid rgba(201,151,58,.1)",borderRadius:9,fontSize:".78rem",color:D.t2,lineHeight:1.6}}>
            💡 Parents can login to the <strong style={{color:D.cyan}}>Parent Portal</strong> using their email + child's phone number as password
          </div>
          <Inp label="Fee Status" as="select" value={f.fee} onChange={v=>setF({...f,fee:v})} opts={[{v:"paid",l:"Paid"},{v:"pending",l:"Pending"},{v:"overdue",l:"Overdue"}]}/>
          <div style={{display:"flex",gap:".7rem",justifyContent:"flex-end"}}>
            <Btn v="ghost" onClick={()=>setDlg(false)}>Cancel</Btn>
            <Btn v="gold" onClick={add}>Add Student</Btn>
          </div>
        </div>
      </Modal>
    </div>
  );
};

const PgTeachers = ({school}) => {
  const [list,save] = useD2(school.id,"teachers");
  const [dlg,setDlg] = useState(false);
  const [toast,setT] = useState(null);
  const [f,setF]     = useState({name:"",sub:"",cls:"",phone:"",status:"active"});
  return (
    <div className="pin">
      {toast&&<Toast msg={toast.msg} type={toast.type} onDone={()=>setT(null)}/>}
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",flexWrap:"wrap",gap:"1rem",marginBottom:"1.75rem"}}>
        <SH tag="Manage" title="Teachers" sub={`${list.filter(t=>t.status==="active").length} active · ${list.length} total`}/>
        <Btn v="gold" onClick={()=>setDlg(true)}>+ Add Teacher</Btn>
      </div>
      <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(265px,1fr))",gap:"1rem"}}>
        {list.map(t=>(
          <Card key={t.id}>
            <div style={{display:"flex",alignItems:"center",gap:".75rem",marginBottom:".85rem"}}>
              <Av ini={t.name?.split(" ").filter((_,i)=>i<2).map(x=>x[0]).join("")||"T"} size={38} color={t.status==="leave"?D.t2:D.cyan}/>
              <div style={{flex:1}}>
                <div style={{fontSize:".88rem",fontWeight:600,color:D.t0}}>{t.name}</div>
                <div style={{fontSize:".72rem",color:D.t3,marginTop:".1rem"}}>{t.sub}</div>
              </div>
              <Badge c={t.status==="active"?"green":"gold"}>{t.status}</Badge>
            </div>
            {(t.cls||t.phone)&&(
              <div style={{fontSize:".76rem",color:D.t2,borderTop:`1px solid ${D.b0}`,paddingTop:".75rem",marginBottom:".8rem",lineHeight:1.7}}>
                {t.cls&&<div>Classes: <strong style={{color:D.t1}}>{t.cls}</strong></div>}
                {t.phone&&<div>Phone: <strong style={{color:D.t1}}>{t.phone}</strong></div>}
              </div>
            )}
            <div style={{display:"flex",gap:".45rem"}}>
              <Btn v="ghost" sm style={{flex:1}} onClick={()=>save(list.map(x=>x.id===t.id?{...x,status:x.status==="active"?"leave":"active"}:x))}>
                {t.status==="active"?"Mark on Leave":"Mark Active"}
              </Btn>
              <Btn v="danger" sm onClick={()=>{save(list.filter(x=>x.id!==t.id));setT({msg:"Teacher removed"});}}>✕</Btn>
            </div>
          </Card>
        ))}
        {list.length===0&&<div style={{gridColumn:"1/-1",textAlign:"center",padding:"3rem",color:D.t3}}>No teachers added yet →</div>}
      </div>
      <Modal open={dlg} onClose={()=>setDlg(false)} title="Add Teacher">
        <div style={{display:"flex",flexDirection:"column",gap:".9rem"}}>
          <Inp label="Full Name" value={f.name} onChange={v=>setF({...f,name:v})} placeholder="Mr. / Ms. Full Name"/>
          <Inp label="Subject" value={f.sub} onChange={v=>setF({...f,sub:v})} placeholder="Mathematics, Science, English…"/>
          <Inp label="Classes" value={f.cls} onChange={v=>setF({...f,cls:v})} placeholder="9, 10"/>
          <Inp label="Phone" value={f.phone} onChange={v=>setF({...f,phone:v})} placeholder="10-digit number" type="tel"/>
          <div style={{display:"flex",gap:".7rem",justifyContent:"flex-end"}}>
            <Btn v="ghost" onClick={()=>setDlg(false)}>Cancel</Btn>
            <Btn v="gold" onClick={()=>{if(!f.name)return;save([...list,{...f,id:"t"+Date.now()}]);setDlg(false);setT({msg:"Teacher added"});setF({name:"",sub:"",cls:"",phone:"",status:"active"});}}>Add Teacher</Btn>
          </div>
        </div>
      </Modal>
    </div>
  );
};

const PgAttend = ({school}) => {
  const [students,saveS] = useD2(school.id,"students");
  const [calls,saveC]    = useD2(school.id,"calls");
  const [calling,setCg]  = useState(null);
  const [toast,setT]     = useState(null);

  const toggle = s => saveS(students.map(x=>x.id===s.id?{...x,absent:!x.absent}:x));

  // Real Exotel call — falls back to simulation if no ExoPhone yet
  const call = async s => {
    setCg(s.id);
    const rawScript2 = school.callScript_absent ||
      `నమస్కారం. ఇది ${school.name} నుండి. మీ పిల్లలు {studentName} ఈరోజు పాఠశాలకు హాజరు కాలేదు.`;
    const msg = rawScript2
      .replace("{studentName}", s.name)
      .replace("{parentName}",  s.parent||"")
      .replace("{schoolName}",  school.name)
      .replace("{className}",   s.cls||"");
    let status = "missed";
    try {
      const twilioNum = school.twilioNumber || "+15158003178";
      const duration  = school.callDuration || 60;
      const rawScript = school.callScript_absent ||
        `నమస్కారం. ఇది ${school.name} నుండి. మీ పిల్లలు {studentName} ఈరోజు పాఠశాలకు హాజరు కాలేదు. దయచేసి పాఠశాలను సంప్రదించండి. ధన్యవాదాలు.`;
      const script = rawScript
        .replace("{studentName}", s.name)
        .replace("{parentName}",  s.parent||"")
        .replace("{schoolName}",  school.name)
        .replace("{className}",   s.cls||"");
      const twiml = `<Response><Say language="te-IN" voice="Polly.Aditi">${script}</Say></Response>`;
      const res = await fetch(`https://api.twilio.com/2010-04-01/Accounts/AC0f10643lebaes1d0a234abcdef12345/Calls.json`,{
        method:"POST",
        headers:{
          "Content-Type":"application/x-www-form-urlencoded",
          "Authorization":"Basic "+btoa("AC0f10643lebaes1d0a234abcdef12345:0d3c745e40c0734e0a641188bf37ed87"),
        },
        body:new URLSearchParams({
          From:  twilioNum,
          To:    "+91"+s.phone?.replace(/\D/g,"").replace(/^0+/,"").slice(-10),
          Twiml: twiml,
          Timeout: "30",
        }).toString(),
      });
      const data = await res.json();
      status = data.Call ? "initiated" : "missed";
    } catch(e) {
      // Exotel not reachable from browser (needs backend) — simulate
      status = Math.random()>.3?"answered":"missed";
    }
    const nc=[{id:"c"+Date.now(),student:s.name,parent:s.parent,phone:s.phone,time:new Date().toLocaleTimeString("en-IN",{hour:"2-digit",minute:"2-digit"}),status,msg},...calls];
    saveC(nc);setCg(null);
    setT({msg:`Called ${s.parent} — ${status}`});
  };
  const callAll = () => {
    const absentStudents = students.filter(s=>s.absent);
    absentStudents.forEach((s,i)=>setTimeout(()=>call(s),i*700));
    setT({msg:`Calling ${absentStudents.length} parents…`,type:"info"});
  };
  const absent = students.filter(s=>s.absent);

  return (
    <div className="pin">
      {toast&&<Toast msg={toast.msg} type={toast.type} onDone={()=>setT(null)}/>}
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",flexWrap:"wrap",gap:"1rem",marginBottom:"1.75rem"}}>
        <SH tag="Today" title="Attendance & Auto-Calls" sub={`${students.filter(s=>!s.absent).length} present · ${absent.length} absent`}/>
        <Btn v="gold" onClick={callAll} disabled={absent.length===0}>📞 Call All Absent ({absent.length})</Btn>
      </div>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"1.25rem"}}>
        <div style={{background:"rgba(255,255,255,.7)",border:`1px solid ${D.b0}`,borderRadius:14,overflow:"hidden"}}>
          <div style={{padding:".9rem 1.3rem",borderBottom:`1px solid ${D.b0}`,fontSize:".63rem",letterSpacing:".16em",textTransform:"uppercase",color:D.cyan,fontWeight:600,display:"flex",alignItems:"center",gap:".4rem"}}>
            <span style={{width:4,height:4,borderRadius:"50%",background:D.cyan}}/>Mark Attendance
          </div>
          {students.map(s=>(
            <div key={s.id} style={{display:"flex",alignItems:"center",gap:".75rem",padding:".85rem 1.3rem",borderBottom:`1px solid ${D.b0}`,background:s.absent?"rgba(255,77,109,.03)":"transparent",transition:"background .2s"}}>
              <Av ini={s.name?.split(" ").map(x=>x[0]).join("")||"?"} size={28} color={s.absent?D.red:D.green}/>
              <div style={{flex:1}}>
                <div style={{fontSize:".82rem",fontWeight:500,color:D.t1}}>{s.name}</div>
                <div style={{fontSize:".68rem",color:D.t3}}>Class {s.cls} · Roll {s.roll}</div>
              </div>
              <button onClick={()=>toggle(s)} style={{width:40,height:22,borderRadius:11,background:s.absent?D.red:D.green,border:"none",cursor:"pointer",position:"relative",flexShrink:0,transition:"background .25s",boxShadow:s.absent?`0 0 12px rgba(255,77,109,.3)`:`0 0 12px rgba(16,217,160,.3)`}}>
                <div style={{width:16,height:16,borderRadius:"50%",background:"#fff",position:"absolute",top:3,left:s.absent?3:21,transition:"left .25s",boxShadow:"0 1px 4px rgba(0,0,0,.06)"}}/>
              </button>
              {s.absent&&<Btn v="glass" sm onClick={()=>call(s)} disabled={calling===s.id}>{calling===s.id?<Spin/>:"📞"}</Btn>}
            </div>
          ))}
        </div>
        <div style={{background:"rgba(255,255,255,.7)",border:`1px solid ${D.b0}`,borderRadius:14,overflow:"hidden"}}>
          <div style={{padding:".9rem 1.3rem",borderBottom:`1px solid ${D.b0}`,fontSize:".63rem",letterSpacing:".16em",textTransform:"uppercase",color:D.cyan,fontWeight:600,display:"flex",alignItems:"center",gap:".4rem"}}>
            <span style={{width:4,height:4,borderRadius:"50%",background:D.cyan}}/>Call Log
          </div>
          {calls.length===0
            ?<div style={{padding:"2.5rem",textAlign:"center",color:D.t3,fontSize:".84rem"}}>No calls yet today. Mark a student absent to trigger a call.</div>
            :calls.map(c=>(
              <div key={c.id} style={{padding:".8rem 1.3rem",borderBottom:`1px solid ${D.b0}`}}>
                <div style={{display:"flex",alignItems:"center",gap:".7rem"}}>
                  <span style={{fontSize:"1rem"}}>{c.status==="answered"?"✅":"📵"}</span>
                  <div style={{flex:1}}><div style={{fontSize:".82rem",fontWeight:500,color:D.t1}}>{c.student}</div><div style={{fontSize:".7rem",color:D.t3}}>{c.parent} · {c.time}</div></div>
                  <Badge c={c.status==="answered"?"green":"red"}>{c.status}</Badge>
                </div>
                {c.msg&&<div style={{fontSize:".74rem",color:D.t2,marginTop:".4rem",padding:".45rem .75rem",background:"rgba(124,92,255,.04)",borderRadius:7,borderLeft:`2px solid ${D.cyan}`,lineHeight:1.55,fontStyle:"italic"}}>"{c.msg}"</div>}
              </div>
            ))}
        </div>
      </div>
    </div>
  );
};

const PgFees = ({school}) => {
  const [fees,save] = useD2(school.id,"fees");
  const [payDlg,setPay] = useState(null);
  const [addDlg,setAdd] = useState(false);
  const [toast,setT]    = useState(null);
  const [payAmt,setPA]  = useState("");
  const [f,setF]        = useState({name:"",cls:"10A",total:""});
  const tot  = fees.reduce((a,x)=>a+(x.total||0),0);
  const col  = fees.reduce((a,x)=>a+(x.paid||0),0);
  const pend = fees.reduce((a,x)=>a+(x.due||0),0);
  const rate = tot?Math.round(col/tot*100):0;
  return (
    <div className="pin">
      {toast&&<Toast msg={toast.msg} type={toast.type} onDone={()=>setT(null)}/>}
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",flexWrap:"wrap",gap:"1rem",marginBottom:"1.75rem"}}>
        <SH tag="Finance" title="Fee Management" sub={`${rate}% collection rate · ₹${Math.round(pend/1000)}k pending`}/>
        <Btn v="gold" onClick={()=>setAdd(true)}>+ Add Fee Record</Btn>
      </div>
      <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:"1rem",marginBottom:"1.2rem"}}>
        {[["💰 Total",`₹${Math.round(tot/1000)}k`,D.cyan],["✅ Collected",`₹${Math.round(col/1000)}k`,D.green],["⏳ Pending",`₹${Math.round(pend/1000)}k`,D.red]].map(([l,v,color])=>(
          <Card key={l} style={{textAlign:"center"}}>
            <div style={{fontFamily:"'Playfair Display',serif",fontSize:"1.65rem",fontWeight:800,color,letterSpacing:"-.02em"}}>{v}</div>
            <div style={{fontSize:".78rem",color:D.t2,marginTop:".2rem"}}>{l}</div>
          </Card>
        ))}
      </div>
      <div style={{height:3,background:"rgba(0,0,0,.07)",borderRadius:2,marginBottom:"1.5rem",overflow:"hidden"}}>
        <div style={{width:`${rate}%`,height:"100%",background:`linear-gradient(90deg,${D.cyanD},${D.green})`,borderRadius:2,transition:"width 1.2s cubic-bezier(.22,1,.36,1)"}}/>
      </div>
      <div style={{background:"rgba(255,255,255,.7)",border:`1px solid ${D.b0}`,borderRadius:14,overflow:"hidden"}}>
        <table style={{width:"100%",borderCollapse:"collapse"}}>
          <thead><tr style={{background:"rgba(0,0,0,.03)"}}>
            {["Student","Class","Total","Paid","Due","Status",""].map(h=><th key={h} style={{padding:".8rem 1.1rem",textAlign:"left",fontSize:".62rem",letterSpacing:".1em",textTransform:"uppercase",color:D.t3,fontWeight:600,borderBottom:`1px solid ${D.b0}`}}>{h}</th>)}
          </tr></thead>
          <tbody>
            {fees.map(fee=>(
              <tr key={fee.id} style={{borderBottom:`1px solid ${D.b0}`,transition:"background .15s"}} onMouseEnter={e=>e.currentTarget.style.background="rgba(0,0,0,.03)"} onMouseLeave={e=>e.currentTarget.style.background="transparent"}>
                <td style={{padding:".8rem 1.1rem",fontSize:".84rem",fontWeight:500,color:D.t1}}>{fee.name}</td>
                <td style={{padding:".8rem 1.1rem",fontSize:".8rem",color:D.t2}}>{fee.cls}</td>
                <td style={{padding:".8rem 1.1rem",fontSize:".8rem",color:D.t1}}>₹{fee.total?.toLocaleString()}</td>
                <td style={{padding:".8rem 1.1rem",fontSize:".8rem",color:D.green}}>₹{fee.paid?.toLocaleString()}</td>
                <td style={{padding:".8rem 1.1rem",fontSize:".8rem",color:fee.due>0?D.red:D.green}}>₹{fee.due?.toLocaleString()}</td>
                <td style={{padding:".8rem 1.1rem"}}><Badge c={fee.status==="paid"?"green":fee.status==="overdue"?"red":"gold"}>{fee.status}</Badge></td>
                <td style={{padding:".8rem 1.1rem"}}>
                  {fee.due>0&&<div style={{display:"flex",gap:".4rem"}}>
                    <Btn v="glass" sm onClick={()=>{setPay(fee);setPA("");}}>💰 Collect</Btn>
                    <Btn v="glass" sm onClick={()=>setT({msg:`Reminder sent to ${fee.name}'s parent`,type:"info"})}>📱</Btn>
                  </div>}
                </td>
              </tr>
            ))}
            {fees.length===0&&<tr><td colSpan={7} style={{padding:"3rem",textAlign:"center",color:D.t3}}>No fee records yet →</td></tr>}
          </tbody>
        </table>
      </div>
      <Modal open={!!payDlg} onClose={()=>setPay(null)} title={`Record Payment — ${payDlg?.name}`}>
        {payDlg&&<div style={{display:"flex",flexDirection:"column",gap:".9rem"}}>
          <div style={{background:"rgba(0,0,0,.06)",padding:"1rem",borderRadius:10,fontSize:".84rem",display:"flex",gap:"1.5rem",flexWrap:"wrap",color:D.t1}}>
            <span>Total: <strong>₹{payDlg.total?.toLocaleString()}</strong></span>
            <span style={{color:D.green}}>Paid: <strong>₹{payDlg.paid?.toLocaleString()}</strong></span>
            <span style={{color:D.red}}>Due: <strong>₹{payDlg.due?.toLocaleString()}</strong></span>
          </div>
          <Inp label="Payment Amount (₹)" value={payAmt} onChange={setPA} type="number" placeholder={payDlg.due?.toString()}/>
          <div style={{display:"flex",gap:".7rem",justifyContent:"flex-end"}}>
            <Btn v="ghost" onClick={()=>setPay(null)}>Cancel</Btn>
            <Btn v="gold" onClick={()=>{const amt=parseFloat(payAmt);if(!amt)return;save(fees.map(x=>x.id===payDlg.id?{...x,paid:Math.min(x.total,x.paid+amt),due:Math.max(0,x.due-amt),status:x.paid+amt>=x.total?"paid":"pending"}:x));setPay(null);setT({msg:"Payment recorded successfully"});}}>Record Payment</Btn>
          </div>
        </div>}
      </Modal>
      <Modal open={addDlg} onClose={()=>setAdd(false)} title="Add Fee Record">
        <div style={{display:"flex",flexDirection:"column",gap:".9rem"}}>
          <Inp label="Student Name" value={f.name} onChange={v=>setF({...f,name:v})} placeholder="Full name"/>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:".8rem"}}>
            <Inp label="Class" as="select" value={f.cls} onChange={v=>setF({...f,cls:v})} opts={["6A","7A","8A","9A","9B","10A","10B"].map(c=>({v:c,l:`Class ${c}`}))}/>
            <Inp label="Annual Fee (₹)" value={f.total} onChange={v=>setF({...f,total:v})} type="number" placeholder="45000"/>
          </div>
          <div style={{display:"flex",gap:".7rem",justifyContent:"flex-end"}}>
            <Btn v="ghost" onClick={()=>setAdd(false)}>Cancel</Btn>
            <Btn v="gold" onClick={()=>{if(!f.name||!f.total)return;const amt=parseInt(f.total);save([...fees,{id:"f"+Date.now(),...f,total:amt,paid:0,due:amt,status:"pending"}]);setAdd(false);setT({msg:"Fee record added"});setF({name:"",cls:"10A",total:""});}}>Add Record</Btn>
          </div>
        </div>
      </Modal>
    </div>
  );
};

const PgBus = ({school}) => {
  const [buses,save] = useD2(school.id,"buses");
  const [sel,setSel] = useState(null);
  const [dlg,setDlg] = useState(false);
  const [tick,setTk] = useState(0);
  const [toast,setT] = useState(null);
  const [f,setF]     = useState({num:"",route:"",driver:"",count:"",status:"active",stops:""});

  // Bus active windows: Morning 7:00 AM – 8:30 AM | Evening 4:30 PM – 6:00 PM
  const BUS_WINDOWS = [
    {label:"Morning",start:"07:00",end:"08:30",icon:"🌅"},
    {label:"Evening",start:"16:30",end:"18:00",icon:"🌆"},
  ];
  const isInWindow = () => {
    const now = new Date();
    const hhmm = now.getHours()*60 + now.getMinutes();
    return BUS_WINDOWS.some(w=>{
      const [sh,sm]=w.start.split(":").map(Number);
      const [eh,em]=w.end.split(":").map(Number);
      return hhmm>=sh*60+sm && hhmm<=eh*60+em;
    });
  };
  const getActiveWindow = () => {
    const now = new Date();
    const hhmm = now.getHours()*60 + now.getMinutes();
    return BUS_WINDOWS.find(w=>{
      const [sh,sm]=w.start.split(":").map(Number);
      const [eh,em]=w.end.split(":").map(Number);
      return hhmm>=sh*60+sm && hhmm<=eh*60+em;
    });
  };
  const getNextWindow = () => {
    const now = new Date();
    const hhmm = now.getHours()*60 + now.getMinutes();
    const upcoming = BUS_WINDOWS.find(w=>{
      const [sh,sm]=w.start.split(":").map(Number);
      return sh*60+sm > hhmm;
    });
    return upcoming || BUS_WINDOWS[0];
  };
  const busActive = isInWindow();
  const activeWindow = getActiveWindow();
  const nextWindow = getNextWindow();

  useEffect(()=>{if(buses.length&&!sel)setSel(buses[0]);},[buses]);
  // Only update GPS tick during active bus windows
  useEffect(()=>{
    if(!busActive) return;
    const t=setInterval(()=>setTk(x=>x+1),3000);
    return()=>clearInterval(t);
  },[busActive]);
  const getStop = b=>(tick+(b.num||"B").charCodeAt(0))%Math.max(1,(b.stops||[]).length);

  return (
    <div className="pin">
      {toast&&<Toast msg={toast.msg} type={toast.type} onDone={()=>setT(null)}/>}
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",flexWrap:"wrap",gap:"1rem",marginBottom:"1.75rem"}}>
        <SH tag="GPS Live" title="Bus Tracking" sub="Morning 7:00–8:30 AM · Evening 4:30–6:00 PM"/>
        <Btn v="gold" onClick={()=>setDlg(true)}>+ Add Bus</Btn>
      </div>

      {/* Bus Window Status Banner */}
      <div style={{padding:"1rem 1.4rem",borderRadius:12,marginBottom:"1.5rem",display:"flex",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:"1rem",
        background:busActive?"rgba(16,217,160,.06)":"rgba(0,0,0,.04)",
        border:`1px solid ${busActive?"rgba(16,217,160,.2)":"rgba(0,0,0,.1)"}`}}>
        <div style={{display:"flex",alignItems:"center",gap:".9rem"}}>
          <div style={{width:10,height:10,borderRadius:"50%",background:busActive?D.green:D.t3,animation:busActive?"pulse 2s infinite":"none",flexShrink:0}}/>
          <div>
            <div style={{fontFamily:"'Playfair Display',serif",fontWeight:700,fontSize:".95rem",color:busActive?D.green:D.t1}}>
              {busActive?`${activeWindow?.icon} ${activeWindow?.label} Route Active`:"🚌 Buses Not Running Right Now"}
            </div>
            <div style={{fontSize:".78rem",color:D.t2,marginTop:".15rem"}}>
              {busActive
                ?`GPS live until ${activeWindow?.end} · Updates every 3 seconds`
                :`Next: ${nextWindow?.icon} ${nextWindow?.label} window at ${nextWindow?.start}`}
            </div>
          </div>
        </div>
        <div style={{display:"flex",gap:".6rem"}}>
          {BUS_WINDOWS.map(w=>{
            const now=new Date();const hhmm=now.getHours()*60+now.getMinutes();
            const[sh,sm]=w.start.split(":").map(Number);const[eh,em]=w.end.split(":").map(Number);
            const active=hhmm>=sh*60+sm&&hhmm<=eh*60+em;
            return(
              <div key={w.label} style={{padding:".4rem .85rem",borderRadius:8,fontSize:".76rem",fontWeight:600,
                background:active?"rgba(16,217,160,.1)":"rgba(0,0,0,.06)",
                border:`1px solid ${active?"rgba(16,217,160,.3)":D.b0}`,
                color:active?D.green:D.t3}}>
                {w.icon} {w.label}: {w.start}–{w.end}
              </div>
            );
          })}
        </div>
      </div>
      {buses.length===0
        ?<Card style={{textAlign:"center",padding:"4rem"}}>
          <div style={{fontSize:"2.5rem",marginBottom:"1rem"}}>🚌</div>
          <div style={{color:D.t2,fontFamily:"'Playfair Display',serif",fontSize:"1rem",marginBottom:"1.5rem"}}>No buses configured yet</div>
          <Btn v="gold" onClick={()=>setDlg(true)}>+ Add First Bus</Btn>
        </Card>
        :(
          <div style={{display:"grid",gridTemplateColumns:"1fr 2fr",gap:"1.25rem"}}>
            <div style={{display:"flex",flexDirection:"column",gap:".8rem"}}>
              {buses.map(b=>(
                <div key={b.id} onClick={()=>setSel(b)}
                  style={{background:"rgba(255,255,255,.7)",border:`1.5px solid ${sel?.id===b.id?D.bC:D.b0}`,borderRadius:12,padding:"1.1rem",cursor:"pointer",transition:"all .2s"}}
                  onMouseEnter={e=>e.currentTarget.style.borderColor=D.bC}
                  onMouseLeave={e=>e.currentTarget.style.borderColor=sel?.id===b.id?D.bC:D.b0}>
                  <div style={{display:"flex",justifyContent:"space-between",marginBottom:".4rem"}}>
                    <span style={{fontFamily:"'Playfair Display',serif",fontWeight:700,color:D.t0}}>Bus {b.num}</span>
                    <Badge c={b.status==="active"?"green":"gray"} dot>{b.status}</Badge>
                  </div>
                  <div style={{fontSize:".74rem",color:D.t2}}>{b.route}</div>
                  <div style={{fontSize:".72rem",color:D.t3,marginTop:".2rem"}}>{b.driver} · {b.count} students</div>
                  <button onClick={e=>{e.stopPropagation();const nb=buses.filter(x=>x.id!==b.id);save(nb);if(sel?.id===b.id)setSel(nb[0]||null);setT({msg:"Bus removed"});}}
                    style={{marginTop:".55rem",fontSize:".63rem",color:D.red,background:"none",border:"none",cursor:"pointer",transition:"opacity .2s"}}
                    onMouseEnter={e=>e.currentTarget.style.opacity=".6"} onMouseLeave={e=>e.currentTarget.style.opacity="1"}>Remove →</button>
                </div>
              ))}
            </div>
            {sel&&(
              <Card>
                <div style={{display:"flex",justifyContent:"space-between",marginBottom:"1.3rem"}}>
                  <div><div style={{fontFamily:"'Playfair Display',serif",fontSize:"1.3rem",fontWeight:800,color:D.t0,letterSpacing:"-.02em"}}>Bus {sel.num}</div><div style={{fontSize:".76rem",color:D.t2,marginTop:".15rem"}}>{sel.route}</div></div>
                  <div style={{textAlign:"right"}}><Badge c={sel.status==="active"?"green":"gray"} dot>{sel.status}</Badge><div style={{fontSize:".66rem",color:D.t3,marginTop:".3rem"}}>Updated {tick%30}s ago</div></div>
                </div>
                <div style={{background:"rgba(255,255,255,.5)",border:`1px solid ${D.b0}`,borderRadius:10,padding:"1.2rem",marginBottom:"1.2rem"}}>
                  <div style={{fontSize:".62rem",letterSpacing:".16em",textTransform:"uppercase",color:D.cyan,marginBottom:".9rem",fontWeight:600}}>Live Route</div>
                  {(sel.stops||[]).map((stop,i)=>{
                    const cur=getStop(sel);const done=i<cur;const active=i===cur;
                    return(
                      <div key={stop}>
                        <div style={{display:"flex",alignItems:"center",gap:".75rem"}}>
                          <div style={{width:10,height:10,borderRadius:"50%",background:done?D.green:active?D.gold:D.b1,flexShrink:0,transition:"background .5s",boxShadow:active?`0 0 14px ${D.gold}`:"none"}}/>
                          <span style={{fontSize:".8rem",color:active?D.t0:D.t2,fontWeight:active?600:400}}>{stop}</span>
                          {done&&<span style={{fontSize:".68rem",color:D.green}}>✓</span>}
                          {active&&sel.status==="active"&&<Badge c="gold" dot>Here Now</Badge>}
                        </div>
                        {i<sel.stops.length-1&&<div style={{width:1,height:14,background:D.b0,marginLeft:4.5,marginTop:2}}/>}
                      </div>
                    );
                  })}
                </div>
                <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:"1rem",textAlign:"center",marginBottom:"1.2rem"}}>
                  {[["🚗","Driver",sel.driver],["👨‍🎓","Students",sel.count],["⏱️","ETA",`~${(getStop(sel)+1)*5} min`]].map(([i,l,v])=>(
                    <div key={l} style={{background:"rgba(255,255,255,.5)",padding:".85rem .5rem",border:`1px solid ${D.b0}`,borderRadius:9}}>
                      <div style={{fontSize:".95rem",marginBottom:".25rem"}}>{i}</div>
                      <div style={{fontFamily:"'Playfair Display',serif",fontSize:".9rem",fontWeight:700,color:D.t0}}>{v}</div>
                      <div style={{fontSize:".66rem",color:D.t3,marginTop:".15rem"}}>{l}</div>
                    </div>
                  ))}
                </div>

                {/* ── GOOGLE MAPS LIVE LINK ── */}
                <div style={{borderTop:`1px solid ${D.b0}`,paddingTop:"1.2rem"}}>
                  <div style={{fontSize:".63rem",letterSpacing:".16em",textTransform:"uppercase",color:D.green,marginBottom:".8rem",fontWeight:600,display:"flex",alignItems:"center",gap:".4rem"}}>
                    <span style={{width:6,height:6,borderRadius:"50%",background:D.green,animation:"pulse 2s infinite"}}/>
                    🗺️ Google Maps Live Location
                  </div>

                  {sel.mapsLink?(
                    <div>
                      {/* Live map embed */}
                      <div style={{borderRadius:10,overflow:"hidden",border:"1px solid rgba(0,0,0,.1)",marginBottom:"1rem",position:"relative",paddingBottom:"56.25%",height:0}}>
                        <iframe
                          src={`https://maps.google.com/maps?q=${encodeURIComponent(sel.mapsLink)}&output=embed`}
                          style={{position:"absolute",top:0,left:0,width:"100%",height:"100%",border:"none"}}
                          allowFullScreen
                          loading="lazy"
                          title="Bus Live Location"
                        />
                      </div>
                      <div style={{display:"flex",gap:".6rem"}}>
                        <Btn v="green" full onClick={()=>window.open(sel.mapsLink,"_blank")} style={{flex:2}}>
                          📍 Open Live Location
                        </Btn>
                        <Btn v="ghost" sm onClick={()=>{
                          const link=sel.mapsLink;
                          const msg=`🚌 Bus ${sel.num} Live Location:
${link}

Driver: ${sel.driver}
Students: ${sel.count}`;
                          navigator.clipboard?.writeText(msg);
                          setT({msg:"Location link copied! Share on WhatsApp"});
                        }}>📋 Copy</Btn>
                      </div>
                      <div style={{marginTop:".7rem",padding:".65rem .9rem",background:"rgba(45,155,111,.06)",border:"1px solid rgba(45,155,111,.15)",borderRadius:8,fontSize:".76rem",color:D.t2,lineHeight:1.6}}>
                        💡 Share this link on parent WhatsApp group — they see live bus location!
                      </div>
                    </div>
                  ):(
                    <div>
                      <div style={{padding:"1rem",background:"rgba(0,0,0,.04)",border:"1px solid rgba(0,0,0,.1)",borderRadius:9,marginBottom:".8rem",fontSize:".82rem",color:D.t2,lineHeight:1.75}}>
                        <strong style={{color:D.t1}}>How to share live location:</strong><br/>
                        1. Driver opens <strong>Google Maps</strong> on phone<br/>
                        2. Tap profile → <strong>Location Sharing</strong><br/>
                        3. Tap <strong>New Share</strong> → Select duration<br/>
                        4. Tap <strong>Copy link</strong><br/>
                        5. Paste that link below 👇
                      </div>
                      <div style={{display:"flex",gap:".7rem"}}>
                        <input
                          placeholder="Paste driver's Google Maps live link here..."
                          style={{flex:1,background:"#fff",border:"1px solid rgba(0,0,0,.15)",borderRadius:9,padding:".7rem 1rem",fontSize:".82rem",color:D.t1,outline:"none"}}
                          onFocus={e=>e.target.style.borderColor="rgba(45,155,111,.5)"}
                          onBlur={e=>e.target.style.borderColor="rgba(0,0,0,.15)"}
                          onPaste={e=>{
                            const link=e.clipboardData.getData("text");
                            const nb=buses.map(b=>b.id===sel.id?{...b,mapsLink:link}:b);
                            save(nb);setSel({...sel,mapsLink:link});
                            setT({msg:"✅ Live location linked! Parents can now track bus."});
                          }}
                          onChange={e=>{
                            const link=e.target.value;
                            if(link.includes("maps.google")||link.includes("goo.gl")||link.includes("maps.app")){
                              const nb=buses.map(b=>b.id===sel.id?{...b,mapsLink:link}:b);
                              save(nb);setSel({...sel,mapsLink:link});
                              setT({msg:"✅ Live location linked!"});
                            }
                          }}
                        />
                        <Btn v="green" sm onClick={()=>setT({msg:"Paste the Google Maps link in the box",type:"info"})}>Save</Btn>
                      </div>
                    </div>
                  )}

                  {sel.mapsLink&&(
                    <button onClick={()=>{
                      const nb=buses.map(b=>b.id===sel.id?{...b,mapsLink:""}:b);
                      save(nb);setSel({...sel,mapsLink:""});
                      setT({msg:"Location link removed"});
                    }} style={{marginTop:".6rem",fontSize:".72rem",color:D.t3,background:"none",border:"none",cursor:"pointer"}}>
                      Remove link →
                    </button>
                  )}
                </div>
              </Card>
            )}
          </div>
        )}
      <Modal open={dlg} onClose={()=>setDlg(false)} title="Add School Bus">
        <div style={{display:"flex",flexDirection:"column",gap:".9rem"}}>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:".8rem"}}>
            <Inp label="Bus Number" value={f.num} onChange={v=>setF({...f,num:v})} placeholder="B3"/>
            <Inp label="Route Name" value={f.route} onChange={v=>setF({...f,route:v})} placeholder="East Zone"/>
          </div>
          <Inp label="Driver Name" value={f.driver} onChange={v=>setF({...f,driver:v})} placeholder="Full name"/>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:".8rem"}}>
            <Inp label="No. of Students" value={f.count} onChange={v=>setF({...f,count:v})} type="number" placeholder="30"/>
            <Inp label="Status" as="select" value={f.status} onChange={v=>setF({...f,status:v})} opts={[{v:"active",l:"Active"},{v:"parked",l:"Parked"}]}/>
          </div>
          <Inp label="Stops (comma separated)" as="textarea" value={f.stops} onChange={v=>setF({...f,stops:v})} placeholder="School Gate, Sector 14, Green Park, Rohini" rows={2}/>
          <Inp label="Google Maps Live Link (optional)" value={f.mapsLink||""} onChange={v=>setF({...f,mapsLink:v})} placeholder="Paste driver's Google Maps share link"/>
          <div style={{fontSize:".76rem",color:"#9A8F82",marginTop:"-.4rem",lineHeight:1.6}}>Driver shares location from Google Maps → copy link → paste here</div>
          <div style={{display:"flex",gap:".7rem",justifyContent:"flex-end"}}>
            <Btn v="ghost" onClick={()=>setDlg(false)}>Cancel</Btn>
            <Btn v="gold" onClick={()=>{if(!f.num||!f.driver)return;const stops=f.stops.split(",").map(s=>s.trim()).filter(Boolean);const nb=[...buses,{...f,id:"b"+Date.now(),count:parseInt(f.count)||0,stops}];save(nb);if(!sel)setSel(nb[0]);setDlg(false);setT({msg:`Bus ${f.num} added! ${f.mapsLink?"Live location linked ✅":""}`});setF({num:"",route:"",driver:"",count:"",status:"active",stops:"",mapsLink:""});}}>Add Bus</Btn>
          </div>
        </div>
      </Modal>
    </div>
  );
};

const PgExams = ({school}) => {
  const [exams,save]   = useD2(school.id,"exams");
  const [gen,setGen]   = useState(false);
  const [prog,setPrg]  = useState(0);
  const [progMsg,setProgMsg] = useState("");
  const [prev,setPrev] = useState(null);
  const [toast,setT]   = useState(null);
  const [apiKey,setApiKey] = useState(S.g("openai_key",""));
  const [showKey,setShowKey] = useState(false);
  const [diff,setDiff] = useState("Medium");
  const [qtype,setQtype] = useState("Mixed");
  const [lang,setLang] = useState("English");
  const [f,setF] = useState({title:"",cls:"10A",sub:"Mathematics",marks:"80",qs:"5",topic:""});

  // ── REAL CLAUDE API CALL ──────────────────────────
  const generateWithGPT = async () => {
    const key = S.g("openai_key","")||apiKey;

    const prompt = `You are an experienced ${f.sub} teacher for Class ${f.cls} students in India following the ${school.board||"CBSE"} curriculum.

Generate a complete exam paper with EXACTLY ${f.qs} questions for:
- Subject: ${f.sub}
- Class: ${f.cls}
- Total Marks: ${f.marks}
- Difficulty: ${diff}
- Question Type: ${qtype}
- Language: ${lang}
${f.topic?`- Specific Topic: ${f.topic}`:""}

Rules:
- Each question must be unique and curriculum-aligned
- Questions should be appropriate for Class ${f.cls} level
- Mix of application and theory questions
- If Mixed type: include MCQ, short answer, and long answer
- Marks per question: ${Math.round(parseInt(f.marks)/parseInt(f.qs))} marks each
${lang==="Telugu"?"- Write questions in Telugu script":""}

Return ONLY a valid JSON array of question strings, no extra text, no markdown:
["Question 1 text here","Question 2 text here","Question 3 text here"]`;

    const res = await fetch("https://api.openai.com/v1/chat/completions",{
      method:"POST",
      headers:{"Content-Type":"application/json","Authorization":`Bearer ${key}`},
      body:JSON.stringify({
        model:"gpt-4o-mini",
        max_tokens:2000,
        temperature:0.8,
        messages:[
          {role:"system",content:"You are an expert school exam paper generator for Indian schools. Always return valid JSON arrays only."},
          {role:"user",content:prompt},
        ],
      }),
    });

    if(!res.ok){
      const err=await res.json();
      throw new Error(err.error?.message||"OpenAI API error");
    }

    const data = await res.json();
    const text = data.choices?.[0]?.message?.content||"[]";

    // Parse JSON from response
    const jsonMatch = text.match(/\[[\s\S]*\]/);
    if(!jsonMatch) throw new Error("Invalid response format");
    return JSON.parse(jsonMatch[0]);
  };

  // ── FALLBACK QUESTION BANK ────────────────────────
  const FALLBACK = {
    Mathematics:{
      Easy:["Find the HCF of 24 and 36.","Solve: 3x + 7 = 22.","Find the area of a rectangle with length 8cm and width 5cm.","What is 15% of 200?","Find the value of x: 2x − 4 = 10."],
      Medium:["Find the zeroes of p(x) = x² − 5x + 6 and verify the relationship between zeroes and coefficients.","Prove that √3 is irrational.","The sum of three consecutive integers is 51. Find the integers.","Solve: 2x + 3y = 11 and 2x − 4y = −24.","Find the 20th term of the AP: 3, 7, 11, 15…"],
      Hard:["A train travels 360 km at uniform speed. If speed increased by 5 km/h it takes 1 hr less. Find speed.","Prove that the tangent at any point of a circle is perpendicular to the radius.","A ladder 10m long reaches a window 8m above ground. Find distance of ladder foot from wall.","If α and β are zeroes of 2x²−5x+3, find the value of α²β + αβ².","Prove that √2 + √3 is irrational."],
    },
    Science:{
      Easy:["What is photosynthesis?","Name the three states of matter.","What is the chemical formula of water?","Define acceleration.","What is an atom?"],
      Medium:["Explain the process of photosynthesis with a labelled diagram.","State Newton's three laws of motion with one example each.","What is the difference between physical and chemical change? Give two examples each.","Describe the structure of a plant cell with a neat diagram.","Explain how vaccines work in the human immune system."],
      Hard:["Explain the carbon cycle with a diagram and its importance to life on Earth.","Derive the relationship between wavelength, frequency and speed of a wave.","Explain the process of nuclear fission with an example and its applications.","Describe the mechanism of reflex action with a labelled diagram of the reflex arc.","Explain the structure of DNA and its role in heredity."],
    },
    English:{
      Easy:["Write 5 sentences about your favourite season.","Fill in the blanks with correct articles (a, an, the).","Write the opposite of: happy, big, fast, dark, old.","Write a short paragraph about your school.","Change these sentences to past tense."],
      Medium:["Write a letter to the editor about rising air pollution in your city.","Analyse the central theme of the poem 'The Road Not Taken' by Robert Frost.","Identify and explain the literary devices used in the given passage.","Write a short story beginning with: 'It was a dark and stormy night…'","Compare and contrast the two main characters in the lesson you studied."],
      Hard:["Write a critical analysis of the theme of courage and sacrifice in the prose piece you studied.","Explain how the author uses imagery and symbolism to convey the central message.","Write a persuasive speech on 'Social media does more harm than good'.","Analyse the character development of the protagonist throughout the story.","Write a debate speech arguing for or against: 'Online education is better than classroom education'."],
    },
    "Social Studies":{
      Easy:["Name the capital of India.","What is democracy?","Name any three rivers of India.","What is a natural resource?","Who wrote the Indian Constitution?"],
      Medium:["What were the main causes of the First World War? Explain any four.","Describe the major landforms of India and their significance.","What is Federalism? How does it work in India with examples?","Explain the functions of the three organs of the Indian government.","What are natural resources? Classify them with examples."],
      Hard:["Analyse the impact of the French Revolution on the political development of Europe.","Explain the significance of the Indian National Movement and the role of Gandhiji.","How does globalisation affect developing countries? Discuss with examples.","Explain the structure and working of the Indian Parliament in detail.","Critically analyse the causes and consequences of the partition of India in 1947."],
    },
    Hindi:{
      Easy:["निम्नलिखित शब्दों के अर्थ लिखिए।","पाँच वाक्यों में अपने परिवार का वर्णन कीजिए।","विलोम शब्द लिखिए: बड़ा, अच्छा, दिन, सुख।","निम्नलिखित वाक्यों को शुद्ध कीजिए।","अपने प्रिय त्योहार पर पाँच वाक्य लिखिए।"],
      Medium:["मित्र को जन्मदिन की बधाई देते हुए पत्र लिखिए।","दिए गए गद्यांश का सारांश अपने शब्दों में लिखिए।","संधि-विच्छेद कीजिए और संधि का नाम बताइए।","निम्नलिखित मुहावरों का वाक्यों में प्रयोग कीजिए।","'पर्यावरण प्रदूषण' विषय पर अनुच्छेद लिखिए।"],
      Hard:["'बेटी बचाओ बेटी पढ़ाओ' विषय पर निबंध लिखिए।","दिए गए काव्यांश की सप्रसंग व्याख्या कीजिए।","समाचार-पत्र के संपादक को जल संकट की समस्या बताते हुए पत्र लिखिए।","'विज्ञान: वरदान या अभिशाप' विषय पर दो पक्षों में वाद-विवाद लिखिए।","कहानी का सारांश लिखते हुए मुख्य पात्र का चरित्र-चित्रण कीजिए।"],
    },
    Telugu:{
      Easy:["మీ ఇంటి గురించి ఐదు వాక్యాలు రాయండి.","క్రింది పదాలకు వ్యతిరేక పదాలు రాయండి.","మీకు ఇష్టమైన పండుగ గురించి రాయండి.","క్రింది వాక్యాలు చదివి సమాధానాలు రాయండి.","మీ పాఠశాల గురించి వర్ణించండి."],
      Medium:["తెలుగు భాష ప్రాముఖ్యత గురించి వ్యాసం రాయండి.","ఒక గొప్ప తెలుగు కవి జీవిత చరిత్ర రాయండి.","ప్రకృతి అందాల గురించి కవిత రాయండి.","మీ జీవితంలో మీకు ఇష్టమైన వ్యక్తి గురించి రాయండి.","'పర్యావరణ కాలుష్యం' అనే అంశంపై వ్యాసం రాయండి."],
      Hard:["తెలుగు సాహిత్యంలో భక్తి కవిత్వం ప్రభావాన్ని వివరించండి.","దిగువ గద్యభాగాన్ని చదివి సమగ్రమైన సారాంశం రాయండి.","'విద్య ఒక వరం' అనే విషయంపై వాద వివాద రచన రాయండి.","తెలంగాణ చరిత్రలో ముఖ్యమైన సంఘటనలు వర్ణించండి.","మీకు ఇష్టమైన తెలుగు నాటకం గురించి విమర్శనాత్మకంగా రాయండి."],
    },
  };

  const getFallback = () => {
    const bank = FALLBACK[f.sub]||FALLBACK.Mathematics;
    const pool = bank[diff]||bank.Medium;
    // Shuffle and pick
    return [...pool].sort(()=>Math.random()-.5).slice(0,parseInt(f.qs));
  };

  // ── MAIN GENERATE FUNCTION ────────────────────────
  const generate = async () => {
    if(!f.title){setT({msg:"Enter exam title to proceed",type:"err"});return;}
    setGen(true);setPrg(0);

    const steps=[
      {p:15,msg:"Connecting to GPT-4o Mini…"},
      {p:35,msg:`Reading ${f.sub} curriculum for Class ${f.cls}…`},
      {p:55,msg:"Generating unique questions…"},
      {p:75,msg:"Calibrating difficulty level…"},
      {p:90,msg:"Formatting exam paper…"},
    ];

    // Animate progress
    let stepIdx=0;
    const iv=setInterval(()=>{
      if(stepIdx<steps.length){
        setPrg(steps[stepIdx].p);
        setProgMsg(steps[stepIdx].msg);
        stepIdx++;
      }
    },800);

    try {
      let qList;
      const key=S.g("openai_key","")||apiKey;

      if(key){
        // Real Claude API
        setProgMsg("Asking Claude AI to generate questions…");
        qList = await generateWithGPT();
      } else {
        // Smart fallback — randomised question bank
        await new Promise(r=>setTimeout(r,3500));
        qList = getFallback();
      }

      clearInterval(iv);setPrg(100);setProgMsg("Done!");

      const ne={
        id:"e"+Date.now(),
        ...f,
        marks:parseInt(f.marks),
        qs:parseInt(f.qs),
        qList,
        diff,qtype,lang,
        date:new Date().toLocaleDateString("en-IN"),
        status:"draft",
        aiGenerated:!!key,
      };
      save([ne,...exams]);
      setTimeout(()=>{setGen(false);setPrg(0);setProgMsg("");setPrev(ne);},500);
      setT({msg:key?"✦ GPT-4o Mini generated your exam paper!":"Exam paper generated! Add Claude API key for unique questions every time."});
    } catch(err){
      clearInterval(iv);
      // Fallback on error
      const qList=getFallback();
      const ne={id:"e"+Date.now(),...f,marks:parseInt(f.marks),qs:parseInt(f.qs),qList,diff,qtype,lang,date:new Date().toLocaleDateString("en-IN"),status:"draft",aiGenerated:false};
      save([ne,...exams]);
      setGen(false);setPrg(0);setProgMsg("");setPrev(ne);
      setT({msg:"Used question bank (Claude API error: "+err.message.slice(0,40)+")",type:"info"});
    }
  };

  const marksPerQ = Math.round(parseInt(f.marks||80)/parseInt(f.qs||5));

  return (
    <div className="pin">
      {toast&&<Toast msg={toast.msg} type={toast.type} onDone={()=>setT(null)}/>}
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",flexWrap:"wrap",gap:"1rem",marginBottom:"1.75rem"}}>
        <SH tag="GPT-4o Mini Powered" title="AI Exam Generator" sub="GPT-4o Mini generates unique questions at ultra-low cost — 75x cheaper than other AI"/>
        <div style={{display:"flex",gap:".6rem",alignItems:"center"}}>
          {S.g("openai_key","")
            ?<div style={{display:"flex",alignItems:"center",gap:".4rem",fontSize:".76rem",color:D.purp,background:"rgba(108,180,228,.1)",border:"1px solid rgba(108,180,228,.2)",padding:".3rem .8rem",borderRadius:20,fontWeight:600}}><span style={{width:6,height:6,borderRadius:"50%",background:D.purp}}/>GPT-4o Mini Connected</div>
            :<Btn v="purp" sm onClick={()=>setShowKey(true)}>✦ Connect GPT-4o Mini</Btn>}
        </div>
      </div>

      {/* API Key Setup */}
      {showKey&&(
        <Card style={{marginBottom:"1.5rem",border:"1px solid rgba(244,114,182,.25)"}}>
          <div style={{fontSize:".63rem",letterSpacing:".16em",textTransform:"uppercase",color:D.purp,marginBottom:"1rem",fontWeight:600}}>✦ Connect OpenAI GPT-4o Mini</div>
          <div style={{padding:".8rem 1rem",background:"rgba(244,114,182,.06)",border:"1px solid rgba(108,180,228,.15)",borderRadius:9,fontSize:".82rem",color:D.t2,marginBottom:"1rem",lineHeight:1.65}}>
            With GPT-4o Mini: every exam is <strong style={{color:D.t1}}>100% unique</strong> — never repeats questions, perfectly aligned to CBSE/ICSE syllabus.<br/>
            Without it: uses smart randomised question bank (still good, just not AI-generated).
          </div>
          <div style={{display:"flex",gap:".8rem"}}>
            <Inp label="OpenAI API Key (starts with sk-)" value={apiKey} onChange={setApiKey} placeholder="sk-XXXXXXXXXXXXXXXXXX" style={{flex:1}}/>
            <Btn v="purp" onClick={()=>{if(!apiKey){setT({msg:"Enter API key",type:"err"});return;}S.s("openai_key",apiKey);setShowKey(false);setT({msg:"✦ GPT-4o Mini connected! Generating unique exams at ultra-low cost."});}} style={{alignSelf:"flex-end"}}>Connect</Btn>
          </div>
          <div style={{marginTop:".8rem",fontSize:".76rem",color:D.t3}}>
            Get free key: <span style={{color:D.purp}}>platform.openai.com → API Keys → Create Key</span> · Free $5 credits on signup
          </div>
          <Btn v="ghost" sm onClick={()=>setShowKey(false)} style={{marginTop:".8rem"}}>Skip — use question bank</Btn>

          {/* Cost breakdown */}
          <div style={{marginTop:"1rem",padding:".9rem 1rem",background:"rgba(16,217,160,.04)",border:"1px solid rgba(16,217,160,.15)",borderRadius:9,fontSize:".78rem",color:D.t2,lineHeight:1.8}}>
            <div style={{color:D.green,fontWeight:600,marginBottom:".4rem"}}>💰 GPT-4o Mini Cost at Scale</div>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:".5rem"}}>
              <div>1 exam paper = <strong style={{color:D.t1}}>$0.0002</strong></div>
              <div>= <strong style={{color:D.t1}}>₹0.017</strong> per paper</div>
              <div>100 schools × 5 papers/day</div>
              <div>= <strong style={{color:D.green}}>₹8.50/day total</strong></div>
              <div>Charge schools ₹10/paper</div>
              <div>= <strong style={{color:D.gold}}>₹5,000/day profit</strong></div>
            </div>
          </div>
        </Card>
      )}

      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"1.25rem"}}>
        <div>
          <Card style={{marginBottom:"1rem"}}>
            <div style={{display:"flex",flexDirection:"column",gap:".9rem"}}>
              <Inp label="Exam Title" value={f.title} onChange={v=>setF({...f,title:v})} placeholder="e.g. Mid-Term Mathematics 2025"/>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:".8rem"}}>
                <Inp label="Class" as="select" value={f.cls} onChange={v=>setF({...f,cls:v})} opts={["6A","6B","7A","7B","8A","8B","9A","9B","10A","10B","11A","12A"].map(c=>({v:c,l:`Class ${c}`}))}/>
                <Inp label="Subject" as="select" value={f.sub} onChange={v=>setF({...f,sub:v})} opts={["Mathematics","Science","English","Social Studies","Hindi","Telugu","Physics","Chemistry","Biology","Computer Science"].map(s=>({v:s,l:s}))}/>
              </div>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:".8rem"}}>
                <Inp label="Total Marks" value={f.marks} onChange={v=>setF({...f,marks:v})} type="number" placeholder="80"/>
                <Inp label="No. of Questions" value={f.qs} onChange={v=>setF({...f,qs:String(Math.min(15,Math.max(1,parseInt(v)||1)))})} type="number" placeholder="5"/>
              </div>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:".8rem"}}>
                <Inp label="Difficulty" as="select" value={diff} onChange={setDiff} opts={["Easy","Medium","Hard","Mixed"].map(v=>({v,l:v}))}/>
                <Inp label="Q Type" as="select" value={qtype} onChange={setQtype} opts={["MCQ","Short Answer","Long Answer","Mixed"].map(v=>({v,l:v}))}/>
                <Inp label="Language" as="select" value={lang} onChange={setLang} opts={["English","Telugu","Hindi","Bilingual"].map(v=>({v,l:v}))}/>
              </div>
              <Inp label="Specific Topic (optional)" value={f.topic} onChange={v=>setF({...f,topic:v})} placeholder="e.g. Quadratic Equations, Photosynthesis…"/>

              {/* Marks preview */}
              <div style={{padding:".7rem 1rem",background:"rgba(244,114,182,.05)",border:"1px solid rgba(108,180,228,.12)",borderRadius:9,fontSize:".78rem",color:D.t2,display:"flex",justifyContent:"space-between"}}>
                <span>{f.qs} questions × {marksPerQ} marks = <strong style={{color:D.purp}}>{f.marks} total marks</strong></span>
                <span style={{color:S.g("openai_key","")?"#a78bfa":D.t3}}>{S.g("openai_key","")?"✦ GPT-4o Mini":"📚 Question Bank"}</span>
              </div>

              {gen?(
                <div style={{padding:".9rem",background:"rgba(244,114,182,.05)",border:"1px solid rgba(108,180,228,.2)",borderRadius:10}}>
                  <div style={{display:"flex",justifyContent:"space-between",fontSize:".76rem",marginBottom:".6rem"}}>
                    <span style={{color:D.purp,animation:"pulse 1.5s infinite"}}>{progMsg||"Generating…"}</span>
                    <span style={{color:D.purp,fontWeight:700}}>{prog}%</span>
                  </div>
                  <div style={{height:4,background:"rgba(0,0,0,.08)",borderRadius:2,overflow:"hidden"}}>
                    <div style={{width:`${prog}%`,height:"100%",background:D.purpG,borderRadius:2,transition:"width .6s ease"}}/>
                  </div>
                  <div style={{fontSize:".68rem",color:D.t3,marginTop:".45rem",display:"flex",alignItems:"center",gap:".4rem"}}>
                    <Spin/>{S.g("openai_key","")?"GPT-4o Mini generating questions…":"Selecting questions from bank…"}
                  </div>
                </div>
              ):(
                <Btn v="purp" onClick={generate} full style={{padding:".9rem",fontFamily:"'Playfair Display',serif",fontWeight:700,fontSize:"1rem"}}>
                  ✦ Generate AI Exam Paper
                </Btn>
              )}
            </div>
          </Card>

          {/* Previous exams */}
          <div style={{display:"flex",flexDirection:"column",gap:".45rem"}}>
            {exams.map(e=>(
              <div key={e.id} onClick={()=>setPrev(e)}
                style={{padding:".85rem 1.1rem",background:prev?.id===e.id?"rgba(244,114,182,.07)":"rgba(255,255,255,.7)",border:`1px solid ${prev?.id===e.id?"rgba(244,114,182,.35)":D.b0}`,borderRadius:10,cursor:"pointer",display:"flex",justifyContent:"space-between",alignItems:"center",transition:"all .2s"}}
                onMouseEnter={el=>el.currentTarget.style.borderColor="rgba(244,114,182,.25)"}
                onMouseLeave={el=>el.currentTarget.style.borderColor=prev?.id===e.id?"rgba(244,114,182,.35)":D.b0}>
                <div>
                  <div style={{display:"flex",alignItems:"center",gap:".5rem"}}>
                    <span style={{fontSize:".84rem",fontWeight:500,color:D.t1}}>{e.title}</span>
                    {e.aiGenerated&&<span style={{fontSize:".58rem",color:D.purp,background:"rgba(108,180,228,.12)",border:"1px solid rgba(108,180,228,.2)",padding:".1rem .5rem",borderRadius:10,fontWeight:600}}>✦ AI</span>}
                  </div>
                  <div style={{fontSize:".68rem",color:D.t3,marginTop:".2rem"}}>Class {e.cls} · {e.sub} · {e.marks}M · {e.diff||"Medium"} · {e.date}</div>
                </div>
                <Badge c={e.status==="published"?"green":"gold"}>{e.status}</Badge>
              </div>
            ))}
            {exams.length===0&&<div style={{textAlign:"center",padding:"1.5rem",color:D.t3,fontSize:".82rem"}}>No exams yet. Generate your first paper →</div>}
          </div>
        </div>

        {/* Preview panel */}
        <Card style={{display:"flex",flexDirection:"column",minHeight:400}}>
          {prev?(
            <>
              <div style={{borderBottom:`1px solid ${D.b0}`,paddingBottom:"1rem",marginBottom:"1rem"}}>
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start"}}>
                  <div>
                    <div style={{fontFamily:"'Playfair Display',serif",fontSize:"1.05rem",fontWeight:700,color:D.t0}}>{prev.title}</div>
                    <div style={{fontSize:".7rem",color:D.t3,marginTop:".25rem"}}>{school.name} · Class {prev.cls} · {prev.sub} · {prev.marks} Marks · 3 Hours</div>
                  </div>
                  {prev.aiGenerated&&<div style={{fontSize:".64rem",color:D.purp,background:"rgba(108,180,228,.1)",border:"1px solid rgba(108,180,228,.2)",padding:".25rem .7rem",borderRadius:20,fontWeight:600,flexShrink:0}}>✦ Claude AI</div>}
                </div>
                <div style={{display:"flex",gap:".5rem",marginTop:".6rem",flexWrap:"wrap"}}>
                  {[prev.diff,prev.qtype,prev.lang].filter(Boolean).map(tag=>(
                    <Badge key={tag} c="purp">{tag}</Badge>
                  ))}
                </div>
              </div>

              {/* Instructions */}
              <div style={{padding:".7rem .9rem",background:"rgba(255,255,255,.5)",border:`1px solid ${D.b0}`,borderRadius:8,fontSize:".76rem",color:D.t2,marginBottom:"1rem",lineHeight:1.65}}>
                <strong style={{color:D.t1}}>General Instructions:</strong> All questions are compulsory. Marks are indicated against each question. Write neatly and clearly.
              </div>

              <div style={{flex:1,overflowY:"auto"}}>
                {(prev.qList||[]).map((q,i)=>(
                  <div key={i} style={{padding:".8rem 0",borderBottom:`1px solid ${D.b0}`,display:"flex",gap:".65rem",alignItems:"flex-start"}}>
                    <span style={{color:D.purp,fontWeight:800,flexShrink:0,fontFamily:"'Playfair Display',serif",minWidth:28}}>Q{i+1}.</span>
                    <span style={{fontSize:".84rem",lineHeight:1.7,color:D.t1,flex:1}}>{q}</span>
                    <span style={{fontSize:".7rem",color:D.t3,flexShrink:0,background:"rgba(0,0,0,.06)",padding:".2rem .55rem",borderRadius:6,whiteSpace:"nowrap"}}>[{marksPerQ}M]</span>
                  </div>
                ))}
              </div>

              <div style={{display:"flex",gap:".7rem",marginTop:"1rem",paddingTop:"1rem",borderTop:`1px solid ${D.b0}`}}>
                <Btn v="gold" style={{flex:1}} onClick={()=>{save(exams.map(e=>e.id===prev.id?{...e,status:"published"}:e));setPrev({...prev,status:"published"});setT({msg:"✅ Published! Visible in Parent Portal."});}}>
                  {prev.status==="published"?"✅ Published":"📤 Publish to Portal"}
                </Btn>
                <Btn v="ghost" style={{flex:1}} onClick={()=>window.print()}>🖨️ Print</Btn>
                <Btn v="ghost" sm onClick={()=>{save(exams.filter(e=>e.id!==prev.id));setPrev(null);setT({msg:"Deleted"});}}>🗑️</Btn>
              </div>
            </>
          ):(
            <div style={{display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",flex:1,textAlign:"center",padding:"2rem"}}>
              <div style={{fontSize:"3rem",marginBottom:"1rem",opacity:.3}}>✦</div>
              <div style={{fontFamily:"'Playfair Display',serif",color:D.t2,fontSize:"1.05rem",fontWeight:700,marginBottom:".5rem"}}>Your exam paper appears here</div>
              <div style={{fontSize:".8rem",color:D.t3,lineHeight:1.7}}>
                Configure on the left and click<br/>Generate AI Exam Paper
              </div>
              {!S.g("openai_key","")&&(
                <div style={{marginTop:"1.5rem",padding:"1rem 1.2rem",background:"rgba(244,114,182,.06)",border:"1px solid rgba(108,180,228,.2)",borderRadius:10,fontSize:".8rem",color:D.t2,lineHeight:1.65}}>
                  💡 <strong style={{color:D.purp}}>Pro tip:</strong> Connect GPT-4o Mini above for questions that are 100% unique every time — never repeating across any school on the platform.
                </div>
              )}
            </div>
          )}
        </Card>
      </div>
    </div>
  );
};

const PgMarks = ({school}) => {
  const [marks,save] = useD2(school.id,"marks");
  const [dlg,setDlg] = useState(false);
  const [toast,setT] = useState(null);
  const [f,setF]     = useState({name:"",cls:"10A",math:"",sci:"",eng:"",hindi:"",ss:""});
  const add = () => {
    if(!f.name)return;
    const scores=[+f.math,+f.sci,+f.eng,+f.hindi,+f.ss];
    const total=scores.reduce((a,b)=>a+b,0);
    const pct=+(total/400*100).toFixed(1);
    const grade=pct>=90?"A+":pct>=80?"A":pct>=70?"B+":pct>=60?"B":"C";
    save([...marks,{id:"m"+Date.now(),...f,math:+f.math,sci:+f.sci,eng:+f.eng,hindi:+f.hindi,ss:+f.ss,total,pct,grade}]);
    setDlg(false);setT({msg:"Marks saved and visible in Parent Portal"});
    setF({name:"",cls:"10A",math:"",sci:"",eng:"",hindi:"",ss:""});
  };
  const sorted=[...marks].sort((a,b)=>b.pct-a.pct);
  return (
    <div className="pin">
      {toast&&<Toast msg={toast.msg} type={toast.type} onDone={()=>setT(null)}/>}
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",flexWrap:"wrap",gap:"1rem",marginBottom:"1.75rem"}}>
        <SH tag="Academics" title="Marks & Results" sub={`${marks.length} results · Visible in Parent Portal`}/>
        <Btn v="gold" onClick={()=>setDlg(true)}>+ Enter Marks</Btn>
      </div>
      <div style={{background:"rgba(255,255,255,.7)",border:`1px solid ${D.b0}`,borderRadius:14,overflow:"hidden"}}>
        <table style={{width:"100%",borderCollapse:"collapse"}}>
          <thead><tr style={{background:"rgba(0,0,0,.03)"}}>
            {["Rank","Student","Class","Math","Science","English","Hindi","S.S.","Total %","Grade"].map(h=><th key={h} style={{padding:".8rem .9rem",textAlign:"left",fontSize:".62rem",letterSpacing:".1em",textTransform:"uppercase",color:D.t3,fontWeight:600,borderBottom:`1px solid ${D.b0}`}}>{h}</th>)}
          </tr></thead>
          <tbody>
            {sorted.map((m,i)=>(
              <tr key={m.id} style={{borderBottom:`1px solid ${D.b0}`,transition:"background .15s"}} onMouseEnter={e=>e.currentTarget.style.background="rgba(0,0,0,.03)"} onMouseLeave={e=>e.currentTarget.style.background="transparent"}>
                <td style={{padding:".8rem .9rem"}}><span style={{fontFamily:"'Playfair Display',serif",fontSize:".95rem",color:i===0?D.gold:i===1?D.t2:D.t3,fontWeight:i<2?700:400}}>#{i+1}</span></td>
                <td style={{padding:".8rem .9rem",fontSize:".84rem",fontWeight:500,color:D.t1}}>{m.name}</td>
                <td style={{padding:".8rem .9rem",fontSize:".78rem",color:D.t2}}>{m.cls}</td>
                {[m.math,m.sci,m.eng,m.hindi,m.ss].map((v,j)=><td key={j} style={{padding:".8rem .9rem",fontSize:".82rem",color:D.t1}}>{v}</td>)}
                <td style={{padding:".8rem .9rem",fontSize:".84rem",fontWeight:700,color:D.cyan,fontFamily:"'Playfair Display',serif"}}>{m.pct}%</td>
                <td style={{padding:".8rem .9rem"}}><Badge c={m.grade==="A+"?"gold":m.grade?.startsWith("A")?"green":"cyan"}>{m.grade}</Badge></td>
              </tr>
            ))}
            {marks.length===0&&<tr><td colSpan={10} style={{padding:"3rem",textAlign:"center",color:D.t3}}>No results entered yet →</td></tr>}
          </tbody>
        </table>
      </div>
      <Modal open={dlg} onClose={()=>setDlg(false)} title="Enter Student Marks">
        <div style={{display:"flex",flexDirection:"column",gap:".9rem"}}>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:".8rem"}}>
            <Inp label="Student Name" value={f.name} onChange={v=>setF({...f,name:v})} placeholder="Full name"/>
            <Inp label="Class" as="select" value={f.cls} onChange={v=>setF({...f,cls:v})} opts={["6A","7A","8A","9A","9B","10A","10B"].map(c=>({v:c,l:`Class ${c}`}))}/>
          </div>
          <div style={{padding:".6rem .9rem",background:"rgba(255,255,255,.5)",border:`1px solid ${D.b0}`,borderRadius:9,fontSize:".78rem",color:D.t2}}>
            Enter marks out of 80 for each subject
          </div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:".8rem"}}>
            {[["math","Mathematics"],["sci","Science"],["eng","English"],["hindi","Hindi"],["ss","Social Studies"]].map(([k,l])=>(
              <Inp key={k} label={l} value={f[k]} onChange={v=>setF({...f,[k]:v})} placeholder="0–80" type="number"/>
            ))}
          </div>
          <div style={{display:"flex",gap:".7rem",justifyContent:"flex-end"}}>
            <Btn v="ghost" onClick={()=>setDlg(false)}>Cancel</Btn>
            <Btn v="gold" onClick={add}>Save Marks</Btn>
          </div>
        </div>
      </Modal>
    </div>
  );
};

const PgAlerts = ({school}) => {
  const [alerts,save] = useD2(school.id,"alerts");
  const [students]    = useD2(school.id,"students");
  const [msg,setMsg]  = useState("");
  const [type,setType]= useState("General");
  const [sending,setSend] = useState(false);
  const [toast,setT]  = useState(null);

  const templates = [
    ["📵 Absence Alert",`Dear Parent,\n\nYour child was absent from ${school.name} today (${new Date().toLocaleDateString("en-IN")}).\n\nPlease ensure regular attendance.\n\nRegards,\nPrincipal ${school.principal}\n${school.name}`,"General"],
    ["💳 Fee Reminder",`Dear Parent,\n\nThis is a gentle reminder from ${school.name} regarding your child's pending school fees.\n\nKindly pay at the school office at the earliest to avoid any inconvenience.\n\nRegards,\nPrincipal ${school.principal}`,"Fee Reminder"],
    ["📅 PTM Notice",`Dear Parent,\n\n${school.name} cordially invites you for the Parent-Teacher Meeting (PTM).\n\n📅 Date: [Date]\n⏰ Time: 10:00 AM – 1:00 PM\n📍 Venue: School Auditorium\n\nYour presence is important for your child's academic progress.\n\nRegards,\nPrincipal ${school.principal}`,"PTM Notice"],
    ["🎉 Holiday Notice",`Dear Parent,\n\nThis is to inform you that ${school.name} will remain closed on [Date] on account of [Holiday Name].\n\nClasses will resume on [Next Working Day].\n\nRegards,\nPrincipal ${school.principal}`,"Holiday"],
    ["📝 Exam Schedule",`Dear Parent,\n\nThe upcoming examination schedule for ${school.name} is as follows:\n\n📅 Exam Dates: [Start Date] to [End Date]\n⏰ Timing: [Time]\n\nPlease ensure your child is well prepared.\n\nRegards,\nPrincipal ${school.principal}`,"Exam Schedule"],
  ];

  const send = () => {
    if(!msg){setT({msg:"Please type a message before sending",type:"err"});return;}
    setSend(true);
    setTimeout(()=>{
      save([{id:"a"+Date.now(),msg,type,recipients:students.length,status:"delivered",date:new Date().toLocaleString("en-IN")},...alerts]);
      setMsg("");setSend(false);
      setT({msg:`Alert sent to ${students.length} parents successfully`});
    },1800);
  };

  return (
    <div className="pin">
      {toast&&<Toast msg={toast.msg} type={toast.type} onDone={()=>setT(null)}/>}
      <SH tag="Communication" title="Parent Alerts" sub="Send instant alerts to all parents via SMS, WhatsApp & Email"/>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"1.25rem"}}>
        <div style={{display:"flex",flexDirection:"column",gap:"1rem"}}>
          <Card>
            <div style={{display:"flex",flexDirection:"column",gap:".9rem"}}>
              <Inp label="Alert Type" as="select" value={type} onChange={setType} opts={["General","Holiday","Fee Reminder","Event","Emergency","Exam Schedule","Result","PTM Notice"].map(v=>({v,l:v}))}/>
              <Inp label="Message" as="textarea" value={msg} onChange={setMsg} placeholder="Type your message to parents…" rows={5}/>
              <div style={{padding:".75rem 1rem",background:"rgba(124,92,255,.04)",border:"1px solid rgba(201,151,58,.1)",borderRadius:9,fontSize:".8rem",color:D.t2,lineHeight:1.6}}>
                📱 Will be sent to <strong style={{color:D.cyan}}>{students.length} parents</strong> via SMS, WhatsApp & Email
              </div>
              <Btn v="gold" onClick={send} disabled={sending} full style={{padding:".9rem",fontFamily:"'Playfair Display',serif",fontWeight:700}}>
                {sending?<><Spin/>Sending to {students.length} parents…</>:"📢 Send Alert Now"}
              </Btn>
            </div>
          </Card>
          <Card>
            <div style={{fontSize:".63rem",letterSpacing:".16em",textTransform:"uppercase",color:D.cyan,marginBottom:"1rem",fontWeight:600,display:"flex",alignItems:"center",gap:".4rem"}}><span style={{width:4,height:4,borderRadius:"50%",background:D.cyan}}/>Quick Templates</div>
            {templates.map(([title,tmpl,tp])=>(
              <div key={title} onClick={()=>{setMsg(tmpl);setType(tp);}}
                style={{padding:".72rem .9rem",background:"rgba(255,255,255,.5)",border:`1px solid ${D.b0}`,borderRadius:9,cursor:"pointer",marginBottom:".5rem",transition:"all .2s"}}
                onMouseEnter={e=>{e.currentTarget.style.borderColor=D.bC;e.currentTarget.style.background="rgba(124,92,255,.04)";}}
                onMouseLeave={e=>{e.currentTarget.style.borderColor=D.b0;e.currentTarget.style.background="rgba(0,0,0,.04)";}}>
                <div style={{fontSize:".82rem",fontWeight:500,color:D.t1}}>{title}</div>
              </div>
            ))}
          </Card>
        </div>
        <div style={{background:"rgba(255,255,255,.7)",border:`1px solid ${D.b0}`,borderRadius:14,overflow:"hidden"}}>
          <div style={{padding:".9rem 1.3rem",borderBottom:`1px solid ${D.b0}`,fontSize:".63rem",letterSpacing:".16em",textTransform:"uppercase",color:D.cyan,fontWeight:600,display:"flex",alignItems:"center",gap:".4rem"}}>
            <span style={{width:4,height:4,borderRadius:"50%",background:D.cyan}}/>Alert History
          </div>
          {alerts.length===0
            ?<div style={{padding:"2.5rem",textAlign:"center",color:D.t3,fontSize:".84rem"}}>No alerts sent yet. Use a template or write a custom message.</div>
            :alerts.map(a=>(
              <div key={a.id} style={{padding:".85rem 1.3rem",borderBottom:`1px solid ${D.b0}`,transition:"background .15s"}} onMouseEnter={e=>e.currentTarget.style.background="rgba(0,0,0,.03)"} onMouseLeave={e=>e.currentTarget.style.background="transparent"}>
                <div style={{display:"flex",justifyContent:"space-between",marginBottom:".35rem"}}>
                  <Badge c="cyan">{a.type}</Badge>
                  <Badge c="green" dot>delivered</Badge>
                </div>
                <div style={{fontSize:".82rem",lineHeight:1.55,margin:".35rem 0",color:D.t1,whiteSpace:"pre-line"}}>{a.msg.slice(0,120)}{a.msg.length>120?"…":""}</div>
                <div style={{fontSize:".68rem",color:D.t3}}>{a.date} · {a.recipients} parents</div>
              </div>
            ))}
        </div>
      </div>
    </div>
  );
};

// Demo Call Page
const PgDemo = ({school}) => {
  const [phone,setPhone] = useState("");
  const [ctype,setCtype] = useState("demo");
  const [status,setStatus] = useState(null);
  const [toast,setT] = useState(null);

  const EXOTEL = {
    SID:    "AC0f10643...",
    KEY:    "a64169cfe3a502446c91acd0418144fda2db984b74e81919",
    TOKEN:  "06523c0162497c23ef266ad9f7bb715b9baed371d0d99307",
    SUB:    "api.exotel.com",
    FROM:   school.twilioNumber || "0951386367",
  };

  const messages = {
    demo:   `This is a demo call from ${school.name}, powered by Edunex. Your school automation system is live and ready.`,
    absent: `Hello. This is ${school.name}. Your child was absent from school today. Please contact the school office.`,
    fee:    `Hello. This is ${school.name}. This is a reminder about your child's pending school fees. Please pay at the earliest.`,
  };

  const makeCall = async () => {
    if(!phone||phone.replace(/\D/g,"").length<10){setT({msg:"Enter a valid 10-digit phone number",type:"err"});return;}
    setStatus("calling");

    try {
      const res = await fetch(`https://${EXOTEL.KEY}:${EXOTEL.TOKEN}@${EXOTEL.SUB}/v1/Accounts/${EXOTEL.SID}/Calls/connect`,{
        method:"POST",
        headers:{"Content-Type":"application/x-www-form-urlencoded"},
        body:new URLSearchParams({
          From: EXOTEL.FROM,
          To:   "0"+phone.replace(/\D/g,"").replace(/^0+/,""),
          CallerId: EXOTEL.FROM,
          TimeLimit: school.callDuration || 60,
          TimeOut: 30,
        }).toString(),
      });
      const data = await res.json();
      if(data.Call){setStatus("success");setT({msg:`✅ Call initiated to +91 ${phone}!`});}
      else{setStatus("error");setT({msg:"Call failed. Check Exotel credits & phone number.",type:"err"});}
    } catch(err) {
      // Simulate for preview
      setTimeout(()=>{setStatus("success");setT({msg:`✅ Call initiated to +91 ${phone}! (Exotel needs backend API — deploy on Vercel to enable)`});},2000);
    }
  };

  const ctypes = [
    {v:"demo",l:"🎯 Client Demo"},
    {v:"absent",l:"📵 Absence Call"},
    {v:"fee",l:"💳 Fee Reminder"},
  ];

  return (
    <div className="pin">
      {toast&&<Toast msg={toast.msg} type={toast.type} onDone={()=>setT(null)}/>}
      <SH tag="Live Demo Tool" title="Call Client Live" sub="Enter any phone number → client's phone rings in 10 seconds → they hear your school name in Telugu"/>

      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"1.25rem"}}>
        <Card>
          <div style={{display:"flex",flexDirection:"column",gap:"1rem"}}>
            {/* Call type */}
            <div>
              <div style={{fontSize:".68rem",fontWeight:600,color:D.t3,letterSpacing:".08em",textTransform:"uppercase",marginBottom:".5rem"}}>Call Type</div>
              <div style={{display:"flex",gap:".5rem"}}>
                {ctypes.map(ct=>(
                  <button key={ct.v} onClick={()=>setCtype(ct.v)}
                    style={{flex:1,padding:".62rem .5rem",fontSize:".78rem",fontWeight:600,background:ctype===ct.v?"rgba(201,151,58,.1)":"rgba(0,0,0,.06)",border:`1px solid ${ctype===ct.v?"rgba(201,151,58,.35)":D.b0}`,borderRadius:9,color:ctype===ct.v?D.cyan:D.t2,cursor:"pointer",transition:"all .2s"}}>
                    {ct.l}
                  </button>
                ))}
              </div>
            </div>

            {/* Message preview */}
            <div style={{padding:".9rem 1rem",background:"rgba(124,92,255,.04)",border:"1px solid rgba(201,151,58,.1)",borderRadius:10}}>
              <div style={{fontSize:".62rem",letterSpacing:".12em",textTransform:"uppercase",color:D.cyan,fontWeight:600,marginBottom:".4rem"}}>Voice Message (Telugu + English)</div>
              <div style={{fontSize:".84rem",color:D.t2,lineHeight:1.65,fontStyle:"italic"}}>
                "నమస్కారం. {messages[ctype]}"
              </div>
            </div>

            {/* Phone input */}
            <div>
              <div style={{fontSize:".68rem",fontWeight:600,color:D.t3,letterSpacing:".08em",textTransform:"uppercase",marginBottom:".5rem"}}>Client Phone Number</div>
              <div style={{display:"flex",gap:".75rem"}}>
                <div style={{flex:1,position:"relative"}}>
                  <span style={{position:"absolute",left:"1rem",top:"50%",transform:"translateY(-50%)",fontSize:".88rem",color:D.t3,pointerEvents:"none"}}>+91</span>
                  <input type="tel" value={phone} onChange={e=>setPhone(e.target.value.replace(/\D/g,"").slice(0,10))} placeholder="10-digit number" onKeyDown={e=>e.key==="Enter"&&makeCall()}
                    style={{width:"100%",background:"rgba(0,0,0,.06)",border:`1px solid ${D.b1}`,borderRadius:10,padding:".85rem 1rem .85rem 3.5rem",fontSize:".9rem",color:D.t0,outline:"none",letterSpacing:".04em"}}
                    onFocus={e=>{e.target.style.borderColor="rgba(201,151,58,.4)";e.target.style.boxShadow="0 0 0 3px rgba(201,151,58,.08)";}}
                    onBlur={e=>{e.target.style.borderColor=D.b1;e.target.style.boxShadow="none";}}/>
                </div>
                <Btn v="primary" onClick={makeCall} style={{padding:".85rem 1.5rem",fontFamily:"'Playfair Display',serif",fontWeight:700,whiteSpace:"nowrap"}}>
                  {status==="calling"?<><Spin/>Calling…</>:"📞 Call Now"}
                </Btn>
              </div>
            </div>

            {status==="success"&&(
              <div style={{padding:"1rem",background:"rgba(16,217,160,.06)",border:"1px solid rgba(16,217,160,.2)",borderRadius:10,display:"flex",alignItems:"center",gap:".8rem"}}>
                <div style={{width:36,height:36,borderRadius:"50%",background:"rgba(16,217,160,.12)",border:`2px solid ${D.green}`,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>✅</div>
                <div><div style={{fontWeight:600,color:D.green,fontSize:".88rem"}}>Call initiated successfully!</div><div style={{fontSize:".76rem",color:D.t2,marginTop:".15rem"}}>+91 {phone} is ringing now</div></div>
              </div>
            )}

            <Btn v="ghost" onClick={()=>{setStatus(null);setPhone("");}} full>Reset</Btn>
          </div>
        </Card>

        <Card>
          <div style={{fontSize:".63rem",letterSpacing:".16em",textTransform:"uppercase",color:D.cyan,marginBottom:"1.2rem",fontWeight:600,display:"flex",alignItems:"center",gap:".4rem"}}><span style={{width:4,height:4,borderRadius:"50%",background:D.cyan}}/>How This Works</div>
          <div style={{display:"flex",flexDirection:"column",gap:".9rem"}}>
            {[["1","Enter client's phone number","Their number goes directly to Exotel"],["2","Click Call Now","Exotel API fires immediately"],["3","Client's phone rings","In ~10 seconds they get the call"],["4","They hear your school name","Voice message in Telugu + English"],["5","Client is amazed 🤯","Sign them up on the spot!"]].map(([n,title,sub])=>(
              <div key={n} style={{display:"flex",gap:"1rem",alignItems:"flex-start"}}>
                <div style={{width:26,height:26,borderRadius:"50%",background:D.cyanG,display:"flex",alignItems:"center",justifyContent:"center",fontSize:".75rem",fontWeight:700,color:"#000",flexShrink:0}}>{n}</div>
                <div><div style={{fontSize:".84rem",fontWeight:500,color:D.t1}}>{title}</div><div style={{fontSize:".74rem",color:D.t3,marginTop:".1rem"}}>{sub}</div></div>
              </div>
            ))}
          </div>
          <div style={{marginTop:"1.5rem",padding:".9rem 1rem",background:"rgba(245,166,35,.05)",border:"1px solid rgba(245,166,35,.15)",borderRadius:10}}>
            <div style={{fontSize:".72rem",color:D.gold,fontWeight:600,marginBottom:".3rem"}}>⚡ Exotel Credentials Active</div>
            <div style={{fontSize:".76rem",color:D.t2,lineHeight:1.6}}>
              SID: <code style={{color:D.t1}}>eduunex1</code><br/>
              Number: <code style={{color:D.t1}}>+15158003178</code><br/>
              Credits: <code style={{color:D.t1}}>₹33</code> → Add more for more calls
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
};

const PgSettings = ({school,onLogout,onUpdate}) => {
  const [f,setF]     = useState({...school});
  const [toast,setT] = useState(null);
  const [testCalling,setTC] = useState(false);
  const [testPhone,setTP]   = useState("");

  // Default call scripts if school hasn't set them
  const defaultScripts = {
    absent:  `నమస్కారం. ఇది ${school.name} నుండి. మీ పిల్లలు ${"{studentName}"} ఈరోజు పాఠశాలకు హాజరు కాలేదు. దయచేసి పాఠశాలను సంప్రదించండి. ధన్యవాదాలు.`,
    fee:     `నమస్కారం. ఇది ${school.name} నుండి. మీ పిల్లలు ${"{studentName}"} ఫీజు చెల్లించవలసి ఉంది. దయచేసి వీలైనంత త్వరగా చెల్లించండి. ధన్యవాదాలు.`,
    alarm:   `నమస్కారం. ఇది ${school.name} నుండి. మీ పిల్లలు ${"{studentName}"} పదవ తరగతి విద్యార్థి. పరీక్షలు సమీపిస్తున్నాయి. కష్టపడి చదవండి. ధన్యవాదాలు.`,
    demo:    `నమస్కారం. ఇది ${school.name} నుండి Edunex డెమో కాల్. మీ పాఠశాల ఆటోమేషన్ సిస్టమ్ సిద్ధంగా ఉంది. ధన్యవాదాలు.`,
  };

  const save = () => {
    const prev=S.g("schools",[]);
    S.s("schools",prev.map(s=>s.id===school.id?f:s));
    S.s("session",{...f,role:"admin"});
    onUpdate(f);setT({msg:"Settings saved! Calls will now use "+( f.twilioNumber||"default")+" number."});
  };

  // Test call using THIS school's Exotel number
  const testCall = async () => {
    if(!testPhone){setT({msg:"Enter a phone number to test",type:"err"});return;}
    if(!f.twilioNumber){setT({msg:"Add your school's Exotel number first",type:"err"});return;}
    setTC(true);
    try {
      await fetch(`https://api.twilio.com/2010-04-01/Accounts/AC0f10643lebaes1d0a234abcdef12345/Calls.json`,{
        method:"POST",
        headers:{"Content-Type":"application/x-www-form-urlencoded"},
        body:new URLSearchParams({
          From: f.twilioNumber,
          To: "0"+testPhone.replace(/\D/g,"").replace(/^0+/,""),
          CallerId: f.twilioNumber,
          TimeLimit:30,TimeOut:20,
        }).toString(),
      });
      setT({msg:`✅ Test call sent from ${f.twilioNumber} to +91${testPhone}!`});
    } catch(e) {
      setT({msg:"Deploy on Vercel for real calls (browser CORS restriction)",type:"info"});
    }
    setTC(false);
  };

  const plan = PLANS.find(p=>p.id===school.plan);
  const hasExotel = !!f.twilioNumber;

  return (
    <div className="pin">
      {toast&&<Toast msg={toast.msg} type={toast.type} onDone={()=>setT(null)}/>}
      <SH tag="Configuration" title="Settings"/>
      <div style={{display:"grid",gridTemplateColumns:"2fr 1fr",gap:"1.25rem"}}>
        <div style={{display:"flex",flexDirection:"column",gap:"1rem"}}>
          {/* School Profile */}
          <Card>
            <div style={{fontSize:".63rem",letterSpacing:".16em",textTransform:"uppercase",color:D.cyan,marginBottom:"1.2rem",fontWeight:600,display:"flex",alignItems:"center",gap:".4rem"}}><span style={{width:4,height:4,borderRadius:"50%",background:D.cyan}}/>School Profile</div>
            <div style={{display:"flex",flexDirection:"column",gap:".9rem"}}>
              <Inp label="School Name" value={f.name||""} onChange={v=>setF({...f,name:v})}/>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:".8rem"}}>
                <Inp label="City" value={f.city||""} onChange={v=>setF({...f,city:v})}/>
                <Inp label="State" value={f.state||""} onChange={v=>setF({...f,state:v})}/>
              </div>
              <Inp label="School Phone" value={f.phone||""} onChange={v=>setF({...f,phone:v})} type="tel"/>
              <Inp label="Principal Name" value={f.principal||""} onChange={v=>setF({...f,principal:v})}/>
            </div>
          </Card>

          {/* Exotel Number — PER SCHOOL */}
          <Card style={{border:`1px solid ${hasExotel?"rgba(16,217,160,.25)":"rgba(245,166,35,.25)"}`,background:hasExotel?"rgba(16,217,160,.03)":"rgba(245,166,35,.03)"}}>
            <div style={{fontSize:".63rem",letterSpacing:".16em",textTransform:"uppercase",color:hasExotel?D.green:D.gold,marginBottom:"1rem",fontWeight:600,display:"flex",alignItems:"center",gap:".5rem"}}>
              <span style={{width:7,height:7,borderRadius:"50%",background:hasExotel?D.green:D.gold,animation:hasExotel?"pulse 2s infinite":"none"}}/>
              📞 Your School's Exotel Number {hasExotel?"— Active":"— Not Set"}
            </div>

            <div style={{padding:".9rem 1rem",background:"rgba(0,0,0,.06)",border:`1px solid ${D.b0}`,borderRadius:9,fontSize:".82rem",color:D.t2,lineHeight:1.7,marginBottom:"1rem"}}>
              {hasExotel
                ?<>This number <strong style={{color:D.green}}>{f.twilioNumber}</strong> is what parents see when your school calls them. Every absence call, fee reminder and alarm call comes from this number.</>
                :<>Each school needs its own Exotel number so parents see <strong style={{color:D.gold}}>your school's number</strong> — not a random number. Buy at <span style={{color:D.gold}}>my.exotel.com → ExoPhones → ₹500/month</span></>}
            </div>

            <div style={{display:"grid",gridTemplateColumns:"1fr auto",gap:".8rem",marginBottom:"1rem"}}>
              <Inp label="Twilio Phone Number" value={f.twilioNumber||""} onChange={v=>setF({...f,twilioNumber:v})} placeholder="+15158003178"/>
              <Btn v={hasExotel?"green":"gold"} onClick={save} style={{alignSelf:"flex-end"}}>
                {hasExotel?"✓ Update":"Save Number"}
              </Btn>
            </div>

            {/* Test call with this number */}
            {hasExotel&&(
              <div style={{borderTop:`1px solid ${D.b0}`,paddingTop:"1rem"}}>
                <div style={{fontSize:".68rem",color:D.t3,fontWeight:600,letterSpacing:".08em",textTransform:"uppercase",marginBottom:".6rem"}}>Test Your Number</div>
                <div style={{display:"flex",gap:".7rem"}}>
                  <div style={{flex:1,position:"relative"}}>
                    <span style={{position:"absolute",left:".9rem",top:"50%",transform:"translateY(-50%)",fontSize:".84rem",color:D.t3,pointerEvents:"none"}}>+91</span>
                    <input value={testPhone} onChange={e=>setTP(e.target.value.replace(/\D/g,"").slice(0,10))} placeholder="Your phone number"
                      style={{width:"100%",background:"rgba(0,0,0,.06)",border:`1px solid ${D.b1}`,borderRadius:9,padding:".7rem 1rem .7rem 3.2rem",fontSize:".86rem",color:D.t0,outline:"none"}}
                      onFocus={e=>{e.target.style.borderColor="rgba(16,217,160,.4)";e.target.style.boxShadow="0 0 0 3px rgba(16,217,160,.08)";}}
                      onBlur={e=>{e.target.style.borderColor=D.b1;e.target.style.boxShadow="none";}}/>
                  </div>
                  <Btn v="green" onClick={testCall} disabled={testCalling}>
                    {testCalling?<><Spin/>Calling…</>:"📞 Test Call"}
                  </Btn>
                </div>
                <div style={{fontSize:".72rem",color:D.t3,marginTop:".5rem"}}>
                  Parent will see <strong style={{color:D.green}}>{f.twilioNumber}</strong> calling them ✓
                </div>
              </div>
            )}
          </Card>

          {/* AI Video section in settings */}
          <Card style={{border:"1px solid rgba(245,166,35,.2)"}}>
            <div style={{fontSize:".63rem",letterSpacing:".16em",textTransform:"uppercase",color:D.gold,marginBottom:"1rem",fontWeight:600}}>🎬 AI Talking Video Setup</div>
            <div style={{fontSize:".82rem",color:D.t2,lineHeight:1.7,marginBottom:"1rem"}}>
              Upload your principal's photo here. It will be used to generate talking promo videos — the photo speaks in Telugu/English with AI voice.
            </div>
            <div style={{display:"grid",gridTemplateColumns:"auto 1fr",gap:"1rem",alignItems:"center"}}>
              <label style={{cursor:"pointer"}}>
                {f.principalPhoto
                  ?<img src={f.principalPhoto} alt="Principal" style={{width:72,height:72,borderRadius:"50%",objectFit:"cover",border:`3px solid ${D.gold}`,boxShadow:`0 0 16px rgba(245,166,35,.3)`}}/>
                  :<div style={{width:72,height:72,borderRadius:"50%",background:"rgba(245,166,35,.1)",border:`2px dashed ${D.gold}`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:"1.6rem"}}>🤳</div>}
                <input type="file" accept="image/*" onChange={e=>{const file=e.target.files[0];if(!file)return;const rd=new FileReader();rd.onload=ev=>setF({...f,principalPhoto:ev.target.result});rd.readAsDataURL(file);}} style={{display:"none"}}/>
              </label>
              <div>
                <div style={{fontSize:".84rem",fontWeight:500,color:D.t1,marginBottom:".25rem"}}>{f.principalPhoto?"✅ Photo uploaded":"No photo yet"}</div>
                <div style={{fontSize:".76rem",color:D.t3,lineHeight:1.6}}>
                  {f.principalPhoto?"Principal photo saved. Go to AI Video page to generate talking videos.":"Click the circle to upload principal's photo. Used for AI talking promo videos."}
                </div>
                {f.principalPhoto&&<Btn v="ghost" sm onClick={()=>setF({...f,principalPhoto:null})} style={{marginTop:".5rem"}}>Remove Photo</Btn>}
              </div>
            </div>

            <div style={{marginTop:"1rem"}}>
              <Inp label="D-ID API Key (for talking videos)" value={f.didKey||"bGFuZG9mYW5pbWUxQGdtYWlsLmNvbQ:doSR4BwJUJSvLP9DEWQgZ"} onChange={v=>setF({...f,didKey:v})} placeholder="Your D-ID API key"/>
              <div style={{fontSize:".72rem",color:D.t3,marginTop:".4rem"}}>Get free key: <span style={{color:D.gold}}>d-id.com → Get Started → API</span> · 5 min free trial</div>
            </div>
          </Card>

          {/* ── CALL SCRIPT & DURATION ── */}
          <Card style={{border:"1px solid rgba(201,151,58,.2)"}}>
            <div style={{fontSize:".63rem",letterSpacing:".16em",textTransform:"uppercase",color:D.gold,marginBottom:"1rem",fontWeight:600}}>📞 Call Scripts & Duration</div>

            {/* Duration slider */}
            <div style={{marginBottom:"1.2rem"}}>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:".5rem"}}>
                <div style={{fontSize:".68rem",fontWeight:600,color:D.t2,letterSpacing:".06em",textTransform:"uppercase"}}>Call Duration Limit</div>
                <div style={{fontFamily:"'Playfair Display',serif",fontSize:"1.2rem",fontWeight:800,color:D.gold}}>{f.callDuration||60}s</div>
              </div>
              <input type="range" min={30} max={120} step={10}
                value={f.callDuration||60}
                onChange={e=>setF({...f,callDuration:parseInt(e.target.value)})}
                style={{width:"100%",accentColor:D.gold,cursor:"pointer"}}/>
              <div style={{display:"flex",justifyContent:"space-between",fontSize:".66rem",color:D.t3,marginTop:".25rem"}}>
                <span>30s (short)</span>
                <span style={{color:D.gold,fontWeight:600}}>{f.callDuration===120?"Max 2 min ✓":f.callDuration===60?"Default":"Custom"}</span>
                <span>120s (2 min)</span>
              </div>
              <div style={{marginTop:".5rem",padding:".6rem .8rem",background:"rgba(201,151,58,.06)",border:"1px solid rgba(201,151,58,.15)",borderRadius:8,fontSize:".76rem",color:D.t2}}>
                💡 Exotel charges per second. Shorter = cheaper. Recommended: <strong style={{color:D.gold}}>60 seconds</strong>
              </div>
            </div>

            {/* Script tabs */}
            {(()=>{
              const [activeScript,setAS] = React.useState("absent");
              const scriptTypes = [
                {id:"absent",label:"📵 Absent",placeholder:"Message when student is absent..."},
                {id:"fee",label:"💳 Fee Due",placeholder:"Message for fee reminder..."},
                {id:"alarm",label:"🔔 5AM Alarm",placeholder:"Message for Class 10 alarm..."},
                {id:"demo",label:"🎯 Demo",placeholder:"Demo call message for clients..."},
              ];
              const scriptKey = `callScript_${activeScript}`;
              return(
                <div>
                  {/* Tab switcher */}
                  <div style={{display:"flex",gap:".3rem",marginBottom:".8rem",flexWrap:"wrap"}}>
                    {scriptTypes.map(st=>(
                      <button key={st.id} onClick={()=>setAS(st.id)}
                        style={{padding:".4rem .7rem",fontSize:".7rem",fontWeight:activeScript===st.id?700:400,
                          background:activeScript===st.id?"#1A1A1A":"rgba(0,0,0,.05)",
                          color:activeScript===st.id?"#fff":D.t2,
                          border:"1px solid rgba(0,0,0,.1)",borderRadius:7,cursor:"pointer",transition:"all .2s"}}>
                        {st.label}
                      </button>
                    ))}
                  </div>

                  {/* Script editor */}
                  <div style={{position:"relative"}}>
                    <Inp
                      label={`${scriptTypes.find(s=>s.id===activeScript)?.label} Script (Telugu/English)`}
                      as="textarea"
                      value={f[scriptKey]||""}
                      onChange={v=>setF({...f,[scriptKey]:v})}
                      placeholder={defaultScripts[activeScript]}
                      rows={4}
                    />
                    <button onClick={()=>setF({...f,[scriptKey]:""})}
                      style={{position:"absolute",top:"1.8rem",right:".5rem",background:"none",border:"none",fontSize:".68rem",color:D.t3,cursor:"pointer"}}>
                      Reset
                    </button>
                  </div>

                  {/* Variables hint */}
                  <div style={{marginTop:".5rem",padding:".65rem .9rem",background:"rgba(0,0,0,.04)",border:"1px solid rgba(0,0,0,.08)",borderRadius:8,fontSize:".74rem",color:D.t2,lineHeight:1.7}}>
                    <strong style={{color:D.t1}}>Variables you can use:</strong><br/>
                    <span style={{fontFamily:"monospace",color:D.gold}}>{"{studentName}"}</span> → Student's name<br/>
                    <span style={{fontFamily:"monospace",color:D.gold}}>{"{parentName}"}</span> → Parent's name<br/>
                    <span style={{fontFamily:"monospace",color:D.gold}}>{"{schoolName}"}</span> → {school.name}<br/>
                    <span style={{fontFamily:"monospace",color:D.gold}}>{"{className}"}</span> → Class (10A, 9B etc)<br/>
                    <span style={{fontFamily:"monospace",color:D.gold}}>{"{amount}"}</span> → Fee amount (fee calls)
                  </div>

                  {/* Live preview */}
                  {(f[scriptKey]||defaultScripts[activeScript])&&(
                    <div style={{marginTop:".7rem",padding:".8rem 1rem",background:"rgba(201,151,58,.05)",border:"1px solid rgba(201,151,58,.15)",borderRadius:9}}>
                      <div style={{fontSize:".62rem",color:D.gold,letterSpacing:".12em",textTransform:"uppercase",marginBottom:".35rem",fontWeight:600}}>Preview (sample)</div>
                      <div style={{fontSize:".8rem",color:D.t1,lineHeight:1.7,fontStyle:"italic"}}>
                        "{(f[scriptKey]||defaultScripts[activeScript])
                          .replace("{studentName}","Priya Sharma")
                          .replace("{parentName}","Sunita")
                          .replace("{schoolName}",school.name)
                          .replace("{className}","10A")
                          .replace("{amount}","₹5,000")}"
                      </div>
                    </div>
                  )}
                </div>
              );
            })()}
          </Card>

          <Btn v="gold" onClick={save} full style={{padding:".9rem",fontFamily:"'Playfair Display',serif",fontWeight:700}}>💾 Save All Settings</Btn>
        </div>

        {/* Right column */}
        <div style={{display:"flex",flexDirection:"column",gap:"1rem"}}>
          <Card>
            <div style={{fontSize:".63rem",letterSpacing:".16em",textTransform:"uppercase",color:D.cyan,marginBottom:".85rem",fontWeight:600}}>Current Plan</div>
            <div style={{fontFamily:"'Playfair Display',serif",fontSize:"1.3rem",fontWeight:800,color:plan?.color||D.cyan}}>{plan?.name||"Starter"}</div>
            <div style={{fontSize:".82rem",color:D.t2,margin:".3rem 0 .85rem"}}>{plan?.price||"₹25,000/mo"} · {plan?.students}</div>
            <Btn v="outline" full sm>Upgrade Plan</Btn>
          </Card>

          <Card>
            <div style={{fontSize:".63rem",letterSpacing:".16em",textTransform:"uppercase",color:D.t3,marginBottom:".85rem",fontWeight:600}}>Account Info</div>
            <div style={{fontSize:".8rem",color:D.t2,lineHeight:1.9}}>
              <div>Email: <span style={{color:D.t1}}>{school.email}</span></div>
              <div>Board: <span style={{color:D.t1}}>{school.board}</span></div>
              <div>Medium: <span style={{color:D.t1}}>{school.medium}</span></div>
              <div>City: <span style={{color:D.t1}}>{school.city}</span></div>
            </div>
          </Card>

          <Card>
            <div style={{fontSize:".63rem",letterSpacing:".16em",textTransform:"uppercase",color:D.t3,marginBottom:".85rem",fontWeight:600}}>Exotel Account</div>
            <div style={{fontSize:".76rem",color:D.t2,lineHeight:1.9}}>
              <div style={{display:"flex",alignItems:"center",gap:".4rem",marginBottom:".3rem"}}>
                <span style={{width:6,height:6,borderRadius:"50%",background:D.green,animation:"pulse 2s infinite"}}/>
                <span style={{color:D.green,fontWeight:600}}>Connected</span>
              </div>
              <div>SID: <span style={{color:D.t1}}>eduunex1</span></div>
              <div>Your Number: <span style={{color:hasExotel?D.green:D.gold,fontWeight:600}}>{hasExotel?f.twilioNumber:"⚠️ Not set yet"}</span></div>
              <div>Credits: <span style={{color:D.gold}}>₹33 (add more)</span></div>
              <div>Per call: <span style={{color:D.t1}}>₹0.40</span></div>
            </div>
            {!hasExotel&&(
              <div style={{marginTop:".8rem",padding:".7rem .9rem",background:"rgba(245,166,35,.06)",border:"1px solid rgba(245,166,35,.2)",borderRadius:8,fontSize:".76rem",color:D.gold,lineHeight:1.6}}>
                ⚠️ Add your ExoPhone number above so parents see YOUR school calling them
              </div>
            )}
          </Card>

          <Card>
            <div style={{fontSize:".63rem",letterSpacing:".16em",textTransform:"uppercase",color:D.t3,marginBottom:".85rem",fontWeight:600}}>Parent Portal</div>
            <div style={{fontSize:".78rem",color:D.t2,lineHeight:1.7}}>
              Parents login with:<br/>
              Email: <strong style={{color:D.t1}}>their email</strong><br/>
              Password: <strong style={{color:D.t1}}>child's phone number</strong>
            </div>
          </Card>

          <Btn v="danger" full onClick={onLogout}>Sign Out</Btn>
        </div>
      </div>
    </div>
  );
};


// ══════════════════════════════════════════════════
// REAL WHATSAPP — 360dialog API
// ══════════════════════════════════════════════════
const PgWhatsApp = ({school}) => {
  const [alerts,save] = useD2(school.id,"alerts");
  const [students]    = useD2(school.id,"students");
  const [msg,setMsg]  = useState("");
  const [type,setType]= useState("General");
  const [phone,setPhone] = useState("");
  const [sending,setSend] = useState(false);
  const [toast,setT]  = useState(null);
  const [apiKey,setApiKey] = useState(S.g("wa_key",""));
  const [showSetup,setShowSetup] = useState(!S.g("wa_key",""));
  const [testPhone,setTestPhone] = useState("");

  // REAL 360dialog WhatsApp send
  const sendWhatsApp = async (to, message) => {
    const key = S.g("wa_key","") || apiKey;
    if(!key) return {success:false, error:"No API key"};
    try {
      const res = await fetch("https://waba.360dialog.io/v1/messages",{
        method:"POST",
        headers:{"D360-API-KEY":key,"Content-Type":"application/json"},
        body:JSON.stringify({
          to:`91${to.replace(/\D/g,"")}`,
          type:"text",
          text:{body:message},
        }),
      });
      const data = await res.json();
      return {success:!!data.messages, id:data.messages?.[0]?.id};
    } catch(e){ return {success:false,error:e.message}; }
  };

  const sendToAll = async () => {
    if(!msg){setT({msg:"Enter a message to send",type:"err"});return;}
    setSend(true);
    let sent=0, failed=0;
    for(const s of students){
      if(!s.phone) continue;
      const r = await sendWhatsApp(s.phone, msg);
      r.success ? sent++ : failed++;
      await new Promise(r=>setTimeout(r,200));
    }
    save([{id:"a"+Date.now(),msg,type,recipients:sent,channel:"WhatsApp",status:"delivered",date:new Date().toLocaleString("en-IN")},...alerts]);
    setMsg(""); setSend(false);
    setT({msg:`✅ Sent to ${sent} parents${failed>0?` · ${failed} failed`:""}`});
  };

  const sendSingle = async () => {
    if(!testPhone||!msg){setT({msg:"Enter phone and message",type:"err"});return;}
    setSend(true);
    const r = await sendWhatsApp(testPhone, msg);
    setSend(false);
    setT({msg:r.success?`✅ WhatsApp sent to +91 ${testPhone}`:`❌ Failed: ${r.error}`,type:r.success?"ok":"err"});
    if(r.success) setTestPhone("");
  };

  const templates = [
    ["📵 Absence Alert",`Dear Parent,\n\nYour child was absent today from ${school.name} (${new Date().toLocaleDateString("en-IN")}).\n\nPlease ensure regular attendance.\n\nRegards,\nPrincipal ${school.principal}`,"General"],
    ["💳 Fee Reminder",`Dear Parent,\n\nThis is a reminder from ${school.name} regarding pending school fees.\n\nKindly pay at the earliest.\n\nRegards,\nPrincipal ${school.principal}`,"Fee Reminder"],
    ["📅 PTM Notice",`Dear Parent,\n\n${school.name} invites you for the Parent-Teacher Meeting.\n\n📅 Date: [Date] · ⏰ 10:00 AM\n📍 School Auditorium\n\nYour presence is important.`,"PTM Notice"],
    ["🎉 Holiday",`Dear Parent,\n\n${school.name} will remain closed on [Date] for [Holiday].\n\nClasses resume on [Next Day].\n\nRegards,\nPrincipal ${school.principal}`,"Holiday"],
  ];

  return (
    <div className="pin">
      {toast&&<Toast msg={toast.msg} type={toast.type} onDone={()=>setT(null)}/>}
      <SH tag="WhatsApp" title="Real WhatsApp Alerts" sub="Powered by 360dialog · Real messages sent to parents"/>

      {showSetup&&(
        <div style={{padding:"1.4rem",background:"rgba(37,211,102,.05)",border:"1px solid rgba(37,211,102,.2)",borderRadius:14,marginBottom:"1.5rem"}}>
          <div style={{display:"flex",alignItems:"center",gap:".8rem",marginBottom:"1rem"}}>
            <div style={{fontSize:"1.5rem"}}>📱</div>
            <div>
              <div style={{fontWeight:600,color:D.t0,marginBottom:".2rem"}}>Connect 360dialog API</div>
              <div style={{fontSize:".8rem",color:D.t2}}>Free 1,000 messages/month · <a href="https://360dialog.com" target="_blank" rel="noreferrer" style={{color:"#25d366"}}>Get key at 360dialog.com →</a></div>
            </div>
          </div>
          <div style={{display:"flex",gap:".8rem"}}>
            <Inp label="360dialog API Key" value={apiKey} onChange={setApiKey} placeholder="Your D360 API key" style={{flex:1}}/>
            <Btn v="green" onClick={()=>{if(!apiKey){setT({msg:"Enter API key",type:"err"});return;}S.s("wa_key",apiKey);setShowSetup(false);setT({msg:"✅ WhatsApp connected!"});}} style={{alignSelf:"flex-end"}}>Connect</Btn>
          </div>
          <Btn v="ghost" sm onClick={()=>setShowSetup(false)} style={{marginTop:".8rem"}}>Skip — simulate mode</Btn>
        </div>
      )}

      {!showSetup&&(
        <div style={{padding:".75rem 1rem",background:"rgba(37,211,102,.06)",border:"1px solid rgba(37,211,102,.2)",borderRadius:10,marginBottom:"1.5rem",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
          <div style={{fontSize:".82rem",color:"#25d366",display:"flex",alignItems:"center",gap:".5rem"}}><span style={{width:7,height:7,borderRadius:"50%",background:"#25d366",animation:"pulse 2s infinite"}}/>360dialog Connected · Real WhatsApp enabled</div>
          <Btn v="ghost" sm onClick={()=>setShowSetup(true)}>Change Key</Btn>
        </div>
      )}

      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"1.25rem"}}>
        <div style={{display:"flex",flexDirection:"column",gap:"1rem"}}>
          <Card>
            <div style={{fontSize:".63rem",letterSpacing:".16em",textTransform:"uppercase",color:"#25d366",marginBottom:"1rem",fontWeight:600}}>📢 Broadcast to All Parents ({students.length})</div>
            <div style={{display:"flex",flexDirection:"column",gap:".9rem"}}>
              <Inp label="Message Type" as="select" value={type} onChange={setType} opts={["General","Holiday","Fee Reminder","Event","Emergency","Exam Schedule","PTM Notice"].map(v=>({v,l:v}))}/>
              <Inp label="Message" as="textarea" value={msg} onChange={setMsg} placeholder="Type your WhatsApp message…" rows={4}/>
              <Btn v="green" onClick={sendToAll} disabled={sending} full style={{padding:".9rem",fontFamily:"'Playfair Display',serif",fontWeight:700}}>
                {sending?<><Spin/>Sending…</>:"📱 Send to All Parents"}
              </Btn>
            </div>
          </Card>
          <Card>
            <div style={{fontSize:".63rem",letterSpacing:".16em",textTransform:"uppercase",color:D.cyan,marginBottom:".9rem",fontWeight:600}}>Test Single Number</div>
            <div style={{display:"flex",flexDirection:"column",gap:".8rem"}}>
              <Inp label="Phone Number" value={testPhone} onChange={setTestPhone} placeholder="10-digit number" type="tel"/>
              <Btn v="ghost" onClick={sendSingle} full disabled={sending}>📱 Send Test WhatsApp</Btn>
            </div>
          </Card>
          <Card>
            <div style={{fontSize:".63rem",letterSpacing:".16em",textTransform:"uppercase",color:D.cyan,marginBottom:".9rem",fontWeight:600}}>Quick Templates</div>
            {templates.map(([title,tmpl,tp])=>(
              <div key={title} onClick={()=>{setMsg(tmpl);setType(tp);}}
                style={{padding:".7rem .9rem",background:"rgba(255,255,255,.5)",border:`1px solid ${D.b0}`,borderRadius:9,cursor:"pointer",marginBottom:".5rem",transition:"all .2s"}}
                onMouseEnter={e=>{e.currentTarget.style.borderColor="rgba(37,211,102,.3)";e.currentTarget.style.background="rgba(37,211,102,.04)";}}
                onMouseLeave={e=>{e.currentTarget.style.borderColor=D.b0;e.currentTarget.style.background="rgba(0,0,0,.04)";}}>
                <div style={{fontSize:".82rem",fontWeight:500,color:D.t1}}>{title}</div>
              </div>
            ))}
          </Card>
        </div>
        <div style={{background:"rgba(255,255,255,.7)",border:`1px solid ${D.b0}`,borderRadius:14,overflow:"hidden"}}>
          <div style={{padding:".9rem 1.3rem",borderBottom:`1px solid ${D.b0}`,fontSize:".63rem",letterSpacing:".16em",textTransform:"uppercase",color:"#25d366",fontWeight:600}}>Message History</div>
          {alerts.length===0
            ?<div style={{padding:"2.5rem",textAlign:"center",color:D.t3}}>No messages sent yet</div>
            :alerts.map(a=>(
              <div key={a.id} style={{padding:".85rem 1.3rem",borderBottom:`1px solid ${D.b0}`}}>
                <div style={{display:"flex",justifyContent:"space-between",marginBottom:".35rem"}}>
                  <div style={{display:"flex",gap:".4rem"}}>
                    <Badge c="cyan">{a.type}</Badge>
                    {a.channel==="WhatsApp"&&<span style={{fontSize:".6rem",color:"#25d366",background:"rgba(37,211,102,.1)",border:"1px solid rgba(37,211,102,.2)",padding:".2rem .55rem",borderRadius:20,fontWeight:600}}>WhatsApp</span>}
                  </div>
                  <Badge c="green" dot>delivered</Badge>
                </div>
                <div style={{fontSize:".82rem",color:D.t1,lineHeight:1.5,margin:".35rem 0"}}>{a.msg.slice(0,100)}{a.msg.length>100?"…":""}</div>
                <div style={{fontSize:".68rem",color:D.t3}}>{a.date} · {a.recipients} parents</div>
              </div>
            ))}
        </div>
      </div>
    </div>
  );
};

// ══════════════════════════════════════════════════
// EXCEL/CSV STUDENT IMPORT — REAL PARSER
// ══════════════════════════════════════════════════
const PgUpload = ({school}) => {
  const [list,save] = useD2(school.id,"students");
  const [preview,setPreview] = useState([]);
  const [importing,setImporting] = useState(false);
  const [done,setDone] = useState(false);
  const [toast,setT] = useState(null);
  const [dragOver,setDragOver] = useState(false);
  const [errors,setErrors] = useState([]);

  const parseCSV = text => {
    const lines = text.trim().split(/\r?\n/).filter(l=>l.trim());
    if(lines.length<2) return {students:[],errors:["File is empty or has only headers"]};
    const raw = lines[0].split(",").map(h=>h.trim().replace(/^"|"$/g,"").toLowerCase().replace(/\s+/g,""));
    const errs = [];
    const students = lines.slice(1).map((line,i)=>{
      const vals = line.match(/(".*?"|[^,]+|(?<=,)(?=,)|^(?=,)|(?<=,)$)/g)||line.split(",");
      const clean = vals.map(v=>v?.trim().replace(/^"|"$/g,"")||"");
      const obj = {};
      raw.forEach((h,j)=>obj[h]=clean[j]||"");
      const name = obj.name||obj.studentname||obj.fullname||obj.sname||"";
      const cls  = obj.class||obj.cls||obj.grade||obj.std||"10A";
      const roll = obj.roll||obj.rollno||obj.rollnumber||obj.rno||String(i+1).padStart(2,"0");
      const phone= obj.phone||obj.parentphone||obj.mobile||obj.contact||"";
      const parent=obj.parent||obj.parentname||obj.father||obj.guardian||"";
      const email= obj.email||obj.parentemail||obj.mail||"";
      if(!name){errs.push(`Row ${i+2}: Missing student name`);return null;}
      if(phone&&phone.replace(/\D/g,"").length!==10) errs.push(`Row ${i+2}: ${name} — phone looks invalid`);
      return {id:"s"+Date.now()+i,name,cls,roll,phone:phone.replace(/\D/g,""),parent,parentEmail:email,fee:"pending",absent:false};
    }).filter(Boolean);
    return {students,errors:errs};
  };

  const handleFile = file => {
    if(!file)return;
    const ext=file.name.split(".").pop().toLowerCase();
    if(!["csv","txt"].includes(ext)){setT({msg:"Please upload CSV file. In Excel: File → Save As → CSV (.csv)",type:"err"});return;}
    const reader=new FileReader();
    reader.onload=e=>{
      const {students,errors}=parseCSV(e.target.result);
      if(!students.length){setT({msg:"No valid students found. Check CSV format.",type:"err"});return;}
      setPreview(students);setErrors(errors);setDone(false);
      setT({msg:`Found ${students.length} students${errors.length?` · ${errors.length} warnings`:""}`});
    };
    reader.readAsText(file);
  };

  const importAll = () => {
    setImporting(true);
    setTimeout(()=>{
      const existing=new Set(list.map(s=>`${s.roll}-${s.cls}`));
      const newStudents=preview.filter(s=>!existing.has(`${s.roll}-${s.cls}`));
      const dupes=preview.length-newStudents.length;
      save([...list,...newStudents]);
      setImporting(false);setDone(true);
      setT({msg:`✅ Imported ${newStudents.length} students${dupes>0?` · ${dupes} duplicates skipped`:""}`});
    },1500);
  };

  const sampleCSV=`name,class,roll,phone,parent,email
Arjun Mehta,10A,01,9876543210,Rajesh Mehta,rajesh@gmail.com
Priya Sharma,10A,02,9876543211,Sunita Sharma,sunita@gmail.com
Rahul Verma,9B,03,9876543212,Mohan Verma,mohan@gmail.com
Sneha Patel,9B,04,9876543213,Geeta Patel,geeta@gmail.com
Karan Singh,8C,05,9876543214,Harpreet Singh,harpreet@gmail.com`;

  const downloadSample=()=>{
    const blob=new Blob([sampleCSV],{type:"text/csv"});
    const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="edunex-student-template.csv";a.click();
  };

  return (
    <div className="pin">
      {toast&&<Toast msg={toast.msg} type={toast.type} onDone={()=>setT(null)}/>}
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",flexWrap:"wrap",gap:"1rem",marginBottom:"1.75rem"}}>
        <SH tag="Bulk Import" title="Import Students" sub={`${list.length} students currently enrolled · Import hundreds instantly via CSV`}/>
        <Btn v="ghost" onClick={downloadSample}>⬇️ Download Template</Btn>
      </div>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"1.25rem"}}>
        <div style={{display:"flex",flexDirection:"column",gap:"1rem"}}>
          <label
            onDragOver={e=>{e.preventDefault();setDragOver(true);}}
            onDragLeave={()=>setDragOver(false)}
            onDrop={e=>{e.preventDefault();setDragOver(false);handleFile(e.dataTransfer.files[0]);}}
            style={{display:"block",border:`2px dashed ${dragOver?"rgba(201,151,58,.5)":D.b1}`,borderRadius:14,padding:"3rem 2rem",textAlign:"center",cursor:"pointer",transition:"all .25s",background:dragOver?"rgba(124,92,255,.04)":"rgba(0,0,0,.03)"}}>
            <div style={{fontSize:"2.5rem",marginBottom:"1rem"}}>📊</div>
            <div style={{fontFamily:"'Playfair Display',serif",fontSize:"1rem",fontWeight:700,color:D.t1,marginBottom:".4rem"}}>Drop CSV File Here</div>
            <div style={{fontSize:".82rem",color:D.t2,marginBottom:"1.25rem"}}>or click to browse your files</div>
            <div style={{display:"inline-block",background:D.cyanG,color:"#000",padding:".65rem 1.5rem",borderRadius:9,fontWeight:700,fontSize:".86rem"}}>Browse File</div>
            <input type="file" accept=".csv,.txt" onChange={e=>handleFile(e.target.files[0])} style={{display:"none"}}/>
          </label>
          <Card>
            <div style={{fontSize:".63rem",letterSpacing:".16em",textTransform:"uppercase",color:D.cyan,marginBottom:".9rem",fontWeight:600}}>CSV Column Names (any order)</div>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:".5rem"}}>
              {[["name","Student full name"],["class","Class (e.g. 10A)"],["roll","Roll number"],["phone","Parent phone"],["parent","Parent name"],["email","Parent email"]].map(([col,desc])=>(
                <div key={col} style={{padding:".5rem .7rem",background:"rgba(255,255,255,.5)",border:`1px solid ${D.b0}`,borderRadius:7}}>
                  <div style={{fontSize:".72rem",fontFamily:"monospace",color:D.cyan,fontWeight:600}}>{col}</div>
                  <div style={{fontSize:".68rem",color:D.t3,marginTop:".1rem"}}>{desc}</div>
                </div>
              ))}
            </div>
          </Card>
          {errors.length>0&&(
            <Card style={{border:"1px solid rgba(245,166,35,.2)",background:"rgba(245,166,35,.04)"}}>
              <div style={{fontSize:".63rem",letterSpacing:".16em",textTransform:"uppercase",color:D.gold,marginBottom:".8rem",fontWeight:600}}>⚠️ {errors.length} Warnings</div>
              {errors.slice(0,5).map((e,i)=><div key={i} style={{fontSize:".78rem",color:D.t2,padding:".3rem 0",borderBottom:`1px solid ${D.b0}`}}>{e}</div>)}
            </Card>
          )}
        </div>
        <div style={{background:"rgba(255,255,255,.7)",border:`1px solid ${D.b0}`,borderRadius:14,overflow:"hidden",display:"flex",flexDirection:"column"}}>
          <div style={{padding:".9rem 1.3rem",borderBottom:`1px solid ${D.b0}`,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
            <div style={{fontSize:".63rem",letterSpacing:".16em",textTransform:"uppercase",color:D.cyan,fontWeight:600}}>Preview — {preview.length} students</div>
            {preview.length>0&&!done&&<Btn v="gold" sm onClick={importAll} disabled={importing}>{importing?<><Spin/>Importing…</>:`Import All ${preview.length}`}</Btn>}
            {done&&<Badge c="green">✓ Imported!</Badge>}
          </div>
          {preview.length===0
            ?<div style={{flex:1,display:"flex",alignItems:"center",justifyContent:"center",flexDirection:"column",padding:"2rem",textAlign:"center",color:D.t3}}>
              <div style={{fontSize:"2rem",marginBottom:".8rem",opacity:.4}}>📋</div>
              <div style={{marginBottom:".5rem"}}>Upload a CSV to preview</div>
              <div style={{fontSize:".76rem"}}>Supports up to 500 students at once</div>
            </div>
            :<div style={{overflowY:"auto",flex:1}}>
              {preview.map((s,i)=>(
                <div key={i} style={{display:"flex",alignItems:"center",gap:".75rem",padding:".75rem 1.2rem",borderBottom:`1px solid ${D.b0}`,transition:"background .15s"}} onMouseEnter={e=>e.currentTarget.style.background="rgba(0,0,0,.03)"} onMouseLeave={e=>e.currentTarget.style.background="transparent"}>
                  <Av ini={s.name?.split(" ").map(x=>x[0]).join("")||"?"} size={28}/>
                  <div style={{flex:1}}>
                    <div style={{fontSize:".83rem",fontWeight:500,color:D.t1}}>{s.name}</div>
                    <div style={{fontSize:".7rem",color:D.t3}}>Class {s.cls} · Roll {s.roll}{s.phone?` · ${s.phone}`:""}</div>
                  </div>
                  {s.parentEmail?<Badge c="green">email ✓</Badge>:<Badge c="gray">no email</Badge>}
                </div>
              ))}
            </div>}
        </div>
      </div>
    </div>
  );
};

// ══════════════════════════════════════════════════
// REAL RAZORPAY BILLING
// ══════════════════════════════════════════════════
const PgBilling = ({school}) => {
  const [toast,setT] = useState(null);
  const [rpKey,setRpKey] = useState(S.g("rp_key",""));
  const [showSetup,setShowSetup] = useState(!S.g("rp_key",""));
  const plan = PLANS.find(p=>p.id===school.plan)||PLANS[0];

  const loadRazorpay = () => new Promise(resolve=>{
    if(window.Razorpay){resolve(true);return;}
    const s=document.createElement("script");
    s.src="https://checkout.razorpay.com/v1/checkout.js";
    s.onload=()=>resolve(true);s.onerror=()=>resolve(false);
    document.head.appendChild(s);
  });

  const pay = async () => {
    const key = S.g("rp_key","")||rpKey;
    if(!key){setShowSetup(true);setT({msg:"Add Razorpay key first",type:"err"});return;}
    const ok = await loadRazorpay();
    if(!ok){setT({msg:"Could not load Razorpay. Check internet.",type:"err"});return;}
    const amountPaisa = (plan.id==="elite"?100000:plan.id==="pro"?75000:25000)*100;
    const options = {
      key,
      amount: amountPaisa,
      currency: "INR",
      name: "Edunex School OS",
      description: `${plan.name} Plan — Monthly Subscription`,
      image: "https://edunex.in/logo.png",
      prefill:{name:school.principal,email:school.email,contact:school.phone||""},
      notes:{school_id:school.id,school_name:school.name,plan:plan.id},
      theme:{color:"#C9973A"},
      handler: resp => {
        setT({msg:`✅ Payment successful! ID: ${resp.razorpay_payment_id}`});
        S.s("last_payment_"+school.id,{id:resp.razorpay_payment_id,date:new Date().toISOString(),amount:amountPaisa/100,plan:plan.id});
      },
    };
    new window.Razorpay(options).open();
  };

  const lastPayment = S.g("last_payment_"+school.id,null);
  const invoices = lastPayment
    ?[{id:lastPayment.id?.slice(-8)||"INV001",date:new Date(lastPayment.date).toLocaleDateString("en-IN"),amount:`₹${lastPayment.amount?.toLocaleString("en-IN")}`,status:"paid"}]
    :[{id:"INV-PENDING",date:new Date().toLocaleDateString("en-IN"),amount:plan.price,status:"pending"}];

  return (
    <div className="pin">
      {toast&&<Toast msg={toast.msg} type={toast.type} onDone={()=>setT(null)}/>}
      <SH tag="Subscription" title="Billing & Plans" sub="Manage your subscription · Razorpay secure payments"/>

      {LAUNCH_OFFER.active&&(
        <div style={{padding:"1.2rem 1.6rem",background:"linear-gradient(135deg,rgba(245,166,35,.08),rgba(124,92,255,.05))",border:"1px solid rgba(245,166,35,.25)",borderRadius:14,marginBottom:"1.75rem",display:"flex",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:"1rem"}}>
          <div>
            <div style={{fontFamily:"'Playfair Display',serif",fontSize:"1rem",fontWeight:800,color:D.gold,marginBottom:".3rem"}}>🚀 Founding School Offer</div>
            <div style={{fontSize:".86rem",color:D.t2,lineHeight:1.6}}>{LAUNCH_OFFER.msg}</div>
          </div>
          <div style={{textAlign:"center",flexShrink:0,background:"rgba(245,166,35,.1)",border:"1px solid rgba(245,166,35,.3)",borderRadius:12,padding:".8rem 1.2rem"}}>
            <div style={{fontFamily:"'Playfair Display',serif",fontSize:"2rem",fontWeight:800,color:D.gold}}>{LAUNCH_OFFER.spotsLeft}</div>
            <div style={{fontSize:".72rem",color:D.t2}}>spots left</div>
          </div>
        </div>
      )}

      {showSetup&&(
        <Card style={{marginBottom:"1.5rem",border:"1px solid rgba(245,166,35,.2)"}}>
          <div style={{fontSize:".63rem",letterSpacing:".16em",textTransform:"uppercase",color:D.gold,marginBottom:"1rem",fontWeight:600}}>Connect Razorpay</div>
          <div style={{display:"flex",gap:".8rem"}}>
            <Inp label="Razorpay Key ID (starts with rzp_)" value={rpKey} onChange={setRpKey} placeholder="rzp_live_XXXXXXXXXX" style={{flex:1}}/>
            <Btn v="gold" onClick={()=>{if(!rpKey){setT({msg:"Enter Razorpay key",type:"err"});return;}S.s("rp_key",rpKey);setShowSetup(false);setT({msg:"✅ Razorpay connected!"});}} style={{alignSelf:"flex-end"}}>Connect</Btn>
          </div>
          <div style={{marginTop:".8rem",fontSize:".76rem",color:D.t3}}>Get key: <span style={{color:D.gold}}>razorpay.com → Settings → API Keys → Generate Key</span></div>
        </Card>
      )}

      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"1.25rem",marginBottom:"1.5rem"}}>
        <Card style={{border:`1px solid ${plan.color}25`,background:`${plan.color}04`}}>
          <div style={{fontSize:".63rem",letterSpacing:".16em",textTransform:"uppercase",color:plan.color,marginBottom:"1rem",fontWeight:600}}>Current Plan</div>
          <div style={{fontFamily:"'Playfair Display',serif",fontSize:"1.5rem",fontWeight:800,color:plan.color,marginBottom:".25rem"}}>{plan.name}</div>
          <div style={{fontFamily:"'Playfair Display',serif",fontSize:"2.5rem",fontWeight:800,color:D.t0,letterSpacing:"-.02em",lineHeight:1,marginBottom:".4rem"}}>{plan.price}</div>
          <div style={{fontSize:".8rem",color:D.t2,marginBottom:"1.2rem"}}>{plan.students} · Billed monthly</div>
          {S.g("rp_key","")&&<div style={{fontSize:".72rem",color:D.green,marginBottom:"1rem",display:"flex",alignItems:"center",gap:".4rem"}}><span style={{width:6,height:6,borderRadius:"50%",background:D.green}}/>Razorpay connected · Auto-billing active</div>}
          <Btn v="gold" full onClick={pay} style={{padding:".9rem",fontFamily:"'Playfair Display',serif",fontWeight:700}}>💳 Pay {plan.price} Now</Btn>
        </Card>
        <div style={{display:"flex",flexDirection:"column",gap:".75rem"}}>
          <div style={{fontSize:".63rem",letterSpacing:".16em",textTransform:"uppercase",color:D.cyan,fontWeight:600}}>Other Plans</div>
          {PLANS.filter(p=>p.id!==school.plan).map(p=>(
            <div key={p.id} style={{padding:"1rem 1.2rem",background:"rgba(255,255,255,.7)",border:`1px solid ${D.b0}`,borderRadius:12,display:"flex",justifyContent:"space-between",alignItems:"center",transition:"all .2s",cursor:"pointer"}}
              onMouseEnter={e=>e.currentTarget.style.borderColor=p.color}
              onMouseLeave={e=>e.currentTarget.style.borderColor=D.b0}>
              <div>
                <div style={{fontFamily:"'Playfair Display',serif",fontWeight:700,color:p.color}}>{p.name}</div>
                <div style={{fontSize:".75rem",color:D.t3,marginTop:".15rem"}}>{p.students}</div>
              </div>
              <div style={{textAlign:"right"}}>
                <div style={{fontFamily:"'Playfair Display',serif",fontWeight:700,color:p.color}}>{p.price}</div>
                <Btn v="ghost" sm style={{marginTop:".4rem"}} onClick={()=>setT({msg:`Contact hello@edunex.in to upgrade to ${p.name}`,type:"info"})}>Upgrade</Btn>
              </div>
            </div>
          ))}
          <div style={{padding:"1rem",background:"rgba(124,92,255,.04)",border:"1px solid rgba(201,151,58,.1)",borderRadius:10,fontSize:".8rem",color:D.t2,lineHeight:1.6}}>
            💡 <strong style={{color:D.cyan}}>Launch Offer:</strong> First 10 schools get Elite features at ₹25,000/mo. Contact hello@edunex.in
          </div>
        </div>
      </div>
      <Card>
        <div style={{fontSize:".63rem",letterSpacing:".16em",textTransform:"uppercase",color:D.cyan,marginBottom:"1rem",fontWeight:600}}>Payment History</div>
        <div style={{background:"rgba(255,255,255,.6)",border:`1px solid ${D.b0}`,borderRadius:10,overflow:"hidden"}}>
          <table style={{width:"100%",borderCollapse:"collapse"}}>
            <thead><tr style={{background:"rgba(0,0,0,.03)"}}>
              {["ID","Date","Amount","Status",""].map(h=><th key={h} style={{padding:".75rem 1rem",textAlign:"left",fontSize:".62rem",letterSpacing:".1em",textTransform:"uppercase",color:D.t3,fontWeight:600,borderBottom:`1px solid ${D.b0}`}}>{h}</th>)}
            </tr></thead>
            <tbody>
              {invoices.map(inv=>(
                <tr key={inv.id} style={{borderBottom:`1px solid ${D.b0}`}}>
                  <td style={{padding:".75rem 1rem",fontSize:".82rem",color:D.t2,fontFamily:"monospace"}}>{inv.id}</td>
                  <td style={{padding:".75rem 1rem",fontSize:".8rem",color:D.t2}}>{inv.date}</td>
                  <td style={{padding:".75rem 1rem",fontSize:".84rem",fontWeight:600,color:D.t1}}>{inv.amount}</td>
                  <td style={{padding:".75rem 1rem"}}><Badge c={inv.status==="paid"?"green":"gold"}>{inv.status}</Badge></td>
                  <td style={{padding:".75rem 1rem"}}><Btn v="ghost" sm onClick={()=>setT({msg:"Receipt emailed to "+school.email,type:"info"})}>📧 Receipt</Btn></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
};

// ══════════════════════════════════════════════════
// AUTO AGENT PAGE
// ══════════════════════════════════════════════════
const PgAgent = ({school}) => {
  const [students] = useD2(school.id,"students");
  const [fees]     = useD2(school.id,"fees");
  const [calls]    = useD2(school.id,"calls");
  const [agentOn,setAgentOn] = useState(()=>S.g("agent_on_"+school.id,false));
  const [toast,setT] = useState(null);
  const [running,setRunning] = useState(null);

  const toggleAgent = () => {
    const next=!agentOn;
    setAgentOn(next);
    S.s("agent_on_"+school.id,next);
    setT({msg:next?"🤖 Auto Agent ACTIVE! Runs daily automatically":"Agent paused.",type:next?"ok":"info"});
  };

  const runNow = async type => {
    setRunning(type);
    await new Promise(r=>setTimeout(r,3000));
    setRunning(null);
    const count=type==="absent"?students.filter(s=>s.absent).length:fees.filter(f=>f.due>0).length;
    setT({msg:`✅ ${type==="absent"?"Absence":"Fee"} agent ran — ${count} calls initiated`});
  };

  const absent=students.filter(s=>s.absent).length;
  const pending=fees.filter(f=>f.due>0).length;
  const class10=students.filter(s=>s.cls?.startsWith("10")).length;

  const schedule=[
    {time:"5:00 AM",icon:"🔔",title:"Class 10 Alarm Agent",desc:"Calls all Class 10 students in Telugu — exam preparation reminder",color:D.purp,type:"alarm"},
    {time:"7:00–8:30 AM",icon:"🚌",title:"Morning Bus Agent",desc:"Live GPS tracking active — WhatsApp ETA alerts sent to parents",color:D.green,type:"bus_morning"},
    {time:"9:00 AM",icon:"📵",title:"Absence Call Agent",desc:"Detects absent students → calls every parent in Telugu automatically",color:D.red,type:"absent"},
    {time:"11:00 AM",icon:"💳",title:"Fee Reminder Agent",desc:"Checks overdue fees → auto-calls + WhatsApp payment reminder",color:D.gold,type:"fee"},
    {time:"4:30–6:00 PM",icon:"🚌",title:"Evening Bus Agent",desc:"Live GPS tracking active — pickup alerts sent when bus is 2 stops away",color:D.green,type:"bus_evening"},
    {time:"6:00 PM",icon:"📊",title:"Daily Report Agent",desc:"Emails full day summary to principal — attendance, fees, calls, buses",color:D.cyan,type:"report"},
  ];

  return (
    <div className="pin">
      {toast&&<Toast msg={toast.msg} type={toast.type} onDone={()=>setT(null)}/>}
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",flexWrap:"wrap",gap:"1rem",marginBottom:"1.75rem"}}>
        <SH tag="AI Automation" title="Auto Agent" sub="Fully autonomous — runs every day with zero human involvement"/>
        <div style={{display:"flex",alignItems:"center",gap:"1rem"}}>
          <div style={{fontSize:".8rem",color:agentOn?D.green:D.t3,fontWeight:600,display:"flex",alignItems:"center",gap:".4rem"}}>
            <span style={{width:8,height:8,borderRadius:"50%",background:agentOn?D.green:D.t3,animation:agentOn?"pulse 2s infinite":"none"}}/>
            {agentOn?"Agent Active":"Agent Paused"}
          </div>
          <button onClick={toggleAgent}
            style={{width:52,height:28,borderRadius:14,background:agentOn?D.green:"rgba(0,0,0,.1)",border:"none",cursor:"pointer",position:"relative",transition:"background .3s",boxShadow:agentOn?`0 0 16px rgba(16,217,160,.4)`:"none"}}>
            <div style={{width:22,height:22,borderRadius:"50%",background:"#fff",position:"absolute",top:3,left:agentOn?27:3,transition:"left .3s",boxShadow:"0 2px 6px rgba(0,0,0,.06)"}}/>
          </button>
        </div>
      </div>

      {agentOn?(
        <div style={{padding:"1.2rem 1.6rem",background:"rgba(16,217,160,.06)",border:"1px solid rgba(16,217,160,.2)",borderRadius:14,marginBottom:"1.75rem",display:"flex",alignItems:"center",gap:"1rem"}}>
          <div style={{width:42,height:42,borderRadius:"50%",background:"rgba(16,217,160,.12)",border:`2px solid ${D.green}`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:"1.2rem",flexShrink:0,animation:"pulse 2s infinite"}}>🤖</div>
          <div>
            <div style={{fontFamily:"'Playfair Display',serif",fontWeight:700,color:D.green,marginBottom:".2rem"}}>Agent is LIVE — Running every day automatically</div>
            <div style={{fontSize:".82rem",color:D.t2}}>5 AM alarm (Class 10) · 9 AM absence calls · Bus GPS 7–8:30 AM & 4:30–6 PM · 11 AM fee reminders · 6 PM reports</div>
          </div>
        </div>
      ):(
        <div style={{padding:"1rem 1.4rem",background:"rgba(255,255,255,.5)",border:`1px solid ${D.b1}`,borderRadius:14,marginBottom:"1.75rem"}}>
          <div style={{fontSize:".84rem",color:D.t2}}>⏸️ Agent paused. Toggle ON above to start daily automation. Once active, all calls and reports run automatically.</div>
        </div>
      )}

      <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:"1rem",marginBottom:"1.75rem"}}>
        {[[`🔔 ${class10}`,`Class 10 Students`,D.purp],[`📵 ${absent}`,`Absent Today`,D.red],[`💳 ${pending}`,`Fee Overdue`,D.gold],[`📞 ${calls.length}`,`Calls Made`,D.cyan]].map(([v,l,color])=>(
          <Card key={l}>
            <div style={{fontFamily:"'Playfair Display',serif",fontSize:"1.4rem",fontWeight:800,color,letterSpacing:"-.02em"}}>{v}</div>
            <div style={{fontSize:".76rem",color:D.t2,marginTop:".2rem"}}>{l}</div>
          </Card>
        ))}
      </div>

      <div style={{display:"flex",flexDirection:"column",gap:".8rem",marginBottom:"1.75rem"}}>
        {schedule.map((item,i)=>(
          <Card key={i} style={{display:"flex",alignItems:"center",gap:"1rem"}}>
            <div style={{width:90,textAlign:"center",flexShrink:0}}>
              <div style={{fontSize:".68rem",fontWeight:700,color:item.color,background:`${item.color}12`,border:`1px solid ${item.color}20`,padding:".3rem .5rem",borderRadius:7}}>{item.time}</div>
            </div>
            <div style={{width:32,height:32,borderRadius:"50%",background:`${item.color}12`,border:`1px solid ${item.color}25`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:"1rem",flexShrink:0}}>{item.icon}</div>
            <div style={{flex:1}}>
              <div style={{fontSize:".86rem",fontWeight:600,color:D.t1}}>{item.title}</div>
              <div style={{fontSize:".76rem",color:D.t3,marginTop:".15rem"}}>{item.desc}</div>
            </div>
            <div style={{display:"flex",gap:".5rem",flexShrink:0,alignItems:"center"}}>
              <Badge c={agentOn?"green":"gray"} dot>daily</Badge>
              {["absent","fee"].includes(item.type)&&(
                <Btn v="ghost" sm onClick={()=>runNow(item.type)} disabled={!!running}>
                  {running===item.type?<><Spin/>Running…</>:"▶ Run Now"}
                </Btn>
              )}
            </div>
          </Card>
        ))}
      </div>

      <Card style={{border:"1px solid rgba(201,151,58,.15)",background:"rgba(124,92,255,.04)"}}>
        <div style={{fontSize:".63rem",letterSpacing:".16em",textTransform:"uppercase",color:D.cyan,marginBottom:".85rem",fontWeight:600}}>⚡ To enable full automation — deploy on Vercel</div>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"1rem",fontSize:".82rem",color:D.t2,lineHeight:1.8}}>
          <div>
            {["1. Deploy app on Vercel (free)","2. Add exotel-agent.js as API route","3. Add email-agent.js as API route","4. Set Vercel Cron (vercel.json)","5. Add .env with API keys"].map(s=><div key={s}>{s}</div>)}
          </div>
          <pre style={{fontSize:".7rem",background:"rgba(0,0,0,.08)",padding:".75rem",borderRadius:8,color:D.green,overflow:"auto",lineHeight:1.6}}>
{`// vercel.json
{ "crons": [
  { "path": "/api/alarm-agent",
    "schedule": "30 23 * * *" },
  { "path": "/api/daily-agent",
    "schedule": "30 3 * * *" },
  { "path": "/api/fee-agent",
    "schedule": "30 5 * * *" },
  { "path": "/api/report-agent",
    "schedule": "30 12 * * *" }
]}`}
          </pre>
        </div>
      </Card>
    </div>
  );
};

// ══════════════════════════════════════════════════
// AI VIDEO GENERATOR
// ══════════════════════════════════════════════════
const PgVideo = ({school}) => {
  const [photo,setPhoto]       = useState(school.principalPhoto||null);
  const [script,setScript]     = useState("");
  const [voice,setVoice]       = useState("en-US-JennyNeural");
  const [lang,setLang]         = useState("English");
  const [scriptMode,setScriptMode] = useState("auto"); // auto | custom
  const [gen,setGen]           = useState(false);
  const [prog,setPrg]          = useState(0);
  const [progMsg,setProgMsg]   = useState("");
  const [result,setResult]     = useState(null);
  const [videoUrl,setVideoUrl] = useState(null);
  const [toast,setT]           = useState(null);
  const [didKey,setDidKey]     = useState(school.didKey||"bGFuZG9mYW5pbWUxQGdtYWlsLmNvbQ:doSR4BwJUJSvLP9DEWQgZ");
  const [showSetup,setShowSetup] = useState(false);
  // Auto-save D-ID key
  useEffect(()=>{ S.s("did_key","bGFuZG9mYW5pbWUxQGdtYWlsLmNvbQ:doSR4BwJUJSvLP9DEWQgZ"); },[]);
  const [videos,setVideos]     = useState(()=>S.g("videos_"+school.id,[]));
  const [dragOver,setDragOver] = useState(false);

  // Auto-generate script based on school info
  const autoScript = {
    English:`Welcome to ${school.name}!

We are a premier ${school.board} school located in ${school.city}, committed to nurturing young minds and building tomorrow's leaders.

Our school offers world-class education with experienced teachers, modern classrooms, GPS-tracked buses, and a dedicated parent app for real-time updates.

From academics to sports, from arts to technology — we develop every child's full potential.

Admissions are now open for the academic year ${new Date().getFullYear()+1}-${new Date().getFullYear()+2}.

Contact us today. ${school.name} — where every child shines.`,

    Telugu:`${school.name}కి స్వాగతం!

మేము ${school.city}లో ఉన్న అత్యుత్తమ ${school.board} పాఠశాల. మా లక్ష్యం ప్రతి విద్యార్థిని అత్యుత్తమ స్థాయికి తీసుకెళ్ళడం.

అనుభవజ్ఞులైన ఉపాధ్యాయులు, ఆధునిక తరగతి గదులు, GPS బస్ ట్రాకింగ్, మరియు తల్లిదండ్రుల యాప్ — అన్నీ మీ పిల్లల కోసమే.

${new Date().getFullYear()+1}-${new Date().getFullYear()+2} విద్యా సంవత్సరానికి అడ్మిషన్లు ప్రారంభమయ్యాయి.

ఇప్పుడే సంప్రదించండి. ${school.name} — ప్రతి పిల్లవాడూ మెరిసే చోటు.`,

    Hindi:`${school.name} में आपका स्वागत है!

हम ${school.city} में स्थित एक प्रमुख ${school.board} विद्यालय हैं, जो हर बच्चे की प्रतिभा को निखारने के लिए समर्पित है।

अनुभवी शिक्षक, आधुनिक कक्षाएं, GPS बस ट्रैकिंग और पेरेंट ऐप — सब कुछ आपके बच्चे की सफलता के लिए।

शैक्षणिक वर्ष ${new Date().getFullYear()+1}-${new Date().getFullYear()+2} के लिए प्रवेश शुरू हो गए हैं।

आज ही संपर्क करें। ${school.name} — जहाँ हर बच्चा चमकता है।`,
  };

  const voices = {
    English:[
      {v:"en-US-JennyNeural",l:"Jenny — Female (US)"},
      {v:"en-US-GuyNeural",l:"Guy — Male (US)"},
      {v:"en-IN-NeerjaNeural",l:"Neerja — Female (India)"},
      {v:"en-IN-PrabhatNeural",l:"Prabhat — Male (India)"},
    ],
    Telugu:[
      {v:"te-IN-ShrutiNeural",l:"Shruti — Female (Telugu)"},
      {v:"te-IN-MohanNeural",l:"Mohan — Male (Telugu)"},
    ],
    Hindi:[
      {v:"hi-IN-SwaraNeural",l:"Swara — Female (Hindi)"},
      {v:"hi-IN-MadhurNeural",l:"Madhur — Male (Hindi)"},
    ],
  };

  const handlePhoto = e => {
    const file = e.target.files?.[0] || e.dataTransfer?.files?.[0];
    if(!file) return;
    if(!file.type.startsWith("image/")){setT({msg:"Please upload an image file (JPG, PNG)",type:"err"});return;}
    if(file.size>5*1024*1024){setT({msg:"Image too large. Max 5MB.",type:"err"});return;}
    const reader = new FileReader();
    reader.onload = ev => setPhoto(ev.target.result);
    reader.readAsDataURL(file);
  };

  // ── REAL D-ID API CALL ────────────────────────────
  const generateWithDID = async (photoBase64, scriptText) => {
    const key = "bGFuZG9mYW5pbWUxQGdtYWlsLmNvbQ:doSR4BwJUJSvLP9DEWQgZ"||S.g("did_key","")||didKey;

    // Step 1: Upload image to D-ID
    const uploadRes = await fetch("https://api.d-id.com/images",{
      method:"POST",
      headers:{"Authorization":`Basic ${key}`,"Content-Type":"application/json"},
      body:JSON.stringify({url: photoBase64}),
    });
    if(!uploadRes.ok) throw new Error("Image upload failed");
    const {url: imageUrl} = await uploadRes.json();

    // Step 2: Create talking video
    const talkRes = await fetch("https://api.d-id.com/talks",{
      method:"POST",
      headers:{"Authorization":`Basic ${key}`,"Content-Type":"application/json"},
      body:JSON.stringify({
        source_url: imageUrl,
        script:{
          type: "text",
          input: scriptText,
          provider:{
            type:"microsoft",
            voice_id: voice,
          },
        },
        config:{fluent:true, pad_audio:0.5, stitch:true},
      }),
    });
    if(!talkRes.ok){const e=await talkRes.json();throw new Error(e.description||"D-ID API error");}
    const {id: talkId} = await talkRes.json();

    // Step 3: Poll for completion
    for(let i=0;i<30;i++){
      await new Promise(r=>setTimeout(r,3000));
      const statusRes = await fetch(`https://api.d-id.com/talks/${talkId}`,{
        headers:{"Authorization":`Basic ${key}`},
      });
      const statusData = await statusRes.json();
      setPrg(Math.min(90, 40 + i*2));
      setProgMsg(`Rendering video… ${Math.min(90,40+i*2)}%`);
      if(statusData.status==="done") return statusData.result_url;
      if(statusData.status==="error") throw new Error(statusData.error?.description||"Rendering failed");
    }
    throw new Error("Video generation timed out");
  };

  const generate = async () => {
    if(!photo){setT({msg:"Upload a photo of the principal first",type:"err"});return;}
    const scriptText = scriptMode==="auto" ? autoScript[lang]||autoScript.English : script;
    if(!scriptText.trim()){setT({msg:"Enter a script or use auto-generate",type:"err"});return;}

    setGen(true);setPrg(0);setResult(null);setVideoUrl(null);

    const steps=[
      {p:10,msg:"Uploading photo to D-ID…"},
      {p:25,msg:"Analyzing facial features…"},
      {p:40,msg:"Generating AI voice…"},
      {p:60,msg:"Syncing lips to speech…"},
      {p:80,msg:"Rendering talking video…"},
    ];

    try {
      const key = "bGFuZG9mYW5pbWUxQGdtYWlsLmNvbQ:doSR4BwJUJSvLP9DEWQgZ"||S.g("did_key","")||didKey;

      if(key){
        // Real D-ID API
        for(const step of steps){
          await new Promise(r=>setTimeout(r,600));
          setPrg(step.p);setProgMsg(step.msg);
        }
        const url = await generateWithDID(photo, scriptText);
        setVideoUrl(url);setPrg(100);setProgMsg("Done! Video ready.");
      } else {
        // Simulate if no key
        for(const step of steps){
          await new Promise(r=>setTimeout(r,900));
          setPrg(step.p);setProgMsg(step.msg+" (simulation)");
        }
        await new Promise(r=>setTimeout(r,600));setPrg(100);
      }

      const video = {
        id:"v"+Date.now(),
        title:`${school.name} — Talking Video`,
        lang,voice,
        date:new Date().toLocaleDateString("en-IN"),
        status:"ready",
        url:videoUrl||null,
        script:scriptText.slice(0,80)+"…",
      };
      const updated=[video,...videos];
      setVideos(updated);S.s("videos_"+school.id,updated);
      setResult(video);setGen(false);
      setT({msg:key?"🎬 Talking video ready! Principal photo is speaking!":"Script ready! Add D-ID key for real video."});
    } catch(err){
      setGen(false);setPrg(0);setProgMsg("");
      setT({msg:"Error: "+err.message,type:"err"});
    }
  };

  const currentVoices = voices[lang]||voices.English;

  return (
    <div className="pin">
      {toast&&<Toast msg={toast.msg} type={toast.type} onDone={()=>setT(null)}/>}
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",flexWrap:"wrap",gap:"1rem",marginBottom:"1.75rem"}}>
        <SH tag="AI Talking Video" title="Talking Photo Video" sub="Upload principal photo → AI makes it speak → Share on WhatsApp instantly"/>
        {S.g("did_key","")
          ?<div style={{display:"flex",alignItems:"center",gap:".4rem",fontSize:".76rem",color:D.green,background:"rgba(16,217,160,.1)",border:"1px solid rgba(16,217,160,.2)",padding:".3rem .8rem",borderRadius:20,fontWeight:600}}><span style={{width:6,height:6,borderRadius:"50%",background:D.green}}/>D-ID Connected</div>
          :<Btn v="gold" sm onClick={()=>setShowSetup(true)}>🎬 Connect D-ID API</Btn>}
      </div>

      {/* D-ID Setup */}
      {showSetup&&(
        <Card style={{marginBottom:"1.5rem",border:"1px solid rgba(245,166,35,.25)"}}>
          <div style={{fontSize:".63rem",letterSpacing:".16em",textTransform:"uppercase",color:D.gold,marginBottom:"1rem",fontWeight:600}}>🎬 Connect D-ID API</div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"1rem",marginBottom:"1rem"}}>
            <div style={{padding:".9rem",background:"rgba(16,217,160,.05)",border:"1px solid rgba(16,217,160,.15)",borderRadius:9,fontSize:".8rem",color:D.t2,lineHeight:1.7}}>
              <div style={{color:D.green,fontWeight:600,marginBottom:".3rem"}}>✓ What D-ID does</div>
              Photo → Talking video<br/>
              Realistic lip sync<br/>
              Telugu/English voice<br/>
              30s video = ₹4 cost
            </div>
            <div style={{padding:".9rem",background:"rgba(245,166,35,.05)",border:"1px solid rgba(245,166,35,.15)",borderRadius:9,fontSize:".8rem",color:D.t2,lineHeight:1.7}}>
              <div style={{color:D.gold,fontWeight:600,marginBottom:".3rem"}}>💰 Revenue</div>
              Charge school ₹500/video<br/>
              Your cost ₹4/video<br/>
              Profit ₹496/video<br/>
              Free trial: 5 min
            </div>
          </div>
          <div style={{display:"flex",gap:".8rem"}}>
            <Inp label="D-ID API Key" value={didKey} onChange={setDidKey} placeholder="Your D-ID Basic API key" style={{flex:1}}/>
            <Btn v="gold" onClick={()=>{if(!didKey){setT({msg:"Enter API key",type:"err"});return;}S.s("did_key",didKey);setShowSetup(false);setT({msg:"🎬 D-ID connected! Talking videos ready."});}} style={{alignSelf:"flex-end"}}>Connect</Btn>
          </div>
          <div style={{marginTop:".8rem",fontSize:".76rem",color:D.t3}}>
            Get free key: <span style={{color:D.gold}}>d-id.com → Get Started Free → API → Create Key</span> · 5 min free trial
          </div>
          <Btn v="ghost" sm onClick={()=>setShowSetup(false)} style={{marginTop:".8rem"}}>Skip — preview mode</Btn>
        </Card>
      )}

      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"1.25rem"}}>

        {/* LEFT — Controls */}
        <div style={{display:"flex",flexDirection:"column",gap:"1rem"}}>

          {/* Photo upload */}
          <Card>
            <div style={{fontSize:".63rem",letterSpacing:".16em",textTransform:"uppercase",color:D.gold,marginBottom:"1rem",fontWeight:600}}>Step 1 — Upload Principal Photo</div>
            <label
              onDragOver={e=>{e.preventDefault();setDragOver(true);}}
              onDragLeave={()=>setDragOver(false)}
              onDrop={e=>{e.preventDefault();setDragOver(false);handlePhoto(e);}}
              style={{display:"block",cursor:"pointer"}}>
              {photo?(
                <div style={{position:"relative",textAlign:"center"}}>
                  <img src={photo} alt="Principal" style={{width:140,height:140,borderRadius:"50%",objectFit:"cover",border:`3px solid ${D.gold}`,boxShadow:`0 0 24px rgba(245,166,35,.3)`}}/>
                  <div style={{position:"absolute",bottom:4,right:"calc(50% - 85px)",width:28,height:28,borderRadius:"50%",background:D.goldG,display:"flex",alignItems:"center",justifyContent:"center",fontSize:".85rem",cursor:"pointer"}} onClick={e=>{e.preventDefault();setPhoto(null);}}>✕</div>
                  <div style={{fontSize:".76rem",color:D.green,marginTop:".6rem",fontWeight:600}}>✅ Photo ready · Click to change</div>
                </div>
              ):(
                <div style={{border:`2px dashed ${dragOver?"rgba(245,166,35,.6)":D.b1}`,borderRadius:12,padding:"2rem",textAlign:"center",transition:"all .25s",background:dragOver?"rgba(245,166,35,.04)":"transparent"}}>
                  <div style={{fontSize:"2.5rem",marginBottom:".6rem"}}>🤳</div>
                  <div style={{fontFamily:"'Playfair Display',serif",fontWeight:700,color:D.t1,marginBottom:".3rem"}}>Drop Principal Photo Here</div>
                  <div style={{fontSize:".78rem",color:D.t2,marginBottom:"1rem"}}>Clear front-facing photo works best · JPG or PNG · Max 5MB</div>
                  <div style={{display:"inline-block",background:D.goldG,color:"#000",padding:".55rem 1.3rem",borderRadius:8,fontWeight:700,fontSize:".84rem"}}>Choose Photo</div>
                </div>
              )}
              <input type="file" accept="image/*" onChange={handlePhoto} style={{display:"none"}}/>
            </label>
          </Card>

          {/* Script */}
          <Card>
            <div style={{fontSize:".63rem",letterSpacing:".16em",textTransform:"uppercase",color:D.gold,marginBottom:"1rem",fontWeight:600}}>Step 2 — Script</div>
            <div style={{display:"flex",border:`1px solid ${D.b1}`,borderRadius:9,overflow:"hidden",marginBottom:"1rem"}}>
              {[["auto","✨ Auto Generate"],["custom","✏️ Write My Own"]].map(([v,l])=>(
                <button key={v} onClick={()=>setScriptMode(v)}
                  style={{flex:1,padding:".55rem",fontSize:".78rem",fontWeight:600,background:scriptMode===v?D.goldG:"transparent",color:scriptMode===v?"#000":D.t2,border:"none",cursor:"pointer",transition:"all .2s"}}>
                  {l}
                </button>
              ))}
            </div>
            {scriptMode==="auto"?(
              <div>
                <Inp label="Language" as="select" value={lang} onChange={v=>{setLang(v);setVoice(voices[v]?.[0]?.v||voice);}} opts={Object.keys(voices).map(v=>({v,l:v}))}/>
                <div style={{marginTop:".8rem",padding:".9rem",background:"rgba(255,255,255,.5)",border:`1px solid ${D.b0}`,borderRadius:9,fontSize:".78rem",color:D.t2,lineHeight:1.7,maxHeight:120,overflowY:"auto",fontStyle:"italic"}}>
                  {autoScript[lang]||autoScript.English}
                </div>
                <div style={{fontSize:".7rem",color:D.t3,marginTop:".4rem"}}>Auto-generated for {school.name} · {school.board}</div>
              </div>
            ):(
              <div style={{display:"flex",flexDirection:"column",gap:".8rem"}}>
                <Inp label="Language" as="select" value={lang} onChange={v=>{setLang(v);setVoice(voices[v]?.[0]?.v||voice);}} opts={Object.keys(voices).map(v=>({v,l:v}))}/>
                <Inp label="Your Script" as="textarea" value={script} onChange={setScript} placeholder="Type what the principal will say… Keep it under 100 words for 30s video." rows={5}/>
                <div style={{fontSize:".72rem",color:script.length>100?D.gold:D.t3}}>{script.split(" ").filter(Boolean).length} words · ~{Math.round(script.split(" ").filter(Boolean).length/2.5)}s video</div>
              </div>
            )}
          </Card>

          {/* Voice */}
          <Card>
            <div style={{fontSize:".63rem",letterSpacing:".16em",textTransform:"uppercase",color:D.gold,marginBottom:"1rem",fontWeight:600}}>Step 3 — Choose Voice</div>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:".5rem"}}>
              {currentVoices.map(v=>(
                <div key={v.v} onClick={()=>setVoice(v.v)}
                  style={{padding:".65rem .8rem",background:voice===v.v?"rgba(245,166,35,.08)":"rgba(0,0,0,.04)",border:`1px solid ${voice===v.v?"rgba(245,166,35,.4)":D.b0}`,borderRadius:9,cursor:"pointer",transition:"all .2s"}}>
                  <div style={{fontSize:".8rem",fontWeight:500,color:voice===v.v?D.gold:D.t1}}>{v.l}</div>
                </div>
              ))}
            </div>
          </Card>

          {/* Generate button */}
          {gen?(
            <div style={{padding:"1.2rem",background:"rgba(245,166,35,.05)",border:"1px solid rgba(245,166,35,.2)",borderRadius:12}}>
              <div style={{display:"flex",justifyContent:"space-between",fontSize:".76rem",marginBottom:".6rem"}}>
                <span style={{color:D.gold,animation:"pulse 1.5s infinite"}}>{progMsg||"Processing…"}</span>
                <span style={{color:D.gold,fontWeight:700}}>{prog}%</span>
              </div>
              <div style={{height:5,background:"rgba(0,0,0,.08)",borderRadius:3,overflow:"hidden"}}>
                <div style={{width:`${prog}%`,height:"100%",background:D.goldG,borderRadius:3,transition:"width .5s ease"}}/>
              </div>
              <div style={{fontSize:".7rem",color:D.t3,marginTop:".5rem",display:"flex",alignItems:"center",gap:".4rem"}}><Spin/>D-ID is rendering your talking video…</div>
            </div>
          ):(
            <Btn v="gold" onClick={generate} full style={{padding:"1rem",fontFamily:"'Playfair Display',serif",fontWeight:700,fontSize:"1rem"}}>
              🎬 Generate Talking Video
            </Btn>
          )}
        </div>

        {/* RIGHT — Preview & History */}
        <div style={{display:"flex",flexDirection:"column",gap:"1rem"}}>

          {/* Video preview */}
          <Card style={{minHeight:300,display:"flex",flexDirection:"column"}}>
            <div style={{fontSize:".63rem",letterSpacing:".16em",textTransform:"uppercase",color:D.gold,marginBottom:"1rem",fontWeight:600}}>Video Preview</div>
            {videoUrl?(
              <div style={{flex:1}}>
                <video src={videoUrl} controls style={{width:"100%",borderRadius:10,background:"#000"}} autoPlay/>
                <div style={{display:"flex",gap:".6rem",marginTop:"1rem"}}>
                  <Btn v="gold" style={{flex:1}} onClick={()=>window.open(videoUrl,"_blank")}>⬇️ Download MP4</Btn>
                  <Btn v="ghost" style={{flex:1}} onClick={()=>{navigator.clipboard?.writeText(videoUrl);setT({msg:"Video link copied!"});}}>🔗 Copy Link</Btn>
                </div>
              </div>
            ):result&&!videoUrl?(
              <div style={{flex:1,display:"flex",flexDirection:"column",gap:".8rem"}}>
                <div style={{padding:"1.2rem",background:"rgba(16,217,160,.06)",border:"1px solid rgba(16,217,160,.2)",borderRadius:10,textAlign:"center"}}>
                  <div style={{fontSize:"1.5rem",marginBottom:".5rem"}}>✅</div>
                  <div style={{fontFamily:"'Playfair Display',serif",fontWeight:700,color:D.green,marginBottom:".3rem"}}>Script Generated!</div>
                  <div style={{fontSize:".8rem",color:D.t2}}>Add D-ID API key above to generate the real talking video</div>
                </div>
                {photo&&(
                  <div style={{textAlign:"center"}}>
                    <img src={photo} alt="" style={{width:120,height:120,borderRadius:"50%",objectFit:"cover",border:`3px solid ${D.gold}`,opacity:.7}}/>
                    <div style={{fontSize:".76rem",color:D.t3,marginTop:".4rem"}}>This photo will speak with AI voice</div>
                  </div>
                )}
              </div>
            ):(
              <div style={{flex:1,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",textAlign:"center",color:D.t3}}>
                <div style={{fontSize:"3rem",marginBottom:"1rem",opacity:.3}}>🎬</div>
                <div style={{fontFamily:"'Playfair Display',serif",color:D.t2,fontSize:"1rem",fontWeight:700,marginBottom:".5rem"}}>Your talking video appears here</div>
                <div style={{fontSize:".8rem",lineHeight:1.7}}>Upload photo + choose script<br/>then click Generate</div>
              </div>
            )}
          </Card>

          {/* How it works */}
          <Card>
            <div style={{fontSize:".63rem",letterSpacing:".16em",textTransform:"uppercase",color:D.cyan,marginBottom:"1rem",fontWeight:600}}>How It Works</div>
            {[["🤳","Upload principal photo","Clear front-facing photo, good lighting"],["✍️","Script is generated","AI writes in Telugu/English/Hindi"],["🗣️","AI voice speaks","Realistic Microsoft Neural voices"],["👄","Lips sync perfectly","D-ID makes the photo talk realistically"],["📱","Download & share","MP4 ready for WhatsApp, YouTube, Instagram"]].map(([i,t,d])=>(
              <div key={t} style={{display:"flex",gap:".75rem",padding:".6rem 0",borderBottom:`1px solid ${D.b0}`,alignItems:"flex-start"}}>
                <span style={{fontSize:"1.1rem",flexShrink:0}}>{i}</span>
                <div><div style={{fontSize:".83rem",fontWeight:500,color:D.t1}}>{t}</div><div style={{fontSize:".72rem",color:D.t3,marginTop:".1rem"}}>{d}</div></div>
              </div>
            ))}
          </Card>

          {/* Video history */}
          {videos.length>0&&(
            <Card>
              <div style={{fontSize:".63rem",letterSpacing:".16em",textTransform:"uppercase",color:D.gold,marginBottom:".9rem",fontWeight:600}}>Generated Videos ({videos.length})</div>
              {videos.slice(0,5).map(v=>(
                <div key={v.id} style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:".65rem 0",borderBottom:`1px solid ${D.b0}`}}>
                  <div>
                    <div style={{fontSize:".82rem",fontWeight:500,color:D.t1}}>{v.title}</div>
                    <div style={{fontSize:".7rem",color:D.t3,marginTop:".1rem"}}>{v.lang} · {v.date}</div>
                  </div>
                  <div style={{display:"flex",gap:".4rem",alignItems:"center"}}>
                    {v.url&&<Btn v="ghost" sm onClick={()=>window.open(v.url,"_blank")}>▶</Btn>}
                    <Badge c="green">ready</Badge>
                  </div>
                </div>
              ))}
            </Card>
          )}
        </div>
      </div>
    </div>
  );
};

// ══════════════════════════════════════════════════
// PASSWORD RESET + ONBOARDING EMAIL
// ══════════════════════════════════════════════════
const PgReset = ({school}) => {
  const [phone,setPhone]   = useState("");
  const [sent,setSent]     = useState(false);
  const [loading,setL]     = useState(false);
  const [toast,setT]       = useState(null);
  const [tab,setTab]       = useState("reset"); // reset | welcome | templates

  const TWILIO_SID   = "AC0f10643lebaes1d0a234abcdef12345";
  const TWILIO_TOKEN = "0d3c745e40c0734e0a641188bf37ed87";
  const TWILIO_FROM  = school.twilioNumber||"+15158003178";

  const sendSMS = async (to, body) => {
    try {
      const res = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${TWILIO_SID}/Messages.json`,{
        method:"POST",
        headers:{
          "Content-Type":"application/x-www-form-urlencoded",
          "Authorization":"Basic "+btoa(`${TWILIO_SID}:${TWILIO_TOKEN}`),
        },
        body:new URLSearchParams({
          From: TWILIO_FROM,
          To:   "+91"+to.replace(/\D/g,"").replace(/^0+/,"").slice(-10),
          Body: body,
        }).toString(),
      });
      const data = await res.json();
      return {success:res.ok, sid:data.sid, error:data.message};
    } catch(e){return {success:false,error:e.message};}
  };

  // Send OTP reset via SMS
  const sendReset = async () => {
    if(!phone){setT({msg:"Enter registered phone number",type:"err"});return;}
    const schools = S.g("schools",[]);
    const found = schools.find(s=>s.phone===phone||s.phone==="+91"+phone);
    if(!found){setT({msg:"Phone not found. Check and try again.",type:"err"});return;}
    setL(true);
    const otp = Math.floor(100000+Math.random()*900000);
    S.s("otp_"+phone,{otp,expires:Date.now()+600000,school:found.id});
    const msg = `నమస్కారం ${found.principal}! Your Edunex password reset OTP is: ${otp}. Valid for 10 minutes. Do not share with anyone. - ${school.name}`;
    const result = await sendSMS(phone, msg);
    setL(false);
    setSent(true);
    setT({msg:result.success?`✅ OTP sent to +91${phone}!`:"OTP sent (verify Twilio number is verified)"});
  };

  // Send welcome SMS
  const sendWelcome = async () => {
    if(!school.phone){setT({msg:"Add school phone in Settings first",type:"err"});return;}
    setL(true);
    const msg = `నమస్కారం ${school.principal} గారు! 🎉 ${school.name} Edunex లో live అయింది!

Login: edunex.in
Phone: ${school.phone}
Plan: ${school.plan?.toUpperCase()}

Features ready:
✅ Auto absence calls
✅ Fee reminders
✅ Bus tracking
✅ Parent portal
✅ AI exams

Support: hello@edunex.in`;
    const result = await sendSMS(school.phone, msg);
    setL(false);
    setT({msg:result.success?"✅ Welcome SMS sent!":"SMS sent (check Twilio verified numbers)"});
  };

  // Quick SMS templates
  const templates = [
    {icon:"🎉",title:"Welcome",msg:`నమస్కారం! ${school.name} Edunex platform లో join అయినందుకు ధన్యవాదాలు. Login: edunex.in`},
    {icon:"🔐",title:"OTP Reset",msg:`Your Edunex OTP is: [OTP]. Valid 10 minutes. - ${school.name}`},
    {icon:"📊",title:"Daily Report",msg:`${school.name} Daily Report: Total students: [X], Absent: [Y], Calls made: [Z], Fees collected: ₹[A]. - Edunex`},
    {icon:"✅",title:"Fee Receipt",msg:`నమస్కారం! ${school.name} ఫీజు ₹[AMOUNT] అందింది. Receipt no: [ID]. ధన్యవాదాలు! - Edunex`},
    {icon:"📞",title:"Call Confirmation",msg:`నమస్కారం! మీ పిల్లలు [NAME] absent కావడంతో call చేసాం. సమాచారం అందింది. - ${school.name}`},
    {icon:"🚌",title:"Bus Alert",msg:`🚌 Alert: ${school.name} bus మీ stop కి 10 minutes లో వస్తుంది. Ready గా ఉండండి!`},
    {icon:"💳",title:"Fee Reminder",msg:`నమస్కారం! ${school.name} ఫీజు [TERM] కి ₹[AMOUNT] చెల్లించవలసి ఉంది. Deadline: [DATE]. Pay: edunex.in`},
    {icon:"📅",title:"PTM Notice",msg:`${school.name} - PTM on [DATE] at [TIME]. మీ presence తప్పనిసరి. మీ పిల్లల progress discuss చేయడానికి వస్తారు!`},
  ];

  const [testPhone,setTP] = useState("");
  const [testMsg,setTMsg] = useState(templates[0].msg);
  const [sending,setSending] = useState(false);

  const sendTest = async () => {
    if(!testPhone||!testMsg){setT({msg:"Enter phone and message",type:"err"});return;}
    setSending(true);
    const result = await sendSMS(testPhone, testMsg);
    setSending(false);
    setT({msg:result.success?`✅ SMS sent to +91${testPhone}!`:"Sent (add number to Twilio verified list if trial)"});
  };

  return (
    <div className="pin">
      {toast&&<Toast msg={toast.msg} type={toast.type} onDone={()=>setT(null)}/>}
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",flexWrap:"wrap",gap:"1rem",marginBottom:"1.75rem"}}>
        <SH tag="SMS System" title="SMS Notifications" sub="Powered by Twilio · No email needed · Works on any phone"/>
        <div style={{display:"flex",alignItems:"center",gap:".5rem",background:"rgba(45,155,111,.1)",border:"1px solid rgba(45,155,111,.25)",padding:".4rem .9rem",borderRadius:20}}>
          <div style={{width:7,height:7,borderRadius:"50%",background:D.green,animation:"pulse 2s infinite"}}/>
          <span style={{fontSize:".74rem",color:D.green,fontWeight:600}}>Twilio Connected</span>
        </div>
      </div>

      {/* Tab switcher */}
      <div style={{display:"flex",gap:".4rem",marginBottom:"1.5rem",background:"rgba(0,0,0,.04)",padding:".3rem",borderRadius:10,border:"1px solid rgba(0,0,0,.08)"}}>
        {[["reset","🔐 Password Reset"],["welcome","🎉 Welcome SMS"],["templates","📋 SMS Templates"],["test","🧪 Test SMS"]].map(([t,l])=>(
          <button key={t} onClick={()=>setTab(t)}
            style={{flex:1,padding:".6rem .3rem",fontSize:".72rem",fontWeight:tab===t?700:400,
              background:tab===t?"#1A1A1A":"transparent",color:tab===t?"#fff":D.t2,
              border:"none",cursor:"pointer",borderRadius:7,transition:"all .2s"}}>
            {l}
          </button>
        ))}
      </div>

      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"1.25rem"}}>
        <div style={{display:"flex",flexDirection:"column",gap:"1rem"}}>

          {/* PASSWORD RESET */}
          {tab==="reset"&&(
            <Card>
              <div style={{fontSize:".63rem",letterSpacing:".14em",textTransform:"uppercase",color:D.cyan,marginBottom:"1rem",fontWeight:600}}>🔐 Password Reset via SMS</div>
              {!sent?(
                <div style={{display:"flex",flexDirection:"column",gap:".9rem"}}>
                  <div style={{position:"relative"}}>
                    <span style={{position:"absolute",left:".9rem",top:"50%",transform:"translateY(-50%)",fontSize:".84rem",color:D.t3,pointerEvents:"none"}}>+91</span>
                    <input value={phone} onChange={e=>setPhone(e.target.value.replace(/\D/g,"").slice(0,10))}
                      placeholder="Principal's phone number"
                      style={{width:"100%",background:"#fff",border:"1px solid rgba(0,0,0,.15)",borderRadius:9,padding:".7rem 1rem .7rem 3.2rem",fontSize:".86rem",color:D.t1,outline:"none"}}
                      onFocus={e=>{e.target.style.borderColor="rgba(201,151,58,.5)";}}
                      onBlur={e=>{e.target.style.borderColor="rgba(0,0,0,.15)";}}/>
                  </div>
                  <div style={{padding:".75rem 1rem",background:"rgba(201,151,58,.06)",border:"1px solid rgba(201,151,58,.15)",borderRadius:9,fontSize:".8rem",color:D.t2,lineHeight:1.65}}>
                    📱 6-digit OTP sent via SMS. Valid for 10 minutes.
                  </div>
                  <Btn v="black" onClick={sendReset} disabled={loading} full style={{padding:".9rem",fontFamily:"'Playfair Display',serif",fontWeight:700}}>
                    {loading?<><Spin/>Sending OTP…</>:"Send OTP →"}
                  </Btn>
                </div>
              ):(
                <div style={{textAlign:"center",padding:"1.5rem 0"}}>
                  <div style={{fontSize:"2.5rem",marginBottom:".8rem"}}>📱</div>
                  <div style={{fontFamily:"'Playfair Display',serif",fontWeight:700,color:D.green,marginBottom:".4rem",fontSize:"1rem"}}>OTP Sent!</div>
                  <div style={{fontSize:".82rem",color:D.t2,marginBottom:"1.25rem"}}>Check +91{phone} for 6-digit OTP</div>
                  <Btn v="ghost" onClick={()=>{setSent(false);setPhone("");}}>Send Another</Btn>
                </div>
              )}
            </Card>
          )}

          {/* WELCOME SMS */}
          {tab==="welcome"&&(
            <Card>
              <div style={{fontSize:".63rem",letterSpacing:".14em",textTransform:"uppercase",color:D.green,marginBottom:"1rem",fontWeight:600}}>🎉 Welcome SMS</div>
              <div style={{fontSize:".84rem",color:D.t2,marginBottom:"1rem",lineHeight:1.6}}>
                Send welcome SMS to <strong style={{color:D.t1}}>{school.principal}</strong> at <strong style={{color:D.t1}}>+91{school.phone||"[add phone in Settings]"}</strong>
              </div>
              <div style={{padding:".9rem 1rem",background:"rgba(0,0,0,.04)",border:"1px solid rgba(0,0,0,.08)",borderRadius:9,fontSize:".78rem",color:D.t2,lineHeight:1.8,marginBottom:"1rem",fontStyle:"italic"}}>
                "నమస్కారం {school.principal} గారు! 🎉 {school.name} Edunex లో live అయింది! Login: edunex.in..."
              </div>
              <Btn v="green" onClick={sendWelcome} disabled={loading} full>
                {loading?<><Spin/>Sending…</>:"📱 Send Welcome SMS"}
              </Btn>
            </Card>
          )}

          {/* TEST SMS */}
          {tab==="test"&&(
            <Card>
              <div style={{fontSize:".63rem",letterSpacing:".14em",textTransform:"uppercase",color:D.cyan,marginBottom:"1rem",fontWeight:600}}>🧪 Test SMS</div>
              <div style={{display:"flex",flexDirection:"column",gap:".8rem"}}>
                <div style={{position:"relative"}}>
                  <span style={{position:"absolute",left:".9rem",top:"50%",transform:"translateY(-50%)",fontSize:".84rem",color:D.t3}}>+91</span>
                  <input value={testPhone} onChange={e=>setTP(e.target.value.replace(/\D/g,"").slice(0,10))}
                    placeholder="Your phone to test"
                    style={{width:"100%",background:"#fff",border:"1px solid rgba(0,0,0,.15)",borderRadius:9,padding:".7rem 1rem .7rem 3.2rem",fontSize:".86rem",color:D.t1,outline:"none"}}/>
                </div>
                <Inp label="Message" as="textarea" value={testMsg} onChange={setTMsg} rows={3}/>
                <div style={{fontSize:".72rem",color:D.t3}}>{testMsg.length} characters · {Math.ceil(testMsg.length/160)} SMS credit</div>
                <Btn v="black" onClick={sendTest} disabled={sending} full>
                  {sending?<><Spin/>Sending…</>:"📱 Send Test SMS"}
                </Btn>
              </div>
            </Card>
          )}

          {/* SMS info */}
          <Card>
            <div style={{fontSize:".63rem",letterSpacing:".14em",textTransform:"uppercase",color:D.t3,marginBottom:".85rem",fontWeight:600}}>Twilio SMS Info</div>
            <div style={{fontSize:".8rem",color:D.t2,lineHeight:1.9}}>
              <div>From: <strong style={{color:D.t1}}>{TWILIO_FROM}</strong></div>
              <div>Cost: <strong style={{color:D.t1}}>$0.0075/SMS = ₹0.63</strong></div>
              <div>Free trial: <strong style={{color:D.green}}>$15 credits = 2,000 SMS</strong></div>
              <div>Trial limit: <strong style={{color:D.gold}}>Verified numbers only</strong></div>
            </div>
            <div style={{marginTop:".8rem",padding:".7rem .9rem",background:"rgba(201,151,58,.06)",border:"1px solid rgba(201,151,58,.15)",borderRadius:8,fontSize:".76rem",color:D.t2,lineHeight:1.6}}>
              💡 Upgrade Twilio to Pro ($20) to SMS any number without verification
            </div>
          </Card>
        </div>

        {/* SMS Templates */}
        <div style={{display:"flex",flexDirection:"column",gap:"1rem"}}>
          <Card>
            <div style={{fontSize:".63rem",letterSpacing:".14em",textTransform:"uppercase",color:D.cyan,marginBottom:"1rem",fontWeight:600}}>📋 SMS Templates ({templates.length})</div>
            <div style={{display:"flex",flexDirection:"column",gap:".5rem",maxHeight:420,overflowY:"auto"}}>
              {templates.map(t=>(
                <div key={t.title}
                  onClick={()=>{setTMsg(t.msg);setTab("test");}}
                  style={{display:"flex",gap:".8rem",padding:".75rem .9rem",background:"rgba(255,255,255,.6)",border:"1px solid rgba(0,0,0,.08)",borderRadius:9,cursor:"pointer",transition:"all .2s"}}
                  onMouseEnter={e=>{e.currentTarget.style.borderColor="rgba(201,151,58,.4)";e.currentTarget.style.background="rgba(201,151,58,.05)";}}
                  onMouseLeave={e=>{e.currentTarget.style.borderColor="rgba(0,0,0,.08)";e.currentTarget.style.background="rgba(255,255,255,.6)";}}>
                  <span style={{fontSize:"1.2rem",flexShrink:0}}>{t.icon}</span>
                  <div style={{flex:1}}>
                    <div style={{fontSize:".82rem",fontWeight:600,color:D.t1,marginBottom:".2rem"}}>{t.title}</div>
                    <div style={{fontSize:".72rem",color:D.t3,lineHeight:1.5}}>{t.msg.slice(0,60)}…</div>
                  </div>
                  <span style={{color:D.t3,fontSize:".8rem",flexShrink:0,alignSelf:"center"}}>→</span>
                </div>
              ))}
            </div>
          </Card>

          {/* Auto SMS list */}
          <Card>
            <div style={{fontSize:".63rem",letterSpacing:".14em",textTransform:"uppercase",color:D.cyan,marginBottom:"1rem",fontWeight:600}}>Auto SMS Events</div>
            {[
              ["Student absent","SMS to parent immediately after call","✅ Active"],
              ["Fee overdue","Daily SMS at 11 AM to overdue parents","✅ Active"],
              ["Bus 2 stops away","WhatsApp + SMS to parent","✅ Active"],
              ["Password reset","OTP SMS on request","✅ Active"],
              ["School welcome","SMS when school registers","✅ Active"],
              ["Daily report","SMS to principal at 6 PM","✅ Active"],
            ].map(([t,d,s])=>(
              <div key={t} style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",padding:".6rem 0",borderBottom:"1px solid rgba(0,0,0,.06)"}}>
                <div>
                  <div style={{fontSize:".82rem",fontWeight:500,color:D.t1}}>{t}</div>
                  <div style={{fontSize:".7rem",color:D.t3,marginTop:".1rem"}}>{d}</div>
                </div>
                <Badge c="green">{s}</Badge>
              </div>
            ))}
          </Card>
        </div>
      </div>
    </div>
  );
};


// ══════════════════════════════════════════════════
// IVR — CALL RESPONSE TRACKER
// Parent presses 1=Coming 2=NotComing after AI call
// ══════════════════════════════════════════════════
const PgIVR = ({school}) => {
  const [calls]    = useD2(school.id,"calls");
  const [students] = useD2(school.id,"students");
  const [ivr,saveIVR] = useD2(school.id,"ivr_responses");
  const [toast,setT]  = useState(null);
  const [filter,setFilter] = useState("all");

  // Simulate IVR response for demo
  const simulateResponse = (callId, studentName, response) => {
    const now = new Date().toLocaleTimeString("en-IN",{hour:"2-digit",minute:"2-digit"});
    const updated = [{
      id:"ivr"+Date.now(),
      callId, studentName,
      response, // "coming" | "not_coming" | "no_answer"
      time:now,
      date:new Date().toLocaleDateString("en-IN"),
      notifiedStaff: response !== "no_answer",
    },...ivr];
    saveIVR(updated);
    setT({msg:response==="coming"?`✅ ${studentName}'s parent confirmed — Coming to school`:`❌ ${studentName}'s parent said — NOT coming today`});
  };

  const stats = {
    coming:    ivr.filter(r=>r.response==="coming").length,
    not_coming:ivr.filter(r=>r.response==="not_coming").length,
    no_answer: ivr.filter(r=>r.response==="no_answer").length,
  };

  const filtered = filter==="all" ? ivr : ivr.filter(r=>r.response===filter);
  const absentStudents = students.filter(s=>s.absent);

  return (
    <div className="pin">
      {toast&&<Toast msg={toast.msg} type={toast.type} onDone={()=>setT(null)}/>}
      <SH tag="IVR System" title="Call Response Tracker"
        sub="Parent presses 1 = Coming · Parent presses 2 = Not coming · Staff notified instantly"/>

      {/* How IVR works */}
      <div style={{padding:"1.2rem 1.6rem",background:"rgba(124,92,255,.05)",border:"1px solid rgba(201,151,58,.15)",borderRadius:14,marginBottom:"1.75rem"}}>
        <div style={{fontFamily:"'Playfair Display',serif",fontWeight:700,color:D.cyan,marginBottom:".8rem",fontSize:".95rem"}}>📞 How IVR Works</div>
        <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:"1rem",fontSize:".8rem",color:D.t2}}>
          {[["1️⃣","AI calls parent","When child is marked absent"],["2️⃣","Voice message plays","School name says child is absent"],["3️⃣","Parent presses key","1 = Coming · 2 = Not Coming"],["4️⃣","Staff notified instantly","SMS sent to class teacher"]].map(([n,t,d])=>(
            <div key={t} style={{textAlign:"center",padding:".8rem",background:"rgba(255,255,255,.5)",border:`1px solid ${D.b0}`,borderRadius:10}}>
              <div style={{fontSize:"1.2rem",marginBottom:".4rem"}}>{n}</div>
              <div style={{fontWeight:600,color:D.t1,marginBottom:".2rem",fontSize:".82rem"}}>{t}</div>
              <div style={{fontSize:".72rem",color:D.t3}}>{d}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Stats */}
      <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:"1rem",marginBottom:"1.5rem"}}>
        {[[`✅ ${stats.coming}`,"Confirmed Coming",D.green,"coming"],[`❌ ${stats.not_coming}`,"Not Coming Today",D.red,"not_coming"],[`📵 ${stats.no_answer}`,"No Answer",D.t3,"no_answer"]].map(([v,l,color,f])=>(
          <Card key={l} style={{cursor:"pointer",border:`1px solid ${filter===f?"rgba(201,151,58,.3)":D.b1}`,transition:"all .2s"}} onClick={()=>setFilter(filter===f?"all":f)}>
            <div style={{fontFamily:"'Playfair Display',serif",fontSize:"1.6rem",fontWeight:800,color,marginBottom:".2rem"}}>{v}</div>
            <div style={{fontSize:".78rem",color:D.t2}}>{l}</div>
          </Card>
        ))}
      </div>

      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"1.25rem"}}>

        {/* Absent students — simulate IVR */}
        <Card>
          <div style={{fontSize:".63rem",letterSpacing:".16em",textTransform:"uppercase",color:D.red,marginBottom:"1rem",fontWeight:600,display:"flex",alignItems:"center",gap:".4rem"}}>
            <span style={{width:4,height:4,borderRadius:"50%",background:D.red}}/>
            Absent Students — Pending IVR Response ({absentStudents.length})
          </div>
          {absentStudents.length===0
            ?<div style={{color:D.t3,fontSize:".84rem",padding:"1rem 0"}}>No absent students today. Mark attendance first.</div>
            :absentStudents.map(s=>{
              const responded = ivr.find(r=>r.studentName===s.name);
              return(
                <div key={s.id} style={{display:"flex",alignItems:"center",gap:".8rem",padding:".8rem 0",borderBottom:`1px solid ${D.b0}`}}>
                  <Av ini={s.name?.split(" ").map(x=>x[0]).join("")||"?"} size={30} color={responded?D.green:D.red}/>
                  <div style={{flex:1}}>
                    <div style={{fontSize:".83rem",fontWeight:500,color:D.t1}}>{s.name}</div>
                    <div style={{fontSize:".7rem",color:D.t3}}>{s.parent} · Class {s.cls}</div>
                    {responded&&<div style={{fontSize:".68rem",color:responded.response==="coming"?D.green:D.red,marginTop:".15rem",fontWeight:600}}>{responded.response==="coming"?"✅ Coming":"❌ Not Coming"}</div>}
                  </div>
                  {!responded?(
                    <div style={{display:"flex",gap:".4rem"}}>
                      <Btn v="green" sm onClick={()=>simulateResponse("c"+s.id,s.name,"coming")}>1 ✅</Btn>
                      <Btn v="danger" sm onClick={()=>simulateResponse("c"+s.id,s.name,"not_coming")}>2 ❌</Btn>
                    </div>
                  ):<Badge c={responded.response==="coming"?"green":"red"}>{responded.response==="coming"?"Coming":"Not Coming"}</Badge>}
                </div>
              );
            })}

          <div style={{marginTop:"1rem",padding:".8rem 1rem",background:"rgba(255,255,255,.5)",border:`1px solid ${D.b0}`,borderRadius:9,fontSize:".76rem",color:D.t3,lineHeight:1.6}}>
            💡 In production: parent calls your Exotel number back and presses 1 or 2. Response auto-logged here and staff notified via SMS.
          </div>
        </Card>

        {/* IVR Response Log */}
        <div style={{background:"rgba(255,255,255,.7)",border:`1px solid ${D.b0}`,borderRadius:14,overflow:"hidden"}}>
          <div style={{padding:".9rem 1.3rem",borderBottom:`1px solid ${D.b0}`,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
            <div style={{fontSize:".63rem",letterSpacing:".16em",textTransform:"uppercase",color:D.cyan,fontWeight:600}}>Response Log</div>
            <div style={{display:"flex",gap:".4rem"}}>
              {["all","coming","not_coming","no_answer"].map(f=>(
                <button key={f} onClick={()=>setFilter(f)}
                  style={{fontSize:".62rem",padding:".2rem .6rem",borderRadius:6,background:filter===f?"rgba(201,151,58,.15)":"transparent",border:`1px solid ${filter===f?"rgba(201,151,58,.3)":D.b0}`,color:filter===f?D.cyan:D.t3,cursor:"pointer"}}>
                  {f==="all"?"All":f==="coming"?"✅":f==="not_coming"?"❌":"📵"}
                </button>
              ))}
            </div>
          </div>
          {filtered.length===0
            ?<div style={{padding:"2.5rem",textAlign:"center",color:D.t3,fontSize:".84rem"}}>No responses yet. Make absence calls first.</div>
            :filtered.map(r=>(
              <div key={r.id} style={{padding:".85rem 1.3rem",borderBottom:`1px solid ${D.b0}`,display:"flex",alignItems:"center",gap:".8rem"}}>
                <div style={{fontSize:"1.2rem"}}>{r.response==="coming"?"✅":r.response==="not_coming"?"❌":"📵"}</div>
                <div style={{flex:1}}>
                  <div style={{fontSize:".83rem",fontWeight:500,color:D.t1}}>{r.studentName}</div>
                  <div style={{fontSize:".7rem",color:D.t3}}>{r.time} · {r.date}</div>
                  {r.notifiedStaff&&<div style={{fontSize:".66rem",color:D.green,marginTop:".15rem"}}>✓ Staff notified via SMS</div>}
                </div>
                <Badge c={r.response==="coming"?"green":r.response==="not_coming"?"red":"gray"}>
                  {r.response==="coming"?"Coming":r.response==="not_coming"?"Not Coming":"No Answer"}
                </Badge>
              </div>
            ))}
        </div>
      </div>

      {/* Exotel IVR Setup Guide */}
      <Card style={{marginTop:"1.25rem",border:"1px solid rgba(201,151,58,.15)"}}>
        <div style={{fontSize:".63rem",letterSpacing:".16em",textTransform:"uppercase",color:D.cyan,marginBottom:"1rem",fontWeight:600}}>⚡ Set Up Real IVR in Exotel</div>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"1.5rem",fontSize:".82rem",color:D.t2,lineHeight:1.8}}>
          <div>
            {["1. Login to my.exotel.com","2. Go to App Bazaar → IVR","3. Create new IVR flow","4. Add: Play message → Gather input","5. Press 1 → trigger webhook → log 'Coming'","6. Press 2 → trigger webhook → log 'Not Coming'","7. Webhook sends SMS to class teacher"].map(s=><div key={s}>{s}</div>)}
          </div>
          <div style={{padding:"1rem",background:"rgba(0,0,0,.06)",borderRadius:9,fontFamily:"monospace",fontSize:".72rem",color:D.green,lineHeight:1.8}}>
            {`// Webhook endpoint (add to Vercel)
// /api/ivr-response

if (digits === "1") {
  status = "coming"
  sendSMS(teacher, 
    student+" coming today")
}
if (digits === "2") {
  status = "not_coming"
  sendSMS(teacher,
    student+" NOT coming today")
}`}
          </div>
        </div>
      </Card>
    </div>
  );
};

// ══════════════════════════════════════════════════
// AI RECEPTIONIST — Handles Incoming Parent Calls
// ══════════════════════════════════════════════════
const PgReceptionist = ({school}) => {
  const [calls,saveCalls] = useD2(school.id,"inbound_calls");
  const [students]        = useD2(school.id,"students");
  const [teachers]        = useD2(school.id,"teachers");
  const [toast,setT]      = useState(null);
  const [active,setActive]= useState(S.g("receptionist_on_"+school.id,false));
  const [testPhone,setTP] = useState("");
  const [calling,setC]    = useState(false);

  const toggle = () => {
    const next=!active;
    setActive(next);
    S.s("receptionist_on_"+school.id,next);
    setT({msg:next?"🤝 AI Receptionist is LIVE — answering all incoming calls":"Receptionist paused"});
  };

  // Simulate incoming call from parent
  const simulateCall = (type) => {
    const now = new Date().toLocaleTimeString("en-IN",{hour:"2-digit",minute:"2-digit"});
    const responses = {
      send_home:{
        caller:"+91 98765 43210",
        type:"Send Child Home",
        aiResponse:`Thank you for calling ${school.name}. I understand you want to send your child home early. I am notifying the class teacher right now. Please wait at the school gate. Have a good day.`,
        staffNotified:teachers.filter(t=>t.status==="active")[0]?.name||"Class Teacher",
        action:"SMS sent to teacher: 'Parent called to pick up child early. Please send to gate.'",
        color:D.gold,icon:"🏠",
      },
      enquiry:{
        caller:"+91 87654 32109",
        type:"Admission Enquiry",
        aiResponse:`Thank you for calling ${school.name}. We are glad you are interested in admissions for the academic year ${new Date().getFullYear()+1}-${new Date().getFullYear()+2}. Our admissions team will call you back within 30 minutes. Your number has been noted. Thank you!`,
        staffNotified:school.principal,
        action:`SMS sent to principal: 'New admission enquiry from +91 87654 32109 at ${now}. Please call back.'`,
        color:D.cyan,icon:"📋",
      },
      emergency:{
        caller:"+91 76543 21098",
        type:"Emergency — Child Sick",
        aiResponse:`I understand this is urgent. I am immediately notifying the school nurse and your child's class teacher. Please come to the school office. We will have your child ready. Help is on the way.`,
        staffNotified:"School Nurse + Class Teacher",
        action:"URGENT SMS to nurse and teacher: 'Parent called — child may be sick/emergency. Go to class immediately.'",
        color:D.red,icon:"🚨",
      },
      fee:{
        caller:"+91 65432 10987",
        type:"Fee Payment Query",
        aiResponse:`Thank you for calling ${school.name}. For fee payment queries, you can pay online through our parent portal, or visit the school office between 9 AM and 4 PM. Your child's fee details are available in the parent app. Thank you!`,
        staffNotified:"Accounts Office",
        action:"SMS to accounts: 'Parent called about fee payment. Please follow up.'",
        color:D.green,icon:"💳",
      },
    };
    const r = responses[type];
    const newCall = {id:"ic"+Date.now(),...r,time:now,date:new Date().toLocaleDateString("en-IN"),status:"handled"};
    saveCalls([newCall,...calls]);
    setT({msg:`📞 ${r.type} handled — ${r.staffNotified} notified!`});
  };

  const callTypes = [
    {id:"send_home",icon:"🏠",label:"Parent wants child home early",color:D.gold},
    {id:"enquiry",icon:"📋",label:"Admission enquiry call",color:D.cyan},
    {id:"emergency",icon:"🚨",label:"Emergency — child sick",color:D.red},
    {id:"fee",icon:"💳",label:"Fee payment query",color:D.green},
  ];

  return (
    <div className="pin">
      {toast&&<Toast msg={toast.msg} type={toast.type} onDone={()=>setT(null)}/>}
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",flexWrap:"wrap",gap:"1rem",marginBottom:"1.75rem"}}>
        <SH tag="AI Receptionist" title="Incoming Call Handler"
          sub="AI answers all incoming calls to your school number — 24/7, no staff needed"/>
        <div style={{display:"flex",alignItems:"center",gap:"1rem"}}>
          <div style={{fontSize:".8rem",color:active?D.green:D.t3,fontWeight:600,display:"flex",alignItems:"center",gap:".4rem"}}>
            <span style={{width:8,height:8,borderRadius:"50%",background:active?D.green:D.t3,animation:active?"pulse 2s infinite":"none"}}/>
            {active?"AI Receptionist LIVE":"Offline"}
          </div>
          <button onClick={toggle}
            style={{width:52,height:28,borderRadius:14,background:active?D.green:"rgba(0,0,0,.1)",border:"none",cursor:"pointer",position:"relative",transition:"background .3s",boxShadow:active?`0 0 16px rgba(16,217,160,.4)`:"none"}}>
            <div style={{width:22,height:22,borderRadius:"50%",background:"#fff",position:"absolute",top:3,left:active?27:3,transition:"left .3s",boxShadow:"0 2px 6px rgba(0,0,0,.06)"}}/>
          </button>
        </div>
      </div>

      {/* Active banner */}
      {active?(
        <div style={{padding:"1.2rem 1.6rem",background:"rgba(16,217,160,.06)",border:"1px solid rgba(16,217,160,.2)",borderRadius:14,marginBottom:"1.75rem",display:"flex",alignItems:"center",gap:"1rem"}}>
          <div style={{width:42,height:42,borderRadius:"50%",background:"rgba(16,217,160,.12)",border:`2px solid ${D.green}`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:"1.2rem",flexShrink:0,animation:"pulse 2s infinite"}}>🤝</div>
          <div>
            <div style={{fontFamily:"'Playfair Display',serif",fontWeight:700,color:D.green,marginBottom:".2rem"}}>AI Receptionist is answering all calls to {school.twilioNumber||"your Exotel number"}</div>
            <div style={{fontSize:".82rem",color:D.t2}}>Send child home · Admission enquiry · Emergency · Fee queries — all handled automatically</div>
          </div>
        </div>
      ):(
        <div style={{padding:"1rem 1.4rem",background:"rgba(255,255,255,.5)",border:`1px solid ${D.b1}`,borderRadius:14,marginBottom:"1.75rem"}}>
          <div style={{fontSize:".84rem",color:D.t2}}>⏸️ AI Receptionist is off. Toggle ON to start handling incoming calls automatically.</div>
        </div>
      )}

      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"1.25rem"}}>

        {/* Call Types + Simulate */}
        <div style={{display:"flex",flexDirection:"column",gap:"1rem"}}>
          <Card>
            <div style={{fontSize:".63rem",letterSpacing:".16em",textTransform:"uppercase",color:D.cyan,marginBottom:"1rem",fontWeight:600}}>Simulate Incoming Call (Demo)</div>
            <div style={{display:"flex",flexDirection:"column",gap:".6rem"}}>
              {callTypes.map(ct=>(
                <div key={ct.id} onClick={()=>simulateCall(ct.id)}
                  style={{display:"flex",alignItems:"center",gap:".8rem",padding:".85rem 1rem",background:"rgba(255,255,255,.5)",border:`1px solid ${D.b0}`,borderRadius:10,cursor:"pointer",transition:"all .2s"}}
                  onMouseEnter={e=>{e.currentTarget.style.borderColor=ct.color+"44";e.currentTarget.style.background=`${ct.color}06`;}}
                  onMouseLeave={e=>{e.currentTarget.style.borderColor=D.b0;e.currentTarget.style.background="rgba(0,0,0,.04)";}}>
                  <div style={{width:36,height:36,borderRadius:"50%",background:`${ct.color}12`,border:`1px solid ${ct.color}25`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:"1rem",flexShrink:0}}>{ct.icon}</div>
                  <div style={{flex:1}}>
                    <div style={{fontSize:".83rem",fontWeight:500,color:D.t1}}>{ct.label}</div>
                    <div style={{fontSize:".7rem",color:D.t3,marginTop:".1rem"}}>Click to simulate — see how AI handles it</div>
                  </div>
                  <span style={{color:D.t3,fontSize:".8rem"}}>→</span>
                </div>
              ))}
            </div>
          </Card>

          <Card>
            <div style={{fontSize:".63rem",letterSpacing:".16em",textTransform:"uppercase",color:D.cyan,marginBottom:".9rem",fontWeight:600}}>AI Voice Script (Telugu)</div>
            <div style={{display:"flex",flexDirection:"column",gap:".6rem"}}>
              {[
                ["📞 Opening","నమస్కారం. మీరు కాల్ చేసినందుకు ధన్యవాదాలు. ఇది "+school.name+". మీకు సహాయం చేయడానికి మేము సంతోషంగా ఉన్నాం."],
                ["1️⃣ Press 1","పిల్లలను ఇంటికి పంపడానికి 1 నొక్కండి"],
                ["2️⃣ Press 2","అడ్మిషన్ విచారణకు 2 నొక్కండి"],
                ["3️⃣ Press 3","అత్యవసర పరిస్థితికి 3 నొక్కండి"],
                ["4️⃣ Press 4","ఫీజు విచారణకు 4 నొక్కండి"],
              ].map(([label,text])=>(
                <div key={label} style={{padding:".6rem .8rem",background:"rgba(255,255,255,.5)",border:`1px solid ${D.b0}`,borderRadius:8}}>
                  <div style={{fontSize:".65rem",color:D.cyan,fontWeight:600,marginBottom:".2rem"}}>{label}</div>
                  <div style={{fontSize:".76rem",color:D.t2,lineHeight:1.5,fontStyle:"italic"}}>{text}</div>
                </div>
              ))}
            </div>
          </Card>
        </div>

        {/* Call Log */}
        <div style={{background:"rgba(255,255,255,.7)",border:`1px solid ${D.b0}`,borderRadius:14,overflow:"hidden"}}>
          <div style={{padding:".9rem 1.3rem",borderBottom:`1px solid ${D.b0}`,fontSize:".63rem",letterSpacing:".16em",textTransform:"uppercase",color:D.cyan,fontWeight:600,display:"flex",alignItems:"center",gap:".4rem"}}>
            <span style={{width:4,height:4,borderRadius:"50%",background:D.cyan}}/>
            Incoming Call Log ({calls.length})
          </div>
          {calls.length===0
            ?<div style={{padding:"2.5rem",textAlign:"center",color:D.t3,fontSize:".84rem"}}>No incoming calls yet.<br/>Simulate one using the buttons on the left.</div>
            :calls.map(c=>(
              <div key={c.id} style={{padding:".9rem 1.3rem",borderBottom:`1px solid ${D.b0}`}}>
                <div style={{display:"flex",justifyContent:"space-between",marginBottom:".4rem"}}>
                  <div style={{display:"flex",alignItems:"center",gap:".6rem"}}>
                    <span style={{fontSize:"1rem"}}>{c.icon}</span>
                    <div>
                      <div style={{fontSize:".83rem",fontWeight:600,color:c.color||D.cyan}}>{c.type}</div>
                      <div style={{fontSize:".7rem",color:D.t3}}>{c.caller} · {c.time}</div>
                    </div>
                  </div>
                  <Badge c="green" dot>handled</Badge>
                </div>
                <div style={{fontSize:".76rem",color:D.t2,fontStyle:"italic",padding:".5rem .7rem",background:"rgba(255,255,255,.5)",borderRadius:7,borderLeft:`2px solid ${c.color||D.cyan}`,lineHeight:1.55,marginBottom:".4rem"}}>
                  🤖 "{c.aiResponse?.slice(0,100)}…"
                </div>
                <div style={{fontSize:".72rem",color:D.green}}>✓ {c.action}</div>
              </div>
            ))}
        </div>
      </div>
    </div>
  );
};

// ══════════════════════════════════════════════════
// ENQUIRY MANAGER — Tracks all admission enquiries
// ══════════════════════════════════════════════════
const PgEnquiry = ({school}) => {
  const [enquiries,save] = useD2(school.id,"enquiries");
  const [toast,setT]     = useState(null);
  const [dlg,setDlg]     = useState(false);
  const [calling,setC]   = useState(null);
  const [f,setF]         = useState({name:"",phone:"",cls:"",source:"Phone Call",status:"new",notes:""});

  const add = () => {
    if(!f.name||!f.phone){setT({msg:"Name and phone required",type:"err"});return;}
    save([{...f,id:"enq"+Date.now(),date:new Date().toLocaleDateString("en-IN"),time:new Date().toLocaleTimeString("en-IN",{hour:"2-digit",minute:"2-digit"})},...enquiries]);
    setDlg(false);setT({msg:"Enquiry added!"});
    setF({name:"",phone:"",cls:"",source:"Phone Call",status:"new",notes:""});
  };

  // AI follow-up call to enquiry
  const callBack = async enq => {
    setC(enq.id);
    await new Promise(r=>setTimeout(r,2000));
    const exoNum = school.twilioNumber||"0951386363";
    try {
      await fetch(`https://api.twilio.com/2010-04-01/Accounts/AC0f10643lebaes1d0a234abcdef12345/Calls.json`,{
        method:"POST",
        headers:{"Content-Type":"application/x-www-form-urlencoded"},
        body:new URLSearchParams({
          From:exoNum,
          To:"0"+enq.phone.replace(/\D/g,"").replace(/^0+/,""),
          CallerId:exoNum,
          TimeLimit:60,TimeOut:30,
        }).toString(),
      });
    } catch(e){}
    save(enquiries.map(e=>e.id===enq.id?{...e,status:"called",lastCall:new Date().toLocaleString("en-IN")}:e));
    setC(null);
    setT({msg:`📞 Called ${enq.name} from ${exoNum}`});
  };

  const statusColors = {new:D.cyan,called:D.gold,interested:D.green,admitted:D.purp,dropped:D.red};
  const stats = Object.entries(statusColors).map(([s,c])=>({s,c,count:enquiries.filter(e=>e.status===s).length}));

  return (
    <div className="pin">
      {toast&&<Toast msg={toast.msg} type={toast.type} onDone={()=>setT(null)}/>}
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",flexWrap:"wrap",gap:"1rem",marginBottom:"1.75rem"}}>
        <SH tag="CRM" title="Admission Enquiries"
          sub="Track all enquiries · AI calls back automatically · Convert leads to admissions"/>
        <Btn v="gold" onClick={()=>setDlg(true)}>+ Add Enquiry</Btn>
      </div>

      {/* Stats */}
      <div style={{display:"flex",gap:".8rem",flexWrap:"wrap",marginBottom:"1.5rem"}}>
        {stats.map(({s,c,count})=>(
          <div key={s} style={{padding:".6rem 1.1rem",background:`${c}10`,border:`1px solid ${c}25`,borderRadius:10,textAlign:"center",minWidth:90}}>
            <div style={{fontFamily:"'Playfair Display',serif",fontSize:"1.3rem",fontWeight:800,color:c}}>{count}</div>
            <div style={{fontSize:".68rem",color:D.t2,textTransform:"capitalize",marginTop:".1rem"}}>{s}</div>
          </div>
        ))}
        <div style={{padding:".6rem 1.1rem",background:"rgba(0,0,0,.06)",border:`1px solid ${D.b0}`,borderRadius:10,textAlign:"center",minWidth:90}}>
          <div style={{fontFamily:"'Playfair Display',serif",fontSize:"1.3rem",fontWeight:800,color:D.t1}}>{enquiries.length}</div>
          <div style={{fontSize:".68rem",color:D.t2,marginTop:".1rem"}}>Total</div>
        </div>
      </div>

      {/* Enquiry table */}
      <div style={{background:"rgba(255,255,255,.7)",border:`1px solid ${D.b0}`,borderRadius:14,overflow:"hidden"}}>
        <table style={{width:"100%",borderCollapse:"collapse"}}>
          <thead><tr style={{background:"rgba(0,0,0,.03)"}}>
            {["Parent Name","Phone","Class Wanted","Source","Status","Date","Action"].map(h=>(
              <th key={h} style={{padding:".8rem 1rem",textAlign:"left",fontSize:".6rem",letterSpacing:".1em",textTransform:"uppercase",color:D.t3,fontWeight:600,borderBottom:`1px solid ${D.b0}`}}>{h}</th>
            ))}
          </tr></thead>
          <tbody>
            {enquiries.length===0&&(
              <tr><td colSpan={7} style={{padding:"3rem",textAlign:"center",color:D.t3}}>
                No enquiries yet. They auto-appear when AI Receptionist handles a call, or add manually.
              </td></tr>
            )}
            {enquiries.map(enq=>(
              <tr key={enq.id} style={{borderBottom:`1px solid ${D.b0}`,transition:"background .15s"}}
                onMouseEnter={e=>e.currentTarget.style.background="rgba(0,0,0,.03)"}
                onMouseLeave={e=>e.currentTarget.style.background="transparent"}>
                <td style={{padding:".8rem 1rem"}}>
                  <div style={{fontSize:".84rem",fontWeight:500,color:D.t1}}>{enq.name}</div>
                  {enq.notes&&<div style={{fontSize:".7rem",color:D.t3,marginTop:".1rem"}}>{enq.notes.slice(0,30)}{enq.notes.length>30?"…":""}</div>}
                </td>
                <td style={{padding:".8rem 1rem",fontSize:".8rem",color:D.t2,fontFamily:"monospace"}}>{enq.phone}</td>
                <td style={{padding:".8rem 1rem",fontSize:".8rem",color:D.t2}}>{enq.cls||"—"}</td>
                <td style={{padding:".8rem 1rem"}}><Badge c="gray">{enq.source}</Badge></td>
                <td style={{padding:".8rem 1rem"}}>
                  <select value={enq.status}
                    onChange={e=>save(enquiries.map(x=>x.id===enq.id?{...x,status:e.target.value}:x))}
                    style={{background:"#F2EDE4",border:`1px solid ${statusColors[enq.status]||D.b0}30`,borderRadius:7,padding:".3rem .6rem",fontSize:".76rem",color:statusColors[enq.status]||D.t1,outline:"none",cursor:"pointer"}}>
                    {["new","called","interested","admitted","dropped"].map(s=><option key={s} value={s}>{s}</option>)}
                  </select>
                </td>
                <td style={{padding:".8rem 1rem",fontSize:".76rem",color:D.t3}}>{enq.date}</td>
                <td style={{padding:".8rem 1rem"}}>
                  <Btn v="primary" sm onClick={()=>callBack(enq)} disabled={calling===enq.id}>
                    {calling===enq.id?<><Spin/>Calling…</>:"📞 Call Back"}
                  </Btn>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Add Enquiry Modal */}
      <Modal open={dlg} onClose={()=>setDlg(false)} title="Add Admission Enquiry">
        <div style={{display:"flex",flexDirection:"column",gap:".9rem"}}>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:".8rem"}}>
            <Inp label="Parent Name" value={f.name} onChange={v=>setF({...f,name:v})} placeholder="Father / Mother name"/>
            <Inp label="Phone Number" value={f.phone} onChange={v=>setF({...f,phone:v})} placeholder="10-digit number" type="tel"/>
          </div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:".8rem"}}>
            <Inp label="Class Wanted" as="select" value={f.cls} onChange={v=>setF({...f,cls:v})} opts={["Nursery","LKG","UKG","1","2","3","4","5","6","7","8","9","10"].map(v=>({v,l:`Class ${v}`}))}/>
            <Inp label="Source" as="select" value={f.source} onChange={v=>setF({...f,source:v})} opts={["Phone Call","Walk-in","WhatsApp","Website","AI Receptionist","Referral"].map(v=>({v,l:v}))}/>
          </div>
          <Inp label="Notes (optional)" as="textarea" value={f.notes} onChange={v=>setF({...f,notes:v})} placeholder="What did the parent ask about?" rows={3}/>
          <div style={{display:"flex",gap:".7rem",justifyContent:"flex-end"}}>
            <Btn v="ghost" onClick={()=>setDlg(false)}>Cancel</Btn>
            <Btn v="gold" onClick={add}>Add Enquiry</Btn>
          </div>
        </div>
      </Modal>
    </div>
  );
};


// ══════════════════════════════════════════════════
// ONLINE ADMISSION FORM
// ══════════════════════════════════════════════════
const PgAdmission = ({school}) => {
  const [enquiries,saveEnq] = useD2(school.id,"enquiries");
  const [submissions,saveSub] = useD2(school.id,"admissions");
  const [toast,setT] = useState(null);
  const [tab,setTab] = useState("form"); // form | link | submissions
  const [copied,setCopied] = useState(false);
  const [preview,setPreview] = useState(false);
  const [sending,setSend] = useState(false);

  // Form config — school customizes this
  const [config,setConfig] = useState(()=>S.g("admission_config_"+school.id,{
    title:`Admission Enquiry — ${school.name}`,
    year:`${new Date().getFullYear()+1}-${new Date().getFullYear()+2}`,
    classes:["Nursery","LKG","UKG","Class 1","Class 2","Class 3","Class 4","Class 5","Class 6","Class 7","Class 8","Class 9","Class 10"],
    welcomeMsg:`Thank you for your interest in ${school.name}. Please fill in the details below and our team will contact you within 24 hours.`,
    thankYouMsg:`Thank you! We have received your application. Our admissions team will call you within 24 hours.`,
    showFee:true,
    requireDOB:false,
    color:"#C9973A",
  }));

  // Sample public form data
  const [form,setForm] = useState({
    childName:"",parentName:"",phone:"",email:"",
    classApplied:"",dob:"",address:"",
    currentSchool:"",howHeard:"WhatsApp",notes:""
  });
  const sf = (k,v) => setForm(p=>({...p,[k]:v}));

  const publicLink = `https://edunex.in/apply/${school.id}`;

  const copyLink = () => {
    navigator.clipboard?.writeText(publicLink).catch(()=>{});
    setCopied(true);
    setTimeout(()=>setCopied(false),2000);
    setT({msg:"Admission link copied! Share on WhatsApp"});
  };

  const submitForm = () => {
    if(!form.childName||!form.phone||!form.classApplied){setT({msg:"Child name, phone & class required",type:"err"});return;}
    setSend(true);
    setTimeout(()=>{
      const entry = {
        ...form,
        id:"adm"+Date.now(),
        date:new Date().toLocaleDateString("en-IN"),
        time:new Date().toLocaleTimeString("en-IN",{hour:"2-digit",minute:"2-digit"}),
        status:"new",
        source:"Online Form",
        school:school.name,
      };
      // Save to admissions
      saveSub([entry,...submissions]);
      // Also add to enquiry manager
      saveEnq([{
        id:"enq_adm"+Date.now(),
        name:form.parentName,
        phone:form.phone,
        cls:form.classApplied,
        source:"Online Admission Form",
        status:"new",
        notes:`Child: ${form.childName}. ${form.notes}`,
        date:entry.date,
        time:entry.time,
      },...enquiries]);
      setSend(false);
      setPreview(false);
      setT({msg:`✅ Application received from ${form.parentName}! Added to Enquiry Manager.`});
      setForm({childName:"",parentName:"",phone:"",email:"",classApplied:"",dob:"",address:"",currentSchool:"",howHeard:"WhatsApp",notes:""});
    },1500);
  };

  const statusColors = {new:D.cyan,called:D.gold,interested:D.green,admitted:D.purp,dropped:D.red};

  return (
    <div className="pin">
      {toast&&<Toast msg={toast.msg} type={toast.type} onDone={()=>setT(null)}/>}
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",flexWrap:"wrap",gap:"1rem",marginBottom:"1.75rem"}}>
        <SH tag="Admissions" title="Online Admission Form"
          sub="Share your link — parents apply online → auto-added to Enquiry Manager"/>
        <div style={{display:"flex",gap:".6rem"}}>
          <Btn v="gold" sm onClick={copyLink}>{copied?"✓ Copied!":"🔗 Copy Link"}</Btn>
          <Btn v="ghost" sm onClick={()=>setPreview(true)}>👁 Preview Form</Btn>
        </div>
      </div>

      {/* Tab switcher */}
      <div style={{display:"flex",gap:".4rem",marginBottom:"1.5rem",background:"rgba(0,0,0,.04)",padding:".3rem",borderRadius:10,border:"1px solid rgba(0,0,0,.08)"}}>
        {[["form","⚙️ Configure"],["link","🔗 Share Link"],["submissions","📋 Applications"]].map(([t,l])=>(
          <button key={t} onClick={()=>setTab(t)}
            style={{flex:1,padding:".6rem",fontSize:".78rem",fontWeight:tab===t?700:400,
              background:tab===t?"#1A1A1A":"transparent",color:tab===t?"#fff":D.t2,
              border:"none",cursor:"pointer",borderRadius:7,transition:"all .2s"}}>
            {l}
          </button>
        ))}
      </div>

      {/* CONFIGURE TAB */}
      {tab==="form"&&(
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"1.25rem"}}>
          <Card>
            <div style={{fontSize:".63rem",letterSpacing:".14em",textTransform:"uppercase",color:D.cyan,marginBottom:"1rem",fontWeight:600}}>Form Settings</div>
            <div style={{display:"flex",flexDirection:"column",gap:".85rem"}}>
              <Inp label="Form Title" value={config.title} onChange={v=>{const nc={...config,title:v};setConfig(nc);S.s("admission_config_"+school.id,nc);}}/>
              <Inp label="Academic Year" value={config.year} onChange={v=>{const nc={...config,year:v};setConfig(nc);S.s("admission_config_"+school.id,nc);}} placeholder="2025-2026"/>
              <Inp label="Welcome Message" as="textarea" value={config.welcomeMsg} onChange={v=>{const nc={...config,welcomeMsg:v};setConfig(nc);S.s("admission_config_"+school.id,nc);}} rows={3}/>
              <Inp label="Thank You Message" as="textarea" value={config.thankYouMsg} onChange={v=>{const nc={...config,thankYouMsg:v};setConfig(nc);S.s("admission_config_"+school.id,nc);}} rows={2}/>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:".8rem"}}>
                <div>
                  <div style={{fontSize:".68rem",fontWeight:600,color:D.t2,letterSpacing:".06em",textTransform:"uppercase",marginBottom:".4rem"}}>Show Fee Info</div>
                  <button onClick={()=>{const nc={...config,showFee:!config.showFee};setConfig(nc);S.s("admission_config_"+school.id,nc);}}
                    style={{width:40,height:22,borderRadius:11,background:config.showFee?D.green:"rgba(0,0,0,.15)",border:"none",cursor:"pointer",position:"relative",transition:"background .25s"}}>
                    <div style={{width:16,height:16,borderRadius:"50%",background:"#fff",position:"absolute",top:3,left:config.showFee?21:3,transition:"left .25s"}}/>
                  </button>
                </div>
                <div>
                  <div style={{fontSize:".68rem",fontWeight:600,color:D.t2,letterSpacing:".06em",textTransform:"uppercase",marginBottom:".4rem"}}>Require DOB</div>
                  <button onClick={()=>{const nc={...config,requireDOB:!config.requireDOB};setConfig(nc);S.s("admission_config_"+school.id,nc);}}
                    style={{width:40,height:22,borderRadius:11,background:config.requireDOB?D.green:"rgba(0,0,0,.15)",border:"none",cursor:"pointer",position:"relative",transition:"background .25s"}}>
                    <div style={{width:16,height:16,borderRadius:"50%",background:"#fff",position:"absolute",top:3,left:config.requireDOB?21:3,transition:"left .25s"}}/>
                  </button>
                </div>
              </div>
            </div>
          </Card>

          <div style={{display:"flex",flexDirection:"column",gap:"1rem"}}>
            <Card>
              <div style={{fontSize:".63rem",letterSpacing:".14em",textTransform:"uppercase",color:D.cyan,marginBottom:"1rem",fontWeight:600}}>Stats</div>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:".8rem"}}>
                {[[submissions.length,"Total Applications",D.cyan],[submissions.filter(s=>s.status==="admitted").length,"Admitted",D.green],[submissions.filter(s=>s.status==="new").length,"New Today",D.gold],[submissions.filter(s=>s.status==="dropped").length,"Dropped",D.red]].map(([v,l,color])=>(
                  <div key={l} style={{padding:".75rem",background:"rgba(0,0,0,.04)",border:"1px solid rgba(0,0,0,.08)",borderRadius:9,textAlign:"center"}}>
                    <div style={{fontFamily:"'Playfair Display',serif",fontSize:"1.5rem",fontWeight:800,color}}>{v}</div>
                    <div style={{fontSize:".68rem",color:D.t2,marginTop:".15rem"}}>{l}</div>
                  </div>
                ))}
              </div>
            </Card>

            <Card>
              <div style={{fontSize:".63rem",letterSpacing:".14em",textTransform:"uppercase",color:D.cyan,marginBottom:".9rem",fontWeight:600}}>How to Share</div>
              {[["📱","WhatsApp","Send link to parents group"],["📸","Instagram Bio","Add to school Instagram"],["🌐","Website","Embed on school website"],["📧","Email","Send to enquiry emails"],["🖨️","Print QR","Print QR code on pamphlets"]].map(([i,t,d])=>(
                <div key={t} style={{display:"flex",gap:".7rem",padding:".5rem 0",borderBottom:"1px solid rgba(0,0,0,.06)",alignItems:"center"}}>
                  <span style={{fontSize:"1.1rem",flexShrink:0}}>{i}</span>
                  <div><div style={{fontSize:".82rem",fontWeight:500,color:D.t1}}>{t}</div><div style={{fontSize:".7rem",color:D.t2}}>{d}</div></div>
                </div>
              ))}
            </Card>
          </div>
        </div>
      )}

      {/* SHARE LINK TAB */}
      {tab==="link"&&(
        <div style={{display:"flex",flexDirection:"column",gap:"1rem",maxWidth:560}}>
          <Card style={{border:"1px solid rgba(201,151,58,.25)",background:"rgba(201,151,58,.04)"}}>
            <div style={{fontSize:".63rem",letterSpacing:".14em",textTransform:"uppercase",color:D.gold,marginBottom:"1rem",fontWeight:600}}>Your Public Admission Link</div>
            <div style={{display:"flex",gap:".7rem",marginBottom:"1rem"}}>
              <div style={{flex:1,background:"rgba(255,255,255,.7)",border:"1px solid rgba(0,0,0,.12)",borderRadius:9,padding:".75rem 1rem",fontSize:".84rem",color:D.t2,fontFamily:"monospace",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{publicLink}</div>
              <Btn v="gold" onClick={copyLink}>{copied?"✓ Copied!":"Copy"}</Btn>
            </div>
            <div style={{padding:".9rem 1rem",background:"rgba(37,211,102,.08)",border:"1px solid rgba(37,211,102,.2)",borderRadius:9,fontSize:".82rem",color:D.t2,lineHeight:1.7}}>
              📱 <strong style={{color:D.green}}>WhatsApp message to send parents:</strong><br/>
              <div style={{marginTop:".4rem",fontStyle:"italic",color:D.t1}}>
                "Admissions open for {config.year}! Apply online: {publicLink}"
              </div>
            </div>
          </Card>

          <Card>
            <div style={{fontSize:".63rem",letterSpacing:".14em",textTransform:"uppercase",color:D.cyan,marginBottom:"1rem",fontWeight:600}}>What parents see when they open the link</div>
            <div style={{display:"flex",gap:".6rem",flexWrap:"wrap"}}>
              {["Child's name","Parent name","Phone number","Class applying for","Email (optional)","Date of birth (optional)","Current school","How did you hear"].map(f=>(
                <div key={f} style={{fontSize:".74rem",color:D.t2,background:"rgba(0,0,0,.05)",border:"1px solid rgba(0,0,0,.08)",borderRadius:20,padding:".25rem .8rem"}}>✓ {f}</div>
              ))}
            </div>
            <div style={{marginTop:"1rem",fontSize:".8rem",color:D.t2,lineHeight:1.7}}>
              After submitting → parent sees thank you message → <strong style={{color:D.cyan}}>auto-added to Enquiry Manager</strong> → you call them back!
            </div>
          </Card>
        </div>
      )}

      {/* SUBMISSIONS TAB */}
      {tab==="submissions"&&(
        <div>
          <div style={{background:"rgba(255,255,255,.7)",border:"1px solid rgba(0,0,0,.08)",borderRadius:14,overflow:"hidden"}}>
            <table style={{width:"100%",borderCollapse:"collapse"}}>
              <thead><tr style={{background:"rgba(0,0,0,.04)"}}>
                {["Child","Parent","Phone","Class","Source","Date","Status"].map(h=>(
                  <th key={h} style={{padding:".75rem 1rem",textAlign:"left",fontSize:".62rem",letterSpacing:".1em",textTransform:"uppercase",color:D.t3,fontWeight:600,borderBottom:"1px solid rgba(0,0,0,.07)"}}>{h}</th>
                ))}
              </tr></thead>
              <tbody>
                {submissions.length===0&&(
                  <tr><td colSpan={7} style={{padding:"3rem",textAlign:"center",color:D.t3}}>
                    No applications yet. Share your admission link to start receiving applications!
                  </td></tr>
                )}
                {submissions.map(s=>(
                  <tr key={s.id} style={{borderBottom:"1px solid rgba(0,0,0,.05)",transition:"background .15s"}}
                    onMouseEnter={e=>e.currentTarget.style.background="rgba(201,151,58,.04)"}
                    onMouseLeave={e=>e.currentTarget.style.background="transparent"}>
                    <td style={{padding:".75rem 1rem",fontSize:".84rem",fontWeight:500,color:D.t1}}>{s.childName}</td>
                    <td style={{padding:".75rem 1rem",fontSize:".8rem",color:D.t2}}>{s.parentName}</td>
                    <td style={{padding:".75rem 1rem",fontSize:".8rem",color:D.t2,fontFamily:"monospace"}}>{s.phone}</td>
                    <td style={{padding:".75rem 1rem",fontSize:".8rem",color:D.t2}}>{s.classApplied}</td>
                    <td style={{padding:".75rem 1rem"}}><Badge c="cyan">{s.source}</Badge></td>
                    <td style={{padding:".75rem 1rem",fontSize:".76rem",color:D.t3}}>{s.date}</td>
                    <td style={{padding:".75rem 1rem"}}>
                      <select value={s.status}
                        onChange={e=>saveSub(submissions.map(x=>x.id===s.id?{...x,status:e.target.value}:x))}
                        style={{background:"#F2EDE4",border:`1px solid ${statusColors[s.status]||D.b0}30`,borderRadius:7,padding:".3rem .6rem",fontSize:".76rem",color:statusColors[s.status]||D.t1,outline:"none",cursor:"pointer"}}>
                        {["new","called","interested","admitted","dropped"].map(st=><option key={st} value={st}>{st}</option>)}
                      </select>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Preview Modal — what parents see */}
      <Modal open={preview} onClose={()=>setPreview(false)} title="📝 Parent View — Admission Form" wide>
        <div style={{display:"flex",flexDirection:"column",gap:".9rem"}}>
          <div style={{padding:"1.2rem",background:"rgba(201,151,58,.06)",border:"1px solid rgba(201,151,58,.2)",borderRadius:10}}>
            <div style={{fontFamily:"'Playfair Display',serif",fontSize:"1.1rem",fontWeight:800,color:D.t0,marginBottom:".3rem"}}>{config.title}</div>
            <div style={{fontSize:".82rem",color:D.t2,lineHeight:1.7}}>{config.welcomeMsg}</div>
          </div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:".8rem"}}>
            <Inp label="Child's Full Name *" value={form.childName} onChange={v=>sf("childName",v)} placeholder="Student's name"/>
            <Inp label="Class Applying For *" as="select" value={form.classApplied} onChange={v=>sf("classApplied",v)} opts={[{v:"",l:"Select class"},...config.classes.map(c=>({v:c,l:c}))]}/>
            <Inp label="Parent/Guardian Name *" value={form.parentName} onChange={v=>sf("parentName",v)} placeholder="Father / Mother name"/>
            <Inp label="Mobile Number *" value={form.phone} onChange={v=>sf("phone",v)} placeholder="10-digit number" type="tel"/>
            <Inp label="Email (Optional)" value={form.email} onChange={v=>sf("email",v)} placeholder="parent@gmail.com" type="email"/>
            {config.requireDOB&&<Inp label="Date of Birth" value={form.dob} onChange={v=>sf("dob",v)} type="date"/>}
          </div>
          <Inp label="Current School" value={form.currentSchool} onChange={v=>sf("currentSchool",v)} placeholder="Where is child studying now?"/>
          <Inp label="How did you hear about us?" as="select" value={form.howHeard} onChange={v=>sf("howHeard",v)} opts={["WhatsApp","Friend/Relative","Google","Instagram","Pamphlet","Drive By","Other"].map(v=>({v,l:v}))}/>
          <Inp label="Additional Notes" as="textarea" value={form.notes} onChange={v=>sf("notes",v)} placeholder="Any specific queries or requirements?" rows={2}/>
          <Btn v="gold" onClick={submitForm} disabled={sending} full style={{padding:".9rem",fontFamily:"'Playfair Display',serif",fontWeight:700,fontSize:".95rem"}}>
            {sending?<><Spin/>Submitting…</>:"Submit Application →"}
          </Btn>
          <div style={{textAlign:"center",fontSize:".76rem",color:D.t3}}>We will contact you within 24 hours · {school.name}</div>
        </div>
      </Modal>
    </div>
  );
};

// ══════════════════════════════════════════════════
// HOME MESSAGE — Broadcast to All Parents on WhatsApp + SMS
// ══════════════════════════════════════════════════
const PgHomeMsg = ({school}) => {
  const [students] = useD2(school.id,"students");
  const [alerts,saveAlerts] = useD2(school.id,"alerts");
  const [msg,setMsg]   = useState("");
  const [lang,setLang] = useState("Telugu+English");
  const [channel,setChannel] = useState("both"); // whatsapp | sms | both
  const [sending,setSend] = useState(false);
  const [sent,setSent]   = useState(false);
  const [toast,setT]     = useState(null);
  const [schedMode,setSched] = useState("now"); // now | schedule
  const [schedTime,setSchedTime] = useState("");
  const [history] = [alerts];

  const templates = [
    {
      icon:"🏖️",
      title:"Holiday Notice",
      te:`నమస్కారం! ${school.name} వారి తరపున మీకు తెలియజేయడమేమిటంటే, [Date] న [Holiday Name] సందర్భంగా పాఠశాలకు సెలవు ఉంటుంది. [Next Date] న పాఠశాల ప్రారంభమవుతుంది. ధన్యవాదాలు.`,
      en:`Dear Parent, ${school.name} will remain closed on [Date] for [Holiday]. School resumes on [Next Date]. Thank you.`,
    },
    {
      icon:"📅",
      title:"PTM Notice",
      te:`నమస్కారం! ${school.name} తరపున తల్లిదండ్రులు-ఉపాధ్యాయుల సమావేశానికి మిమ్మల్ని ఆహ్వానిస్తున్నాము. తేదీ: [Date], సమయం: ఉదయం 10:00 గంటలకు. మీ రాక తప్పనిసరి.`,
      en:`Dear Parent, ${school.name} invites you for the Parent-Teacher Meeting on [Date] at 10:00 AM. Your presence is important for your child's progress.`,
    },
    {
      icon:"📝",
      title:"Exam Schedule",
      te:`నమస్కారం! ${school.name} వారి పరీక్ష వేళాపట్టిక: [Start Date] నుండి [End Date] వరకు. మీ పిల్లలు బాగా చదివేలా చూడగలరు. ధన్యవాదాలు.`,
      en:`Dear Parent, Examinations at ${school.name} are scheduled from [Start Date] to [End Date]. Please ensure your child is well prepared.`,
    },
    {
      icon:"🎉",
      title:"Annual Day Invite",
      te:`నమస్కారం! ${school.name} వార్షికోత్సవానికి మీకు హార్దిక ఆహ్వానం. తేదీ: [Date], సమయం: సాయంత్రం 5:00 గంటలకు, స్థలం: [Venue]. మీరు తప్పక రండి!`,
      en:`Dear Parent, You are cordially invited to ${school.name} Annual Day on [Date] at 5:00 PM at [Venue]. We look forward to your presence!`,
    },
    {
      icon:"⚠️",
      title:"Emergency Notice",
      te:`నమస్కారం! అత్యవసర నోటీసు: ${school.name}. [Emergency message]. దయచేసి వెంటనే పాఠశాలను సంప్రదించండి.`,
      en:`URGENT — ${school.name}: [Emergency message]. Please contact the school immediately at ${school.phone||"school office"}.`,
    },
    {
      icon:"💳",
      title:"Fee Reminder",
      te:`నమస్కారం! ${school.name} నుండి ఫీజు రిమైండర్. మీ పిల్లల [Term] ఫీజు చెల్లించవలసి ఉంది. దయచేసి [Date] లోపు చెల్లించండి. ధన్యవాదాలు.`,
      en:`Dear Parent, This is a reminder from ${school.name} regarding the [Term] fee payment due by [Date]. Please pay at the earliest. Thank you.`,
    },
    {
      icon:"🏆",
      title:"Achievement Announcement",
      te:`నమస్కారం! ${school.name} విద్యార్థులు గర్వపడే వార్త: మన పాఠశాల [Achievement]. ఈ విజయంలో మీ సహకారానికి ధన్యవాదాలు!`,
      en:`Dear Parent, We are proud to announce that ${school.name} has achieved [Achievement]. Thank you for your continued support!`,
    },
    {
      icon:"🔔",
      title:"General Reminder",
      te:`నమస్కారం! ${school.name} నుండి ముఖ్యమైన సమాచారం: [Message]. మరిన్ని వివరాలకు పాఠశాలను సంప్రదించండి. ధన్యవాదాలు.`,
      en:`Dear Parent, Important update from ${school.name}: [Message]. For more details, please contact the school. Thank you.`,
    },
  ];

  const getMixedMsg = () => {
    if(lang==="Telugu") return msg;
    if(lang==="English") return msg;
    // Auto-mix: start Telugu, end English
    return msg;
  };

  const sendNow = () => {
    if(!msg.trim()){setT({msg:"Please type or select a message",type:"err"});return;}
    setSend(true);
    setTimeout(()=>{
      const entry = {
        id:"hm"+Date.now(),
        msg,
        type:"Home Message",
        recipients:students.length,
        channel:channel==="both"?"WhatsApp + SMS":channel==="whatsapp"?"WhatsApp":"SMS",
        lang,
        status:"delivered",
        date:new Date().toLocaleString("en-IN"),
      };
      saveAlerts([entry,...alerts]);
      setSend(false);setSent(true);
      setT({msg:`✅ Sent to ${students.length} parents via ${entry.channel}!`});
      setTimeout(()=>setSent(false),4000);
    },2500);
  };

  const charCount = msg.length;
  const smsCount = Math.ceil(charCount/160);

  return (
    <div className="pin">
      {toast&&<Toast msg={toast.msg} type={toast.type} onDone={()=>setT(null)}/>}
      <SH tag="Mass Communication" title="Home Message to Parents"
        sub={`Send instant message to all ${students.length} parents · WhatsApp + SMS`}/>

      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"1.25rem"}}>

        {/* LEFT — Compose */}
        <div style={{display:"flex",flexDirection:"column",gap:"1rem"}}>
          <Card>
            <div style={{fontSize:".63rem",letterSpacing:".14em",textTransform:"uppercase",color:D.cyan,marginBottom:"1rem",fontWeight:600}}>Compose Message</div>

            {/* Channel selector */}
            <div style={{marginBottom:".9rem"}}>
              <div style={{fontSize:".68rem",fontWeight:600,color:D.t2,letterSpacing:".06em",textTransform:"uppercase",marginBottom:".5rem"}}>Send via</div>
              <div style={{display:"flex",gap:".5rem"}}>
                {[["both","WhatsApp + SMS","#25d366"],["whatsapp","WhatsApp only","#25d366"],["sms","SMS only",D.cyan]].map(([v,l,color])=>(
                  <button key={v} onClick={()=>setChannel(v)}
                    style={{flex:1,padding:".55rem .5rem",fontSize:".72rem",fontWeight:600,
                      background:channel===v?`${color}15`:"rgba(0,0,0,.04)",
                      border:`1px solid ${channel===v?color:"rgba(0,0,0,.1)"}`,
                      borderRadius:8,color:channel===v?color:D.t2,cursor:"pointer",transition:"all .2s"}}>
                    {l}
                  </button>
                ))}
              </div>
            </div>

            {/* Language */}
            <div style={{marginBottom:".9rem"}}>
              <div style={{fontSize:".68rem",fontWeight:600,color:D.t2,letterSpacing:".06em",textTransform:"uppercase",marginBottom:".5rem"}}>Language</div>
              <div style={{display:"flex",gap:".5rem"}}>
                {["Telugu","English","Telugu+English"].map(l=>(
                  <button key={l} onClick={()=>setLang(l)}
                    style={{flex:1,padding:".5rem .3rem",fontSize:".7rem",fontWeight:600,
                      background:lang===l?"rgba(201,151,58,.12)":"rgba(0,0,0,.04)",
                      border:`1px solid ${lang===l?"rgba(201,151,58,.4)":"rgba(0,0,0,.1)"}`,
                      borderRadius:8,color:lang===l?D.gold:D.t2,cursor:"pointer",transition:"all .2s"}}>
                    {l}
                  </button>
                ))}
              </div>
            </div>

            {/* Message box */}
            <Inp label="Message" as="textarea" value={msg} onChange={setMsg}
              placeholder={lang==="Telugu"?"నమస్కారం! తల్లిదండ్రులకు ముఖ్యమైన సమాచారం...":
                lang==="English"?"Dear Parent, Important update from school...":
                "నమస్కారం! Dear Parents..."}
              rows={5}/>

            {/* Char count */}
            <div style={{display:"flex",justifyContent:"space-between",marginTop:".4rem",fontSize:".72rem",color:D.t3}}>
              <span>{charCount} characters</span>
              <span>{smsCount} SMS credit{smsCount>1?"s":""} per parent</span>
            </div>

            {/* Schedule toggle */}
            <div style={{display:"flex",gap:".5rem",margin:".8rem 0"}}>
              {[["now","Send Now"],["schedule","Schedule"]].map(([v,l])=>(
                <button key={v} onClick={()=>setSched(v)}
                  style={{flex:1,padding:".55rem",fontSize:".78rem",fontWeight:schedMode===v?700:400,
                    background:schedMode===v?"#1A1A1A":"rgba(0,0,0,.04)",
                    color:schedMode===v?"#fff":D.t2,border:"1px solid rgba(0,0,0,.1)",
                    borderRadius:8,cursor:"pointer",transition:"all .2s"}}>
                  {l}
                </button>
              ))}
            </div>

            {schedMode==="schedule"&&(
              <div style={{marginBottom:".8rem"}}>
                <Inp label="Schedule Date & Time" value={schedTime} onChange={setSchedTime} type="datetime-local"/>
                <div style={{fontSize:".72rem",color:D.t3,marginTop:".3rem"}}>Message will auto-send at the scheduled time via Auto Agent</div>
              </div>
            )}

            {/* Recipients info */}
            <div style={{padding:".8rem 1rem",background:"rgba(201,151,58,.06)",border:"1px solid rgba(201,151,58,.15)",borderRadius:9,marginBottom:".8rem",fontSize:".8rem",color:D.t2,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
              <span>📱 Sending to <strong style={{color:D.gold}}>{students.length} parents</strong></span>
              <span style={{color:D.t3}}>~{Math.ceil(students.length*0.12)} Exotel credits</span>
            </div>

            {sent?(
              <div style={{padding:"1rem",background:"rgba(45,155,111,.08)",border:"1px solid rgba(45,155,111,.25)",borderRadius:10,textAlign:"center"}}>
                <div style={{fontFamily:"'Playfair Display',serif",fontWeight:700,color:D.green,fontSize:"1rem",marginBottom:".2rem"}}>✅ Message Delivered!</div>
                <div style={{fontSize:".8rem",color:D.t2}}>Sent to {students.length} parents successfully</div>
              </div>
            ):(
              <Btn v={schedMode==="schedule"?"gold":"black"} onClick={sendNow} disabled={sending} full
                style={{padding:".9rem",fontFamily:"'Playfair Display',serif",fontWeight:700,fontSize:".9rem"}}>
                {sending?<><Spin/>{schedMode==="schedule"?"Scheduling…":"Sending to "+students.length+" parents…"}</>:
                  schedMode==="schedule"?"🕐 Schedule Message":"📤 Send Now to All Parents"}
              </Btn>
            )}
          </Card>
        </div>

        {/* RIGHT — Templates + History */}
        <div style={{display:"flex",flexDirection:"column",gap:"1rem"}}>
          <Card>
            <div style={{fontSize:".63rem",letterSpacing:".14em",textTransform:"uppercase",color:D.cyan,marginBottom:"1rem",fontWeight:600}}>Quick Templates ({templates.length})</div>
            <div style={{display:"flex",flexDirection:"column",gap:".5rem",maxHeight:280,overflowY:"auto"}}>
              {templates.map(t=>(
                <div key={t.title}
                  onClick={()=>setMsg(lang==="Telugu"?t.te:lang==="English"?t.en:t.te+"

"+t.en)}
                  style={{display:"flex",gap:".8rem",padding:".7rem .9rem",background:"rgba(255,255,255,.6)",border:"1px solid rgba(0,0,0,.08)",borderRadius:9,cursor:"pointer",transition:"all .2s",alignItems:"center"}}
                  onMouseEnter={e=>{e.currentTarget.style.borderColor="rgba(201,151,58,.4)";e.currentTarget.style.background="rgba(201,151,58,.05)";}}
                  onMouseLeave={e=>{e.currentTarget.style.borderColor="rgba(0,0,0,.08)";e.currentTarget.style.background="rgba(255,255,255,.6)";}}>
                  <span style={{fontSize:"1.2rem",flexShrink:0}}>{t.icon}</span>
                  <div style={{flex:1}}>
                    <div style={{fontSize:".82rem",fontWeight:600,color:D.t1}}>{t.title}</div>
                    <div style={{fontSize:".7rem",color:D.t3,marginTop:".1rem"}}>{lang==="Telugu"?t.te.slice(0,50):t.en.slice(0,50)}…</div>
                  </div>
                  <span style={{color:D.t3,fontSize:".8rem",flexShrink:0}}>→</span>
                </div>
              ))}
            </div>
          </Card>

          {/* History */}
          <div style={{background:"rgba(255,255,255,.7)",border:"1px solid rgba(0,0,0,.08)",borderRadius:14,overflow:"hidden"}}>
            <div style={{padding:".9rem 1.3rem",borderBottom:"1px solid rgba(0,0,0,.07)",fontSize:".63rem",letterSpacing:".14em",textTransform:"uppercase",color:D.cyan,fontWeight:600}}>
              Message History
            </div>
            {alerts.length===0
              ?<div style={{padding:"2rem",textAlign:"center",color:D.t3,fontSize:".84rem"}}>No messages sent yet</div>
              :alerts.slice(0,6).map(a=>(
                <div key={a.id} style={{padding:".8rem 1.3rem",borderBottom:"1px solid rgba(0,0,0,.05)",transition:"background .15s"}}
                  onMouseEnter={e=>e.currentTarget.style.background="rgba(201,151,58,.04)"}
                  onMouseLeave={e=>e.currentTarget.style.background="transparent"}>
                  <div style={{display:"flex",justifyContent:"space-between",marginBottom:".3rem"}}>
                    <div style={{display:"flex",gap:".4rem"}}>
                      <Badge c="cyan">{a.type}</Badge>
                      {a.channel&&<span style={{fontSize:".6rem",color:D.green,background:"rgba(45,155,111,.1)",border:"1px solid rgba(45,155,111,.2)",padding:".15rem .5rem",borderRadius:10,fontWeight:600}}>{a.channel}</span>}
                    </div>
                    <Badge c="green" dot>delivered</Badge>
                  </div>
                  <div style={{fontSize:".8rem",color:D.t1,lineHeight:1.5,marginTop:".3rem"}}>{a.msg?.slice(0,80)}{a.msg?.length>80?"…":""}</div>
                  <div style={{fontSize:".68rem",color:D.t3,marginTop:".25rem"}}>{a.date} · {a.recipients} parents</div>
                </div>
              ))}
          </div>
        </div>
      </div>
    </div>
  );
};

// ══════════════════════════════════════════════════
// MAIN DASHBOARD
// ══════════════════════════════════════════════════
const Dashboard = ({school:init,onLogout}) => {
  const [school,setSchool] = useState(init);
  const [pg,setPg]         = useState("home");
  const [col,setCol]       = useState(false);
  const sw = col?56:220;

  const renderPg = () => {
    const p = {school,setPg,onLogout,onUpdate:setSchool};
    switch(pg){
      case"home":     return <PgHome {...p}/>;
      case"students": return <PgStudents school={school}/>;
      case"teachers": return <PgTeachers school={school}/>;
      case"attend":   return <PgAttend school={school}/>;
      case"fees":     return <PgFees school={school}/>;
      case"bus":      return <PgBus school={school}/>;
      case"exams":    return <PgExams school={school}/>;
      case"marks":    return <PgMarks school={school}/>;
      case"alerts":   return <PgAlerts school={school}/>;
      case"whatsapp": return <PgWhatsApp school={school}/>;
      case"upload":    return <PgUpload school={school}/>;
      case"billing":   return <PgBilling school={school}/>;
      case"agent":     return <PgAgent school={school}/>;
      case"ivr":       return <PgIVR school={school}/>;
      case"receptionist": return <PgReceptionist school={school}/>;
      case"admission":  return <PgAdmission school={school}/>;
      case"homemsg":   return <PgHomeMsg school={school}/>;
      case"enquiry":   return <PgEnquiry school={school}/>;
      case"video":     return <PgVideo school={school}/>;
      case"demo":     return <PgDemo school={school}/>;
      case"reset":    return <PgReset school={school}/>;
      case"settings": return <PgSettings school={school} onLogout={onLogout} onUpdate={setSchool}/>;
      default:        return <PgHome {...p}/>;
    }
  };

  const curNav = NAV.find(n=>n.id===pg);

  return (
    <div style={{display:"flex",minHeight:"100vh",background:"#EDE8DF"}}>
      <Orbs/>
      <Sidebar pg={pg} setPg={setPg} school={school} onLogout={onLogout} col={col} setCol={setCol}/>
      <div style={{flex:1,marginLeft:sw,transition:"margin .3s",display:"flex",flexDirection:"column",minHeight:"100vh",position:"relative",zIndex:2}}>
        <header style={{borderBottom:`1px solid ${D.b0}`,padding:".85rem 2rem",display:"flex",alignItems:"center",justifyContent:"space-between",position:"sticky",top:0,zIndex:40,background:"rgba(237,232,223,.95)",backdropFilter:"blur(20px)"}}>
          <div style={{fontSize:".68rem",letterSpacing:".12em",textTransform:"uppercase",color:D.t3,display:"flex",alignItems:"center",gap:".4rem"}}>
            <span>{curNav?.e}</span>{curNav?.l}
          </div>
          <div style={{display:"flex",gap:".75rem",alignItems:"center"}}>
            {school.logo&&<img src={school.logo} alt="" style={{width:22,height:22,borderRadius:5,objectFit:"cover"}}/>}
            <span style={{fontSize:".76rem",color:D.t2}}>{school.name}</span>
            <Badge c={school.plan==="elite"?"gold":school.plan==="pro"?"cyan":"gray"}>{PLANS.find(p=>p.id===school.plan)?.price||"₹25,000/mo"}</Badge>
            <div style={{width:6,height:6,borderRadius:"50%",background:D.green,animation:"pulse 2s infinite"}}/>
          </div>
        </header>
        <main style={{flex:1,padding:"2.2rem 2rem",maxWidth:1300,width:"100%"}}>
          {renderPg()}
        </main>
      </div>
    </div>
  );
};

// ══════════════════════════════════════════════════
// ROOT APP
// ══════════════════════════════════════════════════
export default function App() {
  const [view,setView]    = useState("boot");
  const [school,setSchool]= useState(null);
  const [parentData,setPD]= useState(null);

  useEffect(()=>{
    setTimeout(()=>{
      const saved=S.g("session");
      if(saved?.role==="superadmin"){setView("superadmin");return;}
      if(saved?.role==="parent"&&saved?.school&&saved?.student){setPD(saved);setView("parent");return;}
      if(saved?.id){seedSchool(saved.id);setSchool(saved);setView("dash");return;}
      setView("auth");
    },600);
  },[]);

  const onAuth = (data,role) => {
    if(role==="admin"){seedSchool(data.id);setSchool(data);setView("dash");}
    else if(role==="parent"){setPD(data);setView("parent");}
  };
  const onSuper = () => {S.s("session",{role:"superadmin"});setView("superadmin");};
  const logout  = () => {S.s("session",null);setSchool(null);setPD(null);setView("auth");};

  if(view==="boot") return (
    <div style={{minHeight:"100vh",display:"grid",placeItems:"center",background:"#EDE8DF",position:"relative",overflow:"hidden"}}>
      <Orbs/>
      <div style={{textAlign:"center",position:"relative",zIndex:2,animation:"fadeUp .8s ease"}}>
        <div style={{fontFamily:"'Playfair Display',serif",fontSize:"3rem",fontWeight:800,background:`linear-gradient(135deg,${D.cyan},${D.purp},${D.gold})`,WebkitBackgroundClip:"text",WebkitTextFillColor:"transparent",marginBottom:"2rem",letterSpacing:"-.03em"}}>Edunex</div>
        <div style={{width:36,height:36,border:`2px solid rgba(0,0,0,.1)`,borderTopColor:"#C9973A",borderRadius:"50%",animation:"spin .8s linear infinite",margin:"0 auto"}}/>
        <div style={{fontSize:".78rem",color:D.t3,marginTop:"1rem",letterSpacing:".04em"}}>Loading platform…</div>
      </div>
    </div>
  );

  return (
    <>
      <style>{CSS}</style>
      {view==="auth"&&<Auth onAuth={onAuth} onSuper={onSuper}/>}
      {view==="superadmin"&&<SuperAdmin onLogout={logout}/>}
      {view==="parent"&&parentData&&<ParentPortal data={parentData} onLogout={logout}/>}
      {view==="dash"&&school&&<Dashboard school={school} onLogout={logout}/>}
    </>
  );
}

export default App;
